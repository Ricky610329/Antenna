# R81 EngineeringOnly offline release assembler

This directory contains a thin, untracked preparation tool for the first R81 engineering release. It reuses the repository’s existing implementation and does not contain an example release, guessed private path, or fabricated completion record.

The tool performs these operations in order:

1. Verify the supplied R80 completion JSON SHA-256, wide-profile SHA-256, and masked-prior config SHA-256. The validated masked-prior config must exactly equal `r81_prior_recipe.build_recipe` for the supplied absolute prior manifest and sample-root paths.
2. Build the exact native `RUNTIME_FILES` map from the supplied full Git commit and call `script.r81_worker_entry._validate_runtime`.
3. Pass the supplied R80 completion object directly to `script.r81_worker_entry._validate_r80`, with the requested private R81 dataset path, before creating any output.
4. Read the explicit historical dual stores through `dual_history_seeds` and snapshot them through `write_seeds`.
5. Call `exploration.prepare_run` once with the masked-prior config. This is the authoritative controller and formal batch-1 source. Its normal full prior preflight runs before the controller work directory is created.
6. Copy that exact batch-1 bundle to `dedust_r81b1_input`. Derive 6 Fast representatives, two per arm, then reuse the first two history representatives for both Discrete and mesh. All derivative configs retain the same masked-prior exploration section while applying the native `wide_check_configs` measurement/runtime variants.
7. Run `validate_wide_inputs` and use native `dedust.jobs_add` to create only the three engineering jobs. Formal batch 1 remains hash-bound and unqueued.
8. Build the exact `EngineeringOnly` release schema. Write an exclusive candidate file and pass its exact bytes through native `validate_release`.
9. Write a preparation receipt containing assembler/helper SHA-256 bindings and the native validation report.
10. Create the byte-identical final release with exclusive creation. The final release is the last write.

Any failure after output creation leaves the generated prefix in place. Reusing the same dataset, controller, seed, candidate, receipt, or release path is refused. Inspect and preserve the failed attempt, then choose a new versioned set of output paths.

## Required arguments

All hashes are lowercase SHA-256. All output parents must already exist. The dataset, controller, and release destinations must be fresh. The private dataset path must contain `r81`, matching the existing native validator.

| Argument | Type and meaning |
|---|---|
| `--r80-completion` | Existing JSON file whose top-level object is accepted directly by native `_validate_r80`; it must contain the exact watch/action/census/profile/raw rows/proofs/producer bindings. |
| `--r80-completion-sha256` | SHA-256 of those exact JSON bytes. |
| `--runtime-commit` | Full 40-character lowercase Git commit. It must be an ancestor, and every native runtime path must remain clean relative to it. |
| `--wide-profile` | Existing R81 wide-profile YAML matching the canonical tracked Fast profile. |
| `--wide-profile-sha256` | SHA-256 of the wide-profile bytes. |
| `--prior-config` | Existing masked-prior YAML with absolute `manifest` and `sample_root` paths. Every other validated field must equal the complete canonical production recipe returned by `r81_prior_recipe.build_recipe`. |
| `--prior-config-sha256` | SHA-256 of the masked-prior config bytes. |
| `--history-root` | Existing historical dataset root containing the exact R79 and `smp073` input/result stores consumed by `dual_history_seeds`. |
| `--dataset-root` | Fresh absolute private R81 dataset directory to create. |
| `--controller-work-dir` | Fresh absolute controller directory to create. A sibling `<name>_explicit_seeds` directory is reserved automatically and must also be absent. |
| `--release-output` | Fresh final release JSON path. Sibling `.candidate` and `.preparation.json` files must also be absent. |
| `--release-id` | Safe release identifier accepted by the native validator. |
| `--priority` | Integer stored in all three native queue jobs; default `5`. |

The command shape is deliberately placeholder-only:

```powershell
<ANT_PYTHON> tmp/r81_engineering_release_assembler_20261011_v001/assemble_r81_engineering_release.py `
  --r80-completion <ABSOLUTE_FINAL_R80_COMPLETION_JSON> `
  --r80-completion-sha256 <EXACT_SHA256> `
  --runtime-commit <FULL_GIT_COMMIT> `
  --wide-profile <ABSOLUTE_CANONICAL_R81_PROFILE_YAML> `
  --wide-profile-sha256 <EXACT_SHA256> `
  --prior-config <ABSOLUTE_MASKED_PRIOR_CONFIG_YAML> `
  --prior-config-sha256 <EXACT_SHA256> `
  --history-root <ABSOLUTE_HISTORICAL_DATASET_ROOT> `
  --dataset-root <FRESH_ABSOLUTE_PRIVATE_R81_DATASET> `
  --controller-work-dir <FRESH_ABSOLUTE_PRIVATE_R81_CONTROLLER> `
  --release-output <FRESH_ABSOLUTE_RELEASE_JSON> `
  --release-id <VERSIONED_SAFE_ID>
```

The callable surface can be inspected without running preparation:

```powershell
<ANT_PYTHON> tmp/r81_engineering_release_assembler_20261011_v001/assemble_r81_engineering_release.py `
  --show-native-signatures
```

`--show-native-signatures` must be used by itself. No paths are read and no outputs are created.

## Tests and mocked boundaries

Run only the bounded local test file:

```powershell
<ANT_PYTHON> -m pytest -q tmp/r81_engineering_release_assembler_20261011_v001/test_assembler.py
```

The tests do not load the real 21,034-row prior, train, run a model forward pass, access NAS, start HFSS, launch a process, claim work, or touch markers/queues outside a pytest temporary directory.

The first release is bound to this complete frozen recipe. A future intentional seed, training, geometry, pool-size, or other non-path recipe change requires a separately reviewed and versioned recipe; a caller cannot authorize drift merely by supplying a coherent new config SHA-256.

The complete-shape test explicitly mocks two boundaries:

- tracked-census Git-path lookup is redirected to the existing generated native fixture census;
- historical-prior loading and the real controller lifecycle are replaced by the existing generated `test_r81_worker_entry` wide-input fixture.

Within that bounded fixture, native runtime validation, the rest of native R80 field validation, `dedust.jobs_add`, input validation, candidate `validate_release`, and final-release `validate_release` execute. This verifies orchestration and schema, not actual 5,000-point completion, prior integrity, model behavior, three-host deployment, or HFSS.

## Limits before execution

- The repository currently has 4,243 valid unique R80 points in the latest tracked action, so the real native 5,000/zero-pending gate cannot pass yet.
- No real final R80 completion JSON or immutable R81 release exists.
- The actual prior preflight, controller preparation, three-host `-CheckOnly`, engineering HFSS, and measurement comparison remain unexecuted.
- The isolated transition-aware selector is outside this native44 EngineeringOnly assembler. Its unresolved three-host CPU replay does not block the first 6+2+2 engineering release and must not be merged before R80 v004 closeout binds the unchanged native entry.
