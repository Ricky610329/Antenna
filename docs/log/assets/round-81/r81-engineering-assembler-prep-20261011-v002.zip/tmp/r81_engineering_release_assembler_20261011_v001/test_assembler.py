from __future__ import annotations

import importlib.util
import json
from pathlib import Path
import sys

import pytest


HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]


def _load(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


assembler = _load(HERE / "assemble_r81_engineering_release.py", "r81_offline_assembler")
fixture = _load(REPO / "tests/test_r81_worker_entry.py", "r81_native_fixture_helpers")


def _actual_configs():
    wide = REPO / "configs/dual_r81_wide_filter.yaml"
    prior = REPO / "tmp/r81_masked_prior_config_20261010_v001/config.yaml"
    return wide, prior


def test_instrument_derivatives_keep_one_masked_prior_controller():
    _wide, prior = _actual_configs()
    controller = assembler.ex.validate_exploration_config(assembler.ex._load_yaml(prior))
    variants = assembler.derive_instrument_configs(controller)
    native = assembler.prep.wide_check_configs()

    for name in ("smoke", "discrete", "mesh"):
        assert variants[name]["exploration"] == controller["exploration"]
        assert variants[name]["measurement"] == native[name]["measurement"]
        assert variants[name]["score_spec"] == native[name]["score_spec"]
        assert variants[name]["runtime"] == native[name]["runtime"]
    assert variants["smoke"]["exploration"]["training_protocol"] == "filter_masked_prior_v1"


def test_native_runtime_failure_happens_before_any_output(monkeypatch, tmp_path):
    wide, prior = _actual_configs()
    completion = tmp_path / "completion.json"
    completion.write_text("{}\n", encoding="utf-8")
    history = tmp_path / "history"
    history.mkdir()
    dataset = tmp_path / "private_r81_dataset"
    controller = tmp_path / "private_r81_controller"
    release = tmp_path / "release.json"

    def fail_runtime(_commit):
        raise ValueError("synthetic native runtime rejection")

    monkeypatch.setattr(assembler, "_build_runtime_binding", fail_runtime)
    with pytest.raises(ValueError, match="synthetic native runtime rejection"):
        assembler.assemble_engineering_release(
            r80_completion_path=completion,
            r80_completion_sha256=assembler.file_sha256(completion),
            runtime_commit="a" * 40,
            wide_profile=wide,
            wide_profile_sha256=assembler.file_sha256(wide),
            prior_config=prior,
            prior_config_sha256=assembler.file_sha256(prior),
            history_root=history,
            dataset_root=dataset,
            controller_work_dir=controller,
            release_output=release,
            release_id="fixture_runtime_reject",
        )

    assert not dataset.exists()
    assert not controller.exists()
    assert not (tmp_path / "private_r81_controller_explicit_seeds").exists()
    assert not release.exists()
    assert not release.with_name("release.json.candidate").exists()
    assert not release.with_name("release.json.preparation.json").exists()


def test_noncanonical_prior_seed_rejected_before_any_output(monkeypatch, tmp_path):
    wide, prior = _actual_configs()
    changed = assembler.ex._load_yaml(prior)
    changed["exploration"]["seed"] += 1
    changed_prior = tmp_path / "changed_prior.yaml"
    changed_prior.write_text(
        json.dumps(changed, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    completion = tmp_path / "completion.json"
    completion.write_text("{}\n", encoding="utf-8")
    history = tmp_path / "history"
    history.mkdir()
    dataset = tmp_path / "private_r81_dataset"
    controller = tmp_path / "private_r81_controller"
    release = tmp_path / "release.json"

    def runtime_must_not_run(_commit):
        raise AssertionError("runtime gate reached after noncanonical recipe")

    monkeypatch.setattr(assembler, "_build_runtime_binding", runtime_must_not_run)
    with pytest.raises(
            ValueError,
            match="complete frozen production recipe"):
        assembler.assemble_engineering_release(
            r80_completion_path=completion,
            r80_completion_sha256=assembler.file_sha256(completion),
            runtime_commit="a" * 40,
            wide_profile=wide,
            wide_profile_sha256=assembler.file_sha256(wide),
            prior_config=changed_prior,
            prior_config_sha256=assembler.file_sha256(changed_prior),
            history_root=history,
            dataset_root=dataset,
            controller_work_dir=controller,
            release_output=release,
            release_id="fixture_recipe_reject",
        )

    assert not dataset.exists()
    assert not controller.exists()
    assert not (tmp_path / "private_r81_controller_explicit_seeds").exists()
    assert not release.exists()
    assert not release.with_name("release.json.candidate").exists()
    assert not release.with_name("release.json.preparation.json").exists()


def test_complete_release_shape_uses_actual_native_validator(monkeypatch, tmp_path):
    """Bounded fixture: prior loading/controller creation are explicitly mocked.

    Native runtime validation, R80 field validation (except tracked-census path
    lookup), jobs_add, input validation, and validate_release all execute.
    No model forward, training, HFSS, NAS, process, or marker operation occurs.
    """
    wide, prior = _actual_configs()
    dataset = tmp_path / "private_r81_dataset"
    controller = tmp_path / "private_r81_controller"
    seed = tmp_path / "private_r81_controller_explicit_seeds"
    release = tmp_path / "release.json"
    history = tmp_path / "history"
    history.mkdir()

    completion_binding = fixture._evidence(tmp_path, dataset)
    completion_path = tmp_path / "r80_completion.json"
    assembler.pb.atomic_json(completion_path, completion_binding)

    def bound_census(binding, _commit):
        path = fixture._CENSUS_FIXTURES[binding["repo_path"]]
        assert assembler.file_sha256(path) == binding["sha256"]
        return path, assembler.pb.read_json(path)

    monkeypatch.setattr(assembler.entry, "_bound_census_status", bound_census)

    def generated_fixture_inputs(*, history_root, prior_config, dataset_root,
                                 controller_work_dir, seed_output):
        assert history_root == history
        assert prior_config == prior
        assert dataset_root == dataset
        fixture._wide_fixture(dataset_root)
        controller_work_dir.mkdir()
        seed_output.mkdir()
        (controller_work_dir / "MOCKED_BOUNDARY.txt").write_text(
            "Generated native input fixture only; prior/controller execution mocked.\n",
            encoding="utf-8",
        )
        return {
            "mocked_boundary": "native generated wide-input fixture",
            "formal_manifest_sha256": assembler.file_sha256(
                dataset_root / "dedust_r81b1_input/manifest.json"),
        }

    monkeypatch.setattr(assembler, "materialize_engineering_inputs", generated_fixture_inputs)
    runtime_commit = assembler.entry._git_commit()
    result = assembler.assemble_engineering_release(
        r80_completion_path=completion_path,
        r80_completion_sha256=assembler.file_sha256(completion_path),
        runtime_commit=runtime_commit,
        wide_profile=wide,
        wide_profile_sha256=assembler.file_sha256(wide),
        prior_config=prior,
        prior_config_sha256=assembler.file_sha256(prior),
        history_root=history,
        dataset_root=dataset,
        controller_work_dir=controller,
        release_output=release,
        release_id="fixture_engineering_only",
        priority=5,
    )

    candidate = release.with_name("release.json.candidate")
    receipt_path = release.with_name("release.json.preparation.json")
    assert release.read_bytes() == candidate.read_bytes()
    assert result["release_sha256"] == assembler.file_sha256(release)

    document = json.loads(release.read_text(encoding="utf-8"))
    assert set(document) == {
        "schema_version", "release_id", "stage", "dataset_root",
        "runtime", "r80_completion", "queue",
    }
    assert document["stage"] == "EngineeringOnly"
    assert document["queue"]["exploration"] is None
    assert document["queue"]["formal_input"]["name"] == "dedust_r81b1_input"
    assert [row["role"] for row in document["queue"]["jobs"]] == [
        "engineering_smoke", "engineering_discrete", "engineering_mesh",
    ]
    assert [row["job"]["store"] for row in document["queue"]["jobs"]] == [
        "dedust_r81smoke", "dedust_r81discrete", "dedust_r81mesh",
    ]
    assert "dedust_r81b1" not in [row["job"]["store"] for row in document["queue"]["jobs"]]

    report = assembler.entry.validate_release(
        release, assembler.file_sha256(release), "EngineeringOnly")
    assert report["status"] == "r81_worker_entry_passed"
    assert report["job_count"] == 3
    assert report["hfss_started"] is False

    receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
    assert receipt["source_bindings"]["assembler"]["sha256"] == assembler.file_sha256(
        HERE / "assemble_r81_engineering_release.py")
    assert receipt["source_bindings"]["script/r81_worker_entry.py"]["sha256"] == assembler.file_sha256(
        REPO / "script/r81_worker_entry.py")
    assert receipt["candidate_native_report"]["status"] == "r81_worker_entry_passed"
