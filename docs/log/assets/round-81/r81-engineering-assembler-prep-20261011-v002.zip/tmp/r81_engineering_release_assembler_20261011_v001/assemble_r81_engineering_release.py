"""Offline assembler for the first immutable R81 EngineeringOnly release.

This tool prepares files only.  It never starts workers or HFSS.  It calls the
existing native runtime and R80 completion gates before it creates any output,
then uses the existing R81 preparation functions and native release validator.

Every output is exclusive-create.  A failed attempt is preserved and the same
paths cannot be reused automatically.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import inspect
import json
import re
import shutil
import sys
from dataclasses import dataclass
from pathlib import Path
from types import SimpleNamespace
from typing import Any, Mapping, Sequence


REPO = Path(__file__).resolve().parents[2]
if str(REPO) not in sys.path:
    sys.path.insert(0, str(REPO))

from script import dedust
from script import exploration as ex
from script import filter_training
from script import prepare_symmetry_filter as prep
from script import profiled_batch as pb
from script import r81_prior_recipe
from script import r81_worker_entry as entry


SCHEMA_VERSION = 1
STAGE = "EngineeringOnly"
HEX40 = re.compile(r"[0-9a-f]{40}")
HEX64 = re.compile(r"[0-9a-f]{64}")
ENGINEERING_ROLES = (
    ("engineering_smoke", "dedust_r81smoke", 6),
    ("engineering_discrete", "dedust_r81discrete", 2),
    ("engineering_mesh", "dedust_r81mesh", 2),
)


@dataclass(frozen=True)
class OutputPaths:
    dataset_root: Path
    controller_work_dir: Path
    seed_output: Path
    release_output: Path
    candidate_output: Path
    receipt_output: Path


def file_sha256(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def inspect_native_signatures() -> dict[str, str]:
    """Return the exact callable signatures used by this offline assembler."""
    functions = {
        "entry._validate_runtime": entry._validate_runtime,
        "entry._validate_r80": entry._validate_r80,
        "entry.validate_release": entry.validate_release,
        "prep.dual_history_seeds": prep.dual_history_seeds,
        "prep.write_seeds": prep.write_seeds,
        "ex.prepare_run": ex.prepare_run,
        "prep.auxiliary_bundle": prep.auxiliary_bundle,
        "prep.wide_check_configs": prep.wide_check_configs,
        "prep.validate_wide_inputs": prep.validate_wide_inputs,
        "dedust.jobs_add": dedust.jobs_add,
    }
    return {name: str(inspect.signature(function)) for name, function in functions.items()}


def _read_json_object(path: Path, label: str) -> dict[str, Any]:
    value = pb.read_json(path)
    if not isinstance(value, dict):
        raise ValueError(f"{label} must contain a JSON object")
    return value


def _require_hash(path: Path, expected: str, label: str) -> str:
    if HEX64.fullmatch(expected) is None:
        raise ValueError(f"{label} SHA-256 must be 64 lowercase hexadecimal characters")
    actual = file_sha256(path)
    if actual != expected:
        raise ValueError(f"{label} SHA-256 differs: {actual}")
    return actual


def _exclusive_bytes(path: Path, payload: bytes) -> None:
    with path.open("xb") as stream:
        stream.write(payload)


def _json_bytes(value: Any) -> bytes:
    return (json.dumps(value, indent=2, ensure_ascii=False) + "\n").encode("utf-8")


def _inside(left: Path, right: Path) -> bool:
    try:
        left.resolve(strict=False).relative_to(right.resolve(strict=False))
        return True
    except ValueError:
        return False


def _output_paths(dataset_root: Path, controller_work_dir: Path,
                  release_output: Path) -> OutputPaths:
    dataset = dataset_root.resolve(strict=False)
    controller = controller_work_dir.resolve(strict=False)
    release = release_output.resolve(strict=False)
    seed = controller.parent / f"{controller.name}_explicit_seeds"
    candidate = release.with_name(release.name + ".candidate")
    receipt = release.with_name(release.name + ".preparation.json")
    paths = OutputPaths(dataset, controller, seed, release, candidate, receipt)

    roots = (paths.dataset_root, paths.controller_work_dir, paths.seed_output)
    if len(set(roots)) != len(roots):
        raise ValueError("dataset, controller, and explicit-seed outputs must be distinct")
    for index, left in enumerate(roots):
        for right in roots[index + 1:]:
            if _inside(left, right) or _inside(right, left):
                raise ValueError("dataset, controller, and explicit-seed outputs must not contain one another")
    for file_path in (paths.release_output, paths.candidate_output, paths.receipt_output):
        if any(_inside(file_path, root) for root in roots):
            raise ValueError("release, candidate, and receipt files must stay outside generated roots")
    for path in (*roots, paths.release_output, paths.candidate_output, paths.receipt_output):
        if path.exists():
            raise FileExistsError(f"refusing to reuse or overwrite preserved attempt output: {path}")
    for parent in {path.parent for path in (*roots, paths.release_output)}:
        if not parent.is_dir():
            raise FileNotFoundError(f"output parent must already exist: {parent}")
    if "r81" not in str(paths.dataset_root).lower():
        raise ValueError("dataset_root must be an explicit separate R81 path")
    return paths


def _build_runtime_binding(runtime_commit: str) -> dict[str, Any]:
    if HEX40.fullmatch(runtime_commit) is None:
        raise ValueError("runtime commit must be a full lowercase 40-character Git id")
    runtime = {
        "git_commit": runtime_commit,
        "files": {relative: entry._git_blob_sha(runtime_commit, relative)
                  for relative in entry.RUNTIME_FILES},
    }
    entry._validate_runtime(runtime)
    return runtime


def _validated_configs(wide_profile: Path, wide_profile_sha256: str,
                       prior_config: Path, prior_config_sha256: str
                       ) -> tuple[dict[str, Any], dict[str, Any]]:
    _require_hash(wide_profile, wide_profile_sha256, "wide profile")
    _require_hash(prior_config, prior_config_sha256, "masked-prior config")
    wide = ex.validate_exploration_config(ex._load_yaml(wide_profile))
    prior = ex.validate_exploration_config(ex._load_yaml(prior_config))
    canonical = prep.wide_check_configs()["smoke"]
    for field in ("measurement", "score_spec", "runtime"):
        if wide.get(field) != canonical.get(field):
            raise ValueError(f"supplied wide profile differs from canonical {field}")
        if prior.get(field) != wide.get(field):
            raise ValueError(f"masked-prior config differs from wide profile {field}")
    if prior.get("name") != wide.get("name") or prior.get("port") != "dual" or prior.get("scope") != prep.SCOPE:
        raise ValueError("masked-prior config identity differs from the canonical R81 profile")
    spec = filter_training._prior_spec(prior)
    if spec["expected_manifest_sha256"] != r81_prior_recipe.EXPECTED_PRIOR_MANIFEST_SHA256:
        raise ValueError("masked-prior config does not bind the frozen R81 prior manifest")
    prior_paths = prior["exploration"]["filter_prior"]
    canonical_prior = r81_prior_recipe.build_recipe(
        prior_paths["manifest"], prior_paths["sample_root"])
    if prior != canonical_prior:
        raise ValueError(
            "masked-prior config differs from the complete frozen production recipe")
    return wide, prior


def derive_instrument_configs(controller_config: Mapping[str, Any]) -> dict[str, dict[str, Any]]:
    """Apply the native instrument profiles while retaining one controller recipe."""
    native = prep.wide_check_configs()
    derived: dict[str, dict[str, Any]] = {}
    for name in ("smoke", "discrete", "mesh"):
        cfg = copy.deepcopy(dict(controller_config))
        cfg["measurement"] = copy.deepcopy(native[name]["measurement"])
        cfg["score_spec"] = copy.deepcopy(native[name]["score_spec"])
        cfg["runtime"] = copy.deepcopy(native[name].get("runtime", {}))
        derived[name] = cfg
    return derived


def materialize_engineering_inputs(*, history_root: Path, prior_config: Path,
                                   dataset_root: Path, controller_work_dir: Path,
                                   seed_output: Path) -> dict[str, Any]:
    """Create one controller, formal batch 1, and its exact 6+2+2 derivatives."""
    dual_rows, history_evidence = prep.dual_history_seeds(history_root)
    prep.write_seeds(seed_output, dual_rows)
    batch_one = ex.prepare_run(prior_config, dataset_root, controller_work_dir, [seed_output])

    formal = dataset_root / "dedust_r81b1_input"
    shutil.copytree(batch_one, formal)
    controller_config = ex.validate_exploration_config(ex._load_yaml(controller_work_dir / "config.yaml"))
    variants = derive_instrument_configs(controller_config)
    manifest = pb.read_json(formal / "manifest.json")
    indices: list[int] = []
    for arm in ("history", "specialist", "random"):
        arm_indices = [index for index, row in enumerate(manifest)
                       if row.get("selection_arm") == arm]
        if len(arm_indices) != 20:
            raise ValueError(f"formal batch 1 needs exactly 20 {arm} rows")
        indices.extend(arm_indices[:2])

    prep.auxiliary_bundle(formal, dataset_root / "dedust_r81smoke_input",
                          indices, config=variants["smoke"])
    prep.auxiliary_bundle(formal, dataset_root / "dedust_r81discrete_input",
                          indices[:2], config=variants["discrete"])
    prep.auxiliary_bundle(formal, dataset_root / "dedust_r81mesh_input",
                          indices[:2], config=variants["mesh"])
    configs, parents = prep.validate_wide_inputs(dataset_root)
    return {
        "history_evidence": history_evidence,
        "formal_batch_one": str(formal),
        "formal_manifest_sha256": file_sha256(formal / "manifest.json"),
        "representative_parent_ids": {
            name: list(parent_map) for name, parent_map in parents.items()
        },
        "instrument_measurement_ids": {
            name: entry.measurement_id(cfg.measurement) for name, cfg in configs.items()
        },
    }


def _direct_files(folder: Path) -> dict[str, str]:
    return {path.name: file_sha256(path) for path in folder.iterdir() if path.is_file()}


def add_engineering_jobs(dataset_root: Path, priority: int) -> list[dict[str, Any]]:
    """Use native jobs_add and return release entries for its exact ordered jobs."""
    if isinstance(priority, bool):
        raise ValueError("priority must be an integer")
    original_dataset = dedust.DATASET_PATH
    entries: list[dict[str, Any]] = []
    try:
        dedust.DATASET_PATH = dataset_root
        for role, store, _count in ENGINEERING_ROLES:
            input_name = store + "_input"
            dedust.jobs_add(SimpleNamespace(
                input=input_name,
                store=store,
                prio=int(priority),
                scope=prep.SCOPE,
                config=str(dataset_root / input_name / "config.yaml"),
                machine=None,
            ))
            entries.append({
                "role": role,
                "job": pb.read_json(dataset_root / "jobs.json")[-1],
                "input_files": _direct_files(dataset_root / input_name),
            })
    finally:
        dedust.DATASET_PATH = original_dataset
    actual = pb.read_json(dataset_root / "jobs.json")
    if actual != [item["job"] for item in entries]:
        raise ValueError("native jobs.json differs from the exact three engineering entries")
    return entries


def build_release_document(*, release_id: str, dataset_root: Path,
                           runtime: Mapping[str, Any], r80_completion: Mapping[str, Any],
                           jobs: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    """Build the exact schema consumed by the native R81 release validator."""
    return {
        "schema_version": 1,
        "release_id": release_id,
        "stage": STAGE,
        "dataset_root": str(dataset_root),
        "runtime": copy.deepcopy(dict(runtime)),
        "r80_completion": copy.deepcopy(dict(r80_completion)),
        "queue": {
            "jobs_sha256": file_sha256(dataset_root / "jobs.json"),
            "jobs": copy.deepcopy(list(jobs)),
            "formal_input": {
                "name": "dedust_r81b1_input",
                "files": _direct_files(dataset_root / "dedust_r81b1_input"),
            },
            "exploration": None,
            "expected_retry_workers": list(entry.EXPECTED_WORKERS),
        },
    }


def _source_bindings(*, wide_profile: Path, prior_config: Path,
                     r80_completion_path: Path) -> dict[str, Any]:
    modules = {
        "assembler": Path(__file__).resolve(),
        "script/r81_worker_entry.py": Path(entry.__file__).resolve(),
        "script/prepare_symmetry_filter.py": Path(prep.__file__).resolve(),
        "script/exploration.py": Path(ex.__file__).resolve(),
        "script/filter_training.py": Path(filter_training.__file__).resolve(),
        "script/dedust.py": Path(dedust.__file__).resolve(),
        "script/profiled_batch.py": Path(pb.__file__).resolve(),
        "script/r81_prior_recipe.py": Path(r81_prior_recipe.__file__).resolve(),
        "wide_profile": wide_profile.resolve(),
        "masked_prior_config": prior_config.resolve(),
        "r80_completion_binding": r80_completion_path.resolve(),
    }
    return {name: {"path": str(path), "sha256": file_sha256(path)}
            for name, path in modules.items()}


def assemble_engineering_release(*, r80_completion_path: Path,
                                 r80_completion_sha256: str,
                                 runtime_commit: str,
                                 wide_profile: Path,
                                 wide_profile_sha256: str,
                                 prior_config: Path,
                                 prior_config_sha256: str,
                                 history_root: Path,
                                 dataset_root: Path,
                                 controller_work_dir: Path,
                                 release_output: Path,
                                 release_id: str,
                                 priority: int = 5) -> dict[str, Any]:
    """Assemble and natively validate a fresh offline EngineeringOnly release.

    Native runtime and R80 exact-5000/zero-pending validation completes before
    any destination directory or release-side file is created.
    """
    paths = _output_paths(dataset_root, controller_work_dir, release_output)
    completion_path = r80_completion_path.resolve(strict=True)
    wide_path = wide_profile.resolve(strict=True)
    prior_path = prior_config.resolve(strict=True)
    history = history_root.resolve(strict=True)
    if not history.is_dir():
        raise ValueError("history_root must be a directory")

    _require_hash(completion_path, r80_completion_sha256, "R80 completion binding")
    _wide, _prior = _validated_configs(
        wide_path, wide_profile_sha256, prior_path, prior_config_sha256)
    completion = _read_json_object(completion_path, "R80 completion binding")

    # These are the required native pre-mutation gates.
    runtime = _build_runtime_binding(runtime_commit)
    r80_summary = entry._validate_r80(completion, paths.dataset_root, runtime_commit)

    # From this point onward failures deliberately leave an immutable prefix.
    paths.dataset_root.mkdir()
    preparation = materialize_engineering_inputs(
        history_root=history,
        prior_config=prior_path,
        dataset_root=paths.dataset_root,
        controller_work_dir=paths.controller_work_dir,
        seed_output=paths.seed_output,
    )
    jobs = add_engineering_jobs(paths.dataset_root, priority)
    release = build_release_document(
        release_id=release_id,
        dataset_root=paths.dataset_root,
        runtime=runtime,
        r80_completion=completion,
        jobs=jobs,
    )
    release_bytes = _json_bytes(release)
    release_sha = hashlib.sha256(release_bytes).hexdigest()

    # Validate the exact bytes before the final release path exists.
    _exclusive_bytes(paths.candidate_output, release_bytes)
    candidate_report = entry.validate_release(paths.candidate_output, release_sha, STAGE)
    if candidate_report.get("status") != "r81_worker_entry_passed" or candidate_report.get("hfss_started") is not False:
        raise ValueError("native candidate release validation did not return the expected pass report")

    receipt = {
        "schema_version": SCHEMA_VERSION,
        "status": "offline_engineering_release_candidate_native_validated",
        "release_id": release_id,
        "stage": STAGE,
        "release_sha256": release_sha,
        "candidate_path": str(paths.candidate_output),
        "final_release_path": str(paths.release_output),
        "dataset_root": str(paths.dataset_root),
        "controller_work_dir": str(paths.controller_work_dir),
        "explicit_seed_output": str(paths.seed_output),
        "runtime_commit": runtime_commit,
        "runtime_file_count": len(runtime["files"]),
        "r80_native_summary": r80_summary,
        "candidate_native_report": candidate_report,
        "preparation": preparation,
        "source_bindings": _source_bindings(
            wide_profile=wide_path,
            prior_config=prior_path,
            r80_completion_path=completion_path,
        ),
        "native_signatures": inspect_native_signatures(),
        "mocked_boundaries": [],
        "hfss_started": False,
        "worker_started": False,
        "queue_worker_claimed": False,
        "limits": [
            "Offline assembly and validation only; this receipt does not prove HFSS behavior.",
            "The final release still requires host-local CheckOnly validation before worker start.",
            "EngineeringOnly completion does not establish a positive R81 margin or campaign completion.",
            "Transition-aware later-batch three-host CPU replay is outside this native44 EngineeringOnly release.",
        ],
    }
    _exclusive_bytes(paths.receipt_output, _json_bytes(receipt))

    # The immutable release is the final write.  It is byte-identical to the
    # already natively validated candidate and uses exclusive creation.
    _exclusive_bytes(paths.release_output, release_bytes)
    if file_sha256(paths.release_output) != release_sha:
        raise ValueError("final release bytes differ from the validated candidate")
    return {
        "release": str(paths.release_output),
        "release_sha256": release_sha,
        "receipt": str(paths.receipt_output),
        "candidate": str(paths.candidate_output),
        "stage": STAGE,
        "hfss_started": False,
    }


def make_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--r80-completion", required=True, type=Path,
                        help="JSON object accepted directly by native _validate_r80")
    parser.add_argument("--r80-completion-sha256", required=True)
    parser.add_argument("--runtime-commit", required=True,
                        help="full 40-character commit bound by native RUNTIME_FILES")
    parser.add_argument("--wide-profile", required=True, type=Path)
    parser.add_argument("--wide-profile-sha256", required=True)
    parser.add_argument("--prior-config", required=True, type=Path)
    parser.add_argument("--prior-config-sha256", required=True)
    parser.add_argument("--history-root", required=True, type=Path)
    parser.add_argument("--dataset-root", required=True, type=Path,
                        help="fresh absolute private R81 dataset path")
    parser.add_argument("--controller-work-dir", required=True, type=Path,
                        help="fresh absolute controller output path")
    parser.add_argument("--release-output", required=True, type=Path,
                        help="fresh final release JSON path; written last")
    parser.add_argument("--release-id", required=True)
    parser.add_argument("--priority", type=int, default=5)
    parser.add_argument("--show-native-signatures", action="store_true")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    raw = list(sys.argv[1:] if argv is None else argv)
    if raw == ["--show-native-signatures"]:
        print(json.dumps(inspect_native_signatures(), indent=2, ensure_ascii=False))
        return 0
    args = make_parser().parse_args(raw)
    if args.show_native_signatures:
        raise ValueError("--show-native-signatures must be used by itself")
    result = assemble_engineering_release(
        r80_completion_path=args.r80_completion,
        r80_completion_sha256=args.r80_completion_sha256,
        runtime_commit=args.runtime_commit,
        wide_profile=args.wide_profile,
        wide_profile_sha256=args.wide_profile_sha256,
        prior_config=args.prior_config,
        prior_config_sha256=args.prior_config_sha256,
        history_root=args.history_root,
        dataset_root=args.dataset_root,
        controller_work_dir=args.controller_work_dir,
        release_output=args.release_output,
        release_id=args.release_id,
        priority=args.priority,
    )
    print(json.dumps(result, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
