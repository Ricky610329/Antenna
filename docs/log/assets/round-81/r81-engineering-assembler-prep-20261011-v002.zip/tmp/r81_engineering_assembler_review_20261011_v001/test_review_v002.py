from __future__ import annotations

import importlib.util
from pathlib import Path
import sys

import pytest
import yaml


HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
ASSEMBLER = (
    REPO
    / "tmp/r81_engineering_release_assembler_20261011_v001/assemble_r81_engineering_release.py"
)


def _load(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


assembler = _load(ASSEMBLER, "r81_offline_assembler_review_v002")


def test_adversarial_recipe_drift_is_rejected(tmp_path):
    """A coherent caller hash cannot authorize noncanonical recipe drift."""
    wide_path = REPO / "configs/dual_r81_wide_filter.yaml"
    prior_path = REPO / "tmp/r81_masked_prior_config_20261010_v001/config.yaml"
    changed = assembler.ex._load_yaml(prior_path)
    changed["exploration"]["seed"] += 1
    changed_path = tmp_path / "changed-prior.yaml"
    changed_path.write_text(yaml.safe_dump(changed, sort_keys=False), encoding="utf-8")

    with pytest.raises(ValueError, match="complete frozen production recipe"):
        assembler._validated_configs(
            wide_path,
            assembler.file_sha256(wide_path),
            changed_path,
            assembler.file_sha256(changed_path),
        )
