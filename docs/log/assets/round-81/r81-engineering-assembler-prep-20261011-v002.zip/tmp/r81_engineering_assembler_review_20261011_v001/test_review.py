from __future__ import annotations

import importlib.util
from pathlib import Path
import sys

import numpy as np
import torch
import yaml


HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
ASSEMBLER_DIR = REPO / "tmp/r81_engineering_release_assembler_20261011_v001"


def _load(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


assembler = _load(
    ASSEMBLER_DIR / "assemble_r81_engineering_release.py",
    "r81_offline_assembler_review",
)


def _write_controller_batch(work: Path, cfg: dict) -> Path:
    work.mkdir()
    (work / "config.yaml").write_text(
        yaml.safe_dump(cfg, sort_keys=False), encoding="utf-8"
    )
    batch = work / "batch-001"
    batch.mkdir()
    (batch / "config.yaml").write_text(
        yaml.safe_dump(cfg, sort_keys=False), encoding="utf-8"
    )
    loaded = assembler.pb.load_profile_config(batch / "config.yaml")
    rows = []
    for index in range(60):
        pattern = assembler.ex.enforce_dual_geometry(
            np.random.default_rng(index).random((25, 25))
        )
        pattern_file = f"p{index}.pt"
        torch.save(torch.as_tensor(pattern, dtype=torch.float32), batch / pattern_file)
        rows.append(
            {
                "id": f"p{index}",
                "pattern_file": pattern_file,
                "port": "dual",
                "pattern_sha256": assembler.pb.pattern_sha256(pattern),
                "measurement_id": assembler.entry.measurement_id(loaded.measurement),
                "score_spec_id": assembler.entry.score_spec_id(loaded.score_spec),
                "selection_arm": ("history", "specialist", "random")[index // 20],
                "batch": 1,
                "model_hash": None,
            }
        )
    assembler.pb.atomic_json(batch / "measurement.json", loaded.measurement)
    assembler.pb.atomic_json(batch / "score_spec.json", loaded.score_spec)
    assembler.pb.atomic_json(batch / "manifest.json", rows)
    return batch


def test_real_materializer_derives_exact_six_two_two(monkeypatch, tmp_path):
    """Generated tensors only: no prior load, training, forward, NAS, or process."""
    prior_path = REPO / "tmp/r81_masked_prior_config_20261010_v001/config.yaml"
    prior = assembler.ex.validate_exploration_config(assembler.ex._load_yaml(prior_path))
    dataset = tmp_path / "private_r81_dataset"
    dataset.mkdir()
    controller = tmp_path / "controller"
    seeds = tmp_path / "seeds"
    history = tmp_path / "history"
    history.mkdir()

    seed_pattern = assembler.ex.enforce_dual_geometry(np.zeros((25, 25)))
    monkeypatch.setattr(
        assembler.prep,
        "dual_history_seeds",
        lambda root: ([{"pattern": seed_pattern, "source_group": "history"}], {"mocked": True}),
    )

    def fake_prepare(config_path, dataset_root, work_dir, seed_inputs):
        assert config_path == prior_path
        assert dataset_root == dataset
        assert seed_inputs == [seeds]
        return _write_controller_batch(work_dir, prior)

    monkeypatch.setattr(assembler.ex, "prepare_run", fake_prepare)
    result = assembler.materialize_engineering_inputs(
        history_root=history,
        prior_config=prior_path,
        dataset_root=dataset,
        controller_work_dir=controller,
        seed_output=seeds,
    )

    expected = {
        "smoke": ["p0", "p1", "p20", "p21", "p40", "p41"],
        "discrete": ["p0", "p1"],
        "mesh": ["p0", "p1"],
    }
    assert result["representative_parent_ids"] == expected
    assert len(assembler.pb.read_json(dataset / "dedust_r81b1_input/manifest.json")) == 60
    for name, count in (("smoke", 6), ("discrete", 2), ("mesh", 2)):
        folder = dataset / f"dedust_r81{name}_input"
        rows = assembler.pb.read_json(folder / "manifest.json")
        config = assembler.ex.validate_exploration_config(
            assembler.ex._load_yaml(folder / "config.yaml")
        )
        assert len(rows) == count
        assert config["exploration"] == prior["exploration"]
    assert not (dataset / "jobs.json").exists()


def test_adversarial_recipe_drift_is_currently_accepted(tmp_path):
    """Documents that non-override exploration drift is outside the current gate."""
    wide_path = REPO / "configs/dual_r81_wide_filter.yaml"
    prior_path = REPO / "tmp/r81_masked_prior_config_20261010_v001/config.yaml"
    changed = assembler.ex._load_yaml(prior_path)
    changed["exploration"]["seed"] += 1
    changed_path = tmp_path / "changed-prior.yaml"
    changed_path.write_text(yaml.safe_dump(changed, sort_keys=False), encoding="utf-8")

    _wide, accepted = assembler._validated_configs(
        wide_path,
        assembler.file_sha256(wide_path),
        changed_path,
        assembler.file_sha256(changed_path),
    )
    assert accepted["exploration"]["seed"] == changed["exploration"]["seed"]
    assert accepted["exploration"]["seed"] != assembler.ex._load_yaml(wide_path)["exploration"]["seed"]
