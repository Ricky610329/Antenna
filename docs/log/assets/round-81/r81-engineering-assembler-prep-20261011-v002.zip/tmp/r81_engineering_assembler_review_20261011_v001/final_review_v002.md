# R81 EngineeringOnly assembler correction re-review v002

## Outcome

The F1 masked-prior validation defect is corrected. The assembler is ready for the later **offline preparation attempt** once the real native R80 exact-5,000/zero-pending evidence exists. This does not mean that a real R81 release, NAS preparation, controller run, worker handoff, or HFSS execution has been validated.

## Correction review

The corrected `_validated_configs` reads the supplied absolute prior manifest and sample-root paths, rebuilds the complete recipe through `r81_prior_recipe.build_recipe`, and requires equality with the entire validated supplied prior config (`assemble_r81_engineering_release.py:176-184`). The caller can relocate the two absolute prior paths, while seed, model/training settings, arm definitions, profile identity, measurement, score, runtime, training protocol, and expected manifest digest must remain canonical.

The previously demonstrated coherent-hash `exploration.seed` mutation now raises `ValueError("masked-prior config differs from the complete frozen production recipe")`. The implementation regression also proves this happens before the runtime gate and before dataset, controller, explicit seeds, candidate, receipt, or release paths are created (`test_assembler.py:86-129`). The unchanged canonical config still reaches the bounded native release validator (`test_assembler.py:132-225`).

The previously reviewed materialization and queue sections remain textually unchanged apart from line displacement: exact history/specialist/random indexing, 6+2+2 derivative creation, `validate_wide_inputs` handling, native smoke/Discrete/mesh job ordering, and final exact jobs equality are still present (`assemble_r81_engineering_release.py:201-274`). The generated 6+2+2 materializer fixture was therefore not repeated.

## Validation

- Corrected assembler SHA-256: `61e7c42d53f4ea7c6b491fe83707b5cf5ddea27c287aa12faa5d6a16999cfa27`.
- Versioned correction receipt SHA-256: `f882d609de7f0b44c11005e114814fdeadd4ed77256b4de2d089452770bc36a2`.
- Two affected implementation tests: `2 passed in 8.95s`.
- Adapted independent adversarial fixture only: `1 passed in 2.06s`.
- The original preparation receipt and original independent review receipt remain byte-preserved.
- The original independent review fixture is also restored byte-for-byte; the corrected expectation lives in `test_review_v002.py`.
- `r81_prior_recipe.py`, `r81_worker_entry.py`, `prepare_symmetry_filter.py`, `dedust.py`, and the tracked wide profile retain the previously reviewed hashes and show no scoped tracked diff.

## Remaining limits

The actual native exact-5,000/zero-pending gate cannot run at the documented current 4,243 count. The real prior preflight, private/NAS output creation, controller materialization, immutable real candidate validation, three-host CheckOnly, worker start, HFSS, and final engineering comparison remain unexecuted.

The earlier provenance and portability notes remain operational limits: the assembler must stay under the documented repository `tmp` path; the absolute dataset/share path must resolve consistently for worker handoff; and the untracked assembler plus `r81_prior_recipe.py` are recorded in the preparation receipt after assembly rather than belonging to native44 `RUNTIME_FILES`. The observed reviewed helper hashes are clean, but actual operators should still bind the reviewed package bytes before use.

No production/NAS/prior preparation, training, model forward, HFSS, queue, marker, process, or Git action was performed during this re-review.
