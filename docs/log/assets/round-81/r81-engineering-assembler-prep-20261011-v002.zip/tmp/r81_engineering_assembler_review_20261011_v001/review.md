# Independent bounded review: R81 EngineeringOnly assembler

## Outcome

The offline assembly sequence is structurally consistent with the current native44 worker contract, but the assembler is **not ready for an actual R81 preparation run yet**. One fail-closed validation defect should be corrected first: the supplied masked-prior config is not required to equal the canonical masked-prior recipe outside four production override keys.

No production preparation, NAS access, prior load, training, model forward, HFSS, process launch, queue claim, marker operation, or Git action was performed. The live R80 run and its 19 sources were not inspected or changed. The documented current count remains 4,243 rather than 5,000, so actual execution remains gated independently of this review.

## Finding

### F1 — High: masked-prior recipe drift is accepted

`_validated_configs` compares the supplied wide and prior configs only for `measurement`, `score_spec`, and `runtime`; checks identity against the supplied wide config; checks the manifest digest constant; and checks only the four keys in `PRODUCTION_OVERRIDES` (`assemble_r81_engineering_release.py:161-182`). It does not require the rest of `prior["exploration"]` to equal the tracked wide base or the output of `r81_prior_recipe.build_recipe`.

The review fixture changed only `exploration.seed`, recomputed the caller-supplied file SHA-256, and `_validated_configs` accepted it. Other validated but noncanonical fields such as `candidate_pool_size`, `hidden_dims`, `batch_train_size`, `learning_rate`, and `geometry_profile` are similarly outside this equality gate. Some size/arm mutations would fail later, after output creation, but valid seed or training-field drift can survive preparation.

This conflicts with the stated frozen masked-prior recipe and makes the caller-provided config/hash authoritative instead of the canonical recipe. Before actual execution, compare the complete validated prior config against the canonical recipe built from the tracked wide base plus the supplied absolute prior paths, or equivalently compare every non-path field and the exact `filter_prior` schema/digest. Add a regression showing that drift in a non-override exploration field is rejected before any destination is created.

## Verified contracts

- Runtime binding and native R80 exact-5,000/zero-pending validation run before `dataset_root.mkdir()` (`assemble_r81_engineering_release.py:343-353`). Native `_validate_r80` checks the watcher and action receipts for 5,000 valid unique points, zero pending points, and an empty planned queue (`r81_worker_entry.py:177-261`).
- Fresh destinations are checked up front, containment hazards among generated roots are rejected, and every output write is exclusive-create (`assemble_r81_engineering_release.py:118-146`). Failures after creation therefore leave a preserved prefix instead of silently reusing it.
- The actual `validate_wide_inputs` return value is `(configs, by_parent)`, where config values expose `.measurement` and `by_parent` values are parent-id dictionaries (`prepare_symmetry_filter.py:239-287`). The assembler's attribute access and `list(parent_map)` conversion are compatible (`assemble_r81_engineering_release.py:225-235`).
- The real materializer derives smoke parents `p0,p1,p20,p21,p40,p41`, then reuses `p0,p1` for both Discrete and mesh. The generated review fixture exercised the real `materialize_engineering_inputs`, `auxiliary_bundle`, and `validate_wide_inputs` path and obtained exact 6+2+2 counts while preserving the controller's masked-prior exploration mapping. The formal 60-row bundle remained unqueued.
- Native `jobs_add` appends exactly `input`, `store`, `prio`, `scope`, and the input-relative config snapshot; `machine=None` is omitted (`dedust.py:6145-6198`). The assembler calls it in smoke, Discrete, mesh order and then rejects any extra, reordered, or changed job (`assemble_r81_engineering_release.py:243-271`). Native release validation independently enforces the three exact roles, stores, counts, and the unqueued formal bundle (`r81_worker_entry.py:428-487`).
- Candidate bytes are exclusively written and passed through native `validate_release`; only a passing, no-HFSS report permits the receipt and final byte-identical release to be written. The final release is the last write (`assemble_r81_engineering_release.py:369-417`).
- The existing three bounded tests still pass. They validate orchestration and the native release schema, but their complete-shape case replaces `materialize_engineering_inputs` wholesale (`test_assembler.py:112-130`). The review's extra fixture closes the specific 6+2+2 derivation coverage gap without loading the real prior or executing a model.

## Provenance and portability limits

- Native runtime sources are commit-bound and checked clean before output creation and again during candidate validation. However, the untracked assembler and `script/r81_prior_recipe.py` are not members of native `RUNTIME_FILES` (`r81_worker_entry.py:30-36`). Their receipt hashes are sampled only after preparation (`assemble_r81_engineering_release.py:298-314,394-399`), so those hashes record end-state bytes rather than proving the exact imported bytes remained unchanged throughout the call. This is a bounded provenance limitation; verify the reviewed assembler/helper hashes immediately before execution or add a pre-call binding.
- `REPO = Path(__file__).resolve().parents[2]` is correct only when the directory remains at `<repository>/tmp/r81_engineering_release_assembler_20261011_v001`. The README command uses that layout, but the tool is not a standalone archive executable. A handoff should preserve this exact repository-relative extraction path.
- The release intentionally embeds an absolute `dataset_root`. Future NAS use therefore requires the same absolute/share path to resolve on every worker host. Source-binding paths in the preparation receipt are local evidence paths and are not worker-portable inputs.

## Bounded validation

- Existing suite: `3 passed in 9.03s`.
- Review fixture: `2 passed in 2.66s`.
- Assembler SHA-256: `5b08f2b4d1913b7e505a566b5e3dbd8dd471e0c82cb3cdd3113c84f8ef331e7c` (matches the implementation receipt).
- Native helper hashes observed unchanged: `r81_worker_entry.py` `cd578a22...023c`, `prepare_symmetry_filter.py` `e79cda67...a1f`, and `dedust.py` `4d203816...e05d`.

This is a preparation review only. Actual exact-5,000 evidence, the 21,034-row prior preflight, private/NAS path behavior, controller creation, host-local CheckOnly, worker handoff, and HFSS remain unverified.
