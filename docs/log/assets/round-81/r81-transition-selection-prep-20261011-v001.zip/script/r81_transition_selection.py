"""Opt-in measured-transition parent selection with replayable receipts.

This preparation wrapper never dispatches work.  It authenticates already
measured prior batches, freezes the small pre-selection metadata, invokes the
existing selector once, and writes a completion receipt only after replay.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
from collections import Counter
from pathlib import Path
from typing import Any, Mapping, Sequence

import numpy as np
import torch

from script import exploration as ex
from script import filter_training as ft
from script import profiled_batch as pb
from script import r81_transition_soft as soft


POLICY_ID = "r81_measured_transition_parent_selection_v1"
PLAN_KIND = "r81_transition_selection_plan_v1"
RECEIPT_KIND = "r81_transition_selection_receipt_v1"
FORBIDDEN_CANDIDATE_TRUTH = {
    "truth_kind", "hard_band_truth", "measured_wm_db", "transition", "labels",
    "frequencies_ghz", "raw_response_f32le_sha256",
}
REPO = Path(__file__).resolve().parents[1]


def _sha_bytes(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _producer() -> dict[str, str]:
    path = Path(__file__).resolve()
    return {"path": path.relative_to(REPO).as_posix(), "sha256": pb.file_sha256(path)}


def _write_json_x(path: Path, value: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False, sort_keys=True,
                  allow_nan=False)
        stream.write("\n")


def _write_bytes_x(path: Path, raw: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as stream:
        stream.write(raw)


def _read_json_once(path: Path) -> tuple[dict[str, Any], str]:
    raw = path.read_bytes()
    value = json.loads(raw.decode("utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"expected JSON object: {path}")
    return value, _sha_bytes(raw)


def _paths(work: Path, batch: int, evidence_dir: Path | None) -> dict[str, Path]:
    root = (evidence_dir or work / "transition_selection").resolve()
    stem = f"batch-{batch:03d}"
    return {
        "root": root,
        "state": root / f"{stem}-pre-state.json",
        "dataset": root / f"{stem}-pre-dataset.json",
        "plan": root / f"{stem}-plan.json",
        "receipt": root / f"{stem}-receipt.json",
    }


def _candidate_summary(row: Mapping[str, Any]) -> dict[str, Any]:
    keys = ("candidate_index", "candidate_group", "parent_id", "parent_source",
            "lineage_id", "source", "pattern_sha256", "canonical_group_id",
            "parent_truth_provenance")
    return {key: row.get(key) for key in keys}


def _selected_summary(row: Mapping[str, Any], *, batch: int, ordinal: int,
                      state: Mapping[str, Any], cfg: Mapping[str, Any],
                      model_hash: str) -> dict[str, Any]:
    """Canonical selected-row semantics produced by write_batch_bundle."""
    digest = row["pattern_sha256"]
    row_id = f"{state['id_prefix']}_b{batch:02d}_{ordinal:03d}_{digest[:8]}"
    pattern = np.asarray(row["pattern"], dtype="<f4").reshape(25, 25)
    manifest_row = {key: value for key, value in dict(row).items()
                    if key not in {"pattern", "seed_input"}}
    manifest_row.update({
        "id": row_id,
        "batch": batch,
        "pattern_file": f"{row_id}.pt",
        "pattern_sha256": digest,
        "model_hash": model_hash,
        "port": cfg["measurement"]["port"],
        "measurement_id": state["measurement_id"],
        "score_spec_id": state["score_spec_id"],
        "geometry_profile": cfg["exploration"]["geometry_profile"],
    })
    return {
        "manifest_row": manifest_row,
        "pattern_f32le_sha256": _sha_bytes(pattern.tobytes(order="C")),
    }


def _selector_replay(work: Path, batch: int, candidates: Sequence[Mapping[str, Any]],
                     exp: Mapping[str, Any]) -> tuple[list[dict[str, Any]], str,
                                                     dict[str, str]]:
    """Run the production prediction/arm helpers with immutable source checks."""
    model_dir = work / "models" / f"batch-{batch - 1:03d}"
    sources = [Path(ex.__file__).resolve(), Path(ft.__file__).resolve(),
               work / "config.yaml"] + [
        model_dir / f"member-{seed}.pt" for seed in exp["ensemble_seeds"]]
    before = {path.relative_to(REPO).as_posix() if path.is_relative_to(REPO)
              else str(path): pb.file_sha256(path) for path in sources}
    predictions, uncertainty, model_hash = ex.predict_ensemble(
        work, batch - 1, [row["pattern"] for row in candidates])
    selected = ex.select_candidate_arms(
        candidates, exp["later_arms"], seed=exp["seed"] + batch * 1009 + 1,
        mode=exp["mode"], predictions=predictions, uncertainty=uncertainty)
    after = {path.relative_to(REPO).as_posix() if path.is_relative_to(REPO)
             else str(path): pb.file_sha256(path) for path in sources}
    if after != before:
        raise ValueError("selector source/model bytes changed during deterministic replay")
    return selected, model_hash, before


def _parent_summary(row: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "id": row.get("id"),
        "pattern_sha256": ex.pattern_sha256(row["pattern"]),
        "source": row.get("source"),
        "parent_truth_provenance": row.get("parent_truth_provenance"),
    }


def _replay_candidate_pool(work: Path, batch: int, state: Mapping[str, Any],
                           context: Mapping[str, Any], exp: Mapping[str, Any]) \
        -> tuple[list[dict[str, Any]], list[dict[str, Any]], int]:
    saved_seed_paths = [(Path(value) if Path(value).is_absolute() else work / value)
                        for value in state.get("seed_inputs", [])]
    seeds = ex.load_seed_rows(saved_seed_paths)
    current = ex.load_scoped_parent_rows(work, through_batch=batch - 1)
    current, preference_order = ex._apply_measured_parent_context(current, context)
    parents = ex.mixed_diverse_parents(
        seeds, current, current_preference_order=preference_order)
    candidate_seed = int(exp["seed"]) + batch * 1009
    candidates = ex.generate_candidates(
        parents, int(exp["candidate_pool_size"]), seed=candidate_seed, single=False,
        emit_parent_truth_provenance=True)
    return parents, candidates, candidate_seed


def _make_plan(work: Path, batch: int, state_raw: bytes, dataset_raw: bytes, *,
               allow_dataset_extension: bool) -> dict[str, Any]:
    state = json.loads(state_raw.decode("utf-8"))
    if (not isinstance(state, dict) or state.get("next_batch") != batch
            or set(state.get("batches", {})) != {str(i) for i in range(1, batch)}
            or batch <= 1):
        raise ValueError("frozen state is not the exact later-batch predecessor")
    cfg = ex.validate_exploration_config(ex._load_yaml(work / "config.yaml"))
    exp = cfg["exploration"]
    if (exp.get("mode") != "dual_margin5"
            or exp.get("training_protocol") != ft.PROTOCOL
            or exp.get("candidate_pool_size") != 1024
            or exp.get("batch_size") != 60
            or exp.get("later_arms") != {
                "best_min_margin": 20, "uncertainty": 20, "random": 20}):
        raise ValueError("transition selection requires the exact formal R81 pool and quotas")

    payloads = []
    record_sidecars: dict[str, str] = {}
    records = []
    predecessor_model_hash = None
    for previous in range(1, batch):
        info = state["batches"][str(previous)]
        if not info.get("feedback_audit") or not info.get("trained_model_dir"):
            raise ValueError("each prior batch needs completed feedback and training")
        payload = soft.build_authenticated_payload(
            work, previous, state_bytes=state_raw,
            dataset_manifest_bytes=dataset_raw,
            allow_dataset_extension=allow_dataset_extension)
        payloads.append(payload)
        for record in payload["records"]:
            if record["id"] in record_sidecars:
                raise ValueError("measured row id appears in multiple prior batches")
            record_sidecars[record["id"]] = payload["content_id"]
            records.append(record)
        _training_plan, summary = ft.validate_model_evidence(work, previous, cfg, state)
        if previous == batch - 1:
            predecessor_model_hash = ex._ensemble_hash(
                [work / relative for relative in summary["model_files"]])

    ranking = soft.rank_measured_records(records)
    ranking_unsigned = {
        "policy_id": soft.POLICY_ID,
        "sidecar_content_ids": [payload["content_id"] for payload in payloads],
        "ranking": ranking,
    }
    ranking_content_id = ex.content_id(ranking_unsigned)
    records_by_id = {record["id"]: record for record in records}
    parent_map: dict[str, dict[str, Any]] = {}
    for ordinal, ranked in enumerate(ranking):
        record = records_by_id[ranked["id"]]
        digest = ranked["pattern_sha256"]
        if digest in parent_map:
            raise ValueError("measured parent pattern is duplicated")
        parent_map[digest] = {
            "measured_row_id": ranked["id"],
            "measured_batch": int(record["batch"]),
            "parent_pattern_sha256": digest,
            "sidecar_content_id": record_sidecars[ranked["id"]],
            "combined_ranking_content_id": ranking_content_id,
            "preference_ordinal": ordinal,
        }
    context = {
        "policy_id": POLICY_ID,
        "combined_ranking_content_id": ranking_content_id,
        "parents": parent_map,
    }

    parents, candidates, candidate_seed = _replay_candidate_pool(
        work, batch, state, context, exp)
    candidate_summaries = [_candidate_summary(row) for row in candidates]
    if len({row["pattern_sha256"] for row in candidate_summaries}) != 1024:
        raise ValueError("transition candidate pool is not 1024 unique patterns")
    groups = Counter(row["candidate_group"] for row in candidate_summaries)
    if groups != {"fresh_random": 512, "parent_variant": 512}:
        raise ValueError("transition candidate strata differ from 512/512")

    selected, replayed_model_hash, selector_source_hashes = _selector_replay(
        work, batch, candidates, exp)
    if replayed_model_hash != predecessor_model_hash:
        raise ValueError("selector replay model differs from authenticated predecessor")
    expected_selection = [
        _selected_summary(row, batch=batch, ordinal=ordinal,
                          state=state, cfg=cfg, model_hash=predecessor_model_hash)
        for ordinal, row in enumerate(selected)
    ]

    plan: dict[str, Any] = {
        "schema_version": 1,
        "kind": PLAN_KIND,
        "policy": {
            "id": POLICY_ID,
            "measured_parent_only": True,
            "max_wm_tradeoff_db": soft.DEFAULT_MAX_WM_TRADEOFF_DB,
            "cap_is_noise_estimate": False,
            "candidate_sm_transition_output": False,
            "transition_hard_gate": False,
        },
        "work_dir": str(work),
        "batch": batch,
        "pre_state_sha256": _sha_bytes(state_raw),
        "pre_dataset_sha256": _sha_bytes(dataset_raw),
        "sidecar_payloads": payloads,
        "combined_ranking": ranking_unsigned,
        "combined_ranking_content_id": ranking_content_id,
        "measured_parent_context": context,
        "selected_parents": [_parent_summary(row) for row in parents],
        "candidate_pool": candidate_summaries,
        "candidate_pool_content_id": ex.content_id(candidate_summaries),
        "expected_selection": expected_selection,
        "expected_selection_content_id": ex.content_id(expected_selection),
        "candidate_seed": candidate_seed,
        "predecessor_model_hash": predecessor_model_hash,
        "selector_source_hashes": selector_source_hashes,
        "selection_producer": _producer(),
        "integration": "opt_in_parent_preference_only_five_margin_candidate_selection_unchanged",
    }
    plan["content_id"] = ex.content_id(plan)
    return plan


def _validate_plan_files(work: Path, paths: Mapping[str, Path], *,
                         allow_dataset_extension: bool) -> tuple[dict[str, Any], bytes, bytes, str]:
    state_raw = paths["state"].read_bytes()
    dataset_raw = paths["dataset"].read_bytes()
    plan, plan_sha = _read_json_once(paths["plan"])
    claimed = plan.get("content_id")
    unsigned = dict(plan); unsigned.pop("content_id", None)
    if claimed != ex.content_id(unsigned):
        raise ValueError("transition selection plan content id changed")
    if (plan.get("pre_state_sha256") != _sha_bytes(state_raw)
            or plan.get("pre_dataset_sha256") != _sha_bytes(dataset_raw)):
        raise ValueError("transition selection snapshots differ from the plan")
    expected = _make_plan(
        work, int(plan.get("batch")), state_raw, dataset_raw,
        allow_dataset_extension=allow_dataset_extension)
    if plan != expected:
        raise ValueError("transition selection plan differs from authenticated replay")
    return plan, state_raw, dataset_raw, plan_sha


def _expected_successor(pre: Mapping[str, Any], batch: int, input_dir: Path,
                        model_hash: str, work: Path) -> dict[str, Any]:
    expected = copy.deepcopy(dict(pre))
    relative = input_dir.relative_to(work)
    expected["batches"][str(batch)] = {
        "input_dir": relative.as_posix(),
        "selected": 60,
        "model_hash": model_hash,
        "feedback_audit": None,
        "trained_model_dir": None,
        "input_manifest_sha256": pb.file_sha256(input_dir / "manifest.json"),
    }
    expected["next_batch"] = batch + 1
    return expected


def _validate_successor(pre: Mapping[str, Any], post: Mapping[str, Any], batch: int,
                        input_dir: Path, model_hash: str, work: Path) -> None:
    expected = _expected_successor(pre, batch, input_dir, model_hash, work)
    if post != expected:
        raise ValueError("post-selection state is not the exact semantic successor")


def _validate_bundle(work: Path, plan: Mapping[str, Any], input_dir: Path) -> list[dict[str, Any]]:
    batch = int(plan["batch"])
    if input_dir != work / "batches" / f"batch-{batch:03d}_input":
        raise ValueError("selected bundle path is not the canonical batch input")
    state = ex._read_json(work / "state.json")
    info = state["batches"].get(str(batch))
    if not isinstance(info, dict) or ex._safe_input_path(work, info["input_dir"]) != input_dir:
        raise ValueError("selected bundle is not the state-bound input directory")
    rows = ex._manifest_rows(input_dir / "manifest.json")
    if (len(rows) != 60 or len({row.get("id") for row in rows}) != 60
            or len({row.get("pattern_sha256") for row in rows}) != 60
            or Counter(row.get("selection_arm") for row in rows) != {
                "best_min_margin": 20, "uncertainty": 20, "random": 20}):
        raise ValueError("selected bundle does not preserve formal R81 quotas")
    pool = {row["pattern_sha256"]: row for row in plan["candidate_pool"]}
    expected_rows = plan.get("expected_selection")
    if (not isinstance(expected_rows, list) or len(expected_rows) != 60
            or plan.get("expected_selection_content_id") != ex.content_id(expected_rows)):
        raise ValueError("authenticated expected selection differs")
    for ordinal, (row, selected_expected) in enumerate(zip(rows, expected_rows)):
        if row["pattern_sha256"] not in pool:
            raise ValueError("selected row is absent from the authenticated candidate pool")
        expected = pool[row["pattern_sha256"]]
        if any(row.get(key) != value for key, value in expected.items()):
            raise ValueError("selected row parent/provenance differs from its candidate")
        if (set(selected_expected) != {"manifest_row", "pattern_f32le_sha256"}
                or row != selected_expected["manifest_row"]):
            raise ValueError(f"selected row {ordinal} differs from deterministic selector replay")
        pattern_path = input_dir / row["pattern_file"]
        pattern_before = pb.file_sha256(pattern_path)
        pattern = torch.load(pattern_path, weights_only=True, map_location="cpu")
        pattern_after = pb.file_sha256(pattern_path)
        actual_pattern_bytes = np.asarray(pattern, dtype="<f4").reshape(25, 25).tobytes(order="C")
        if (pattern_before != pattern_after
                or _sha_bytes(actual_pattern_bytes) != selected_expected["pattern_f32le_sha256"]
                or ex.pattern_sha256(pattern) != row["pattern_sha256"]):
            raise ValueError(f"selected row {ordinal} pattern bytes differ from replay")
        if any(key in row for key in FORBIDDEN_CANDIDATE_TRUTH):
            raise ValueError("unmeasured candidate inherited measured parent truth")
        proof = row.get("parent_truth_provenance")
        if row.get("candidate_group") == "fresh_random" and proof is not None:
            raise ValueError("fresh candidate must have explicit null parent truth provenance")
        if proof is not None and set(proof) != {
                "measured_row_id", "measured_batch", "parent_pattern_sha256",
                "sidecar_content_id", "combined_ranking_content_id", "preference_ordinal"}:
            raise ValueError("candidate parent truth provenance contains unsupported fields")
        if row.get("model_hash") != plan["predecessor_model_hash"]:
            raise ValueError("selected row model hash differs from predecessor")
    return rows


def _validate_current_state(work: Path, pre: Mapping[str, Any], current: Mapping[str, Any],
                            batch: int) -> None:
    """Allow only the controller's contiguous later feedback/model lifecycle."""
    if set(current) != set(pre):
        raise ValueError("current state top-level schema differs from frozen predecessor")
    stable_top = set(pre) - {"batches", "next_batch", "measured_budget"}
    if any(current[key] != pre[key] for key in stable_top):
        raise ValueError("current state stable fields differ from frozen predecessor")
    next_batch = current.get("next_batch")
    if (isinstance(next_batch, bool) or not isinstance(next_batch, int)
            or next_batch < batch + 1 or next_batch > int(pre["max_batches"]) + 1
            or set(current.get("batches", {})) !=
            {str(value) for value in range(1, next_batch)}):
        raise ValueError("current state batch lifecycle is not exact and contiguous")
    manifest = ex._manifest_rows(work / "dataset_manifest.json")
    if current.get("measured_budget") != len(manifest):
        raise ValueError("current state measured budget differs from dataset manifest")
    base_keys = {"input_dir", "selected", "model_hash", "feedback_audit",
                 "trained_model_dir", "input_manifest_sha256"}
    cfg = ex.validate_exploration_config(ex._load_yaml(work / "config.yaml"))
    for key, info in current["batches"].items():
        if not isinstance(info, dict):
            raise ValueError(f"current state batch {key} is not an object")
        allowed = base_keys | ({"feedback_audit_sha256"} if info.get("feedback_audit") else set())
        if set(info) != allowed:
            raise ValueError(f"current state batch {key} schema differs")
        if info.get("feedback_audit") is None and (
                info.get("trained_model_dir") is not None or "feedback_audit_sha256" in info):
            raise ValueError(f"current state batch {key} advances without feedback")
        index = int(key)
        input_dir = ex._safe_input_path(work, info["input_dir"])
        if (input_dir != work / "batches" / f"batch-{index:03d}_input"
                or info.get("selected") != 60
                or info.get("input_manifest_sha256") !=
                pb.file_sha256(input_dir / "manifest.json")):
            raise ValueError(f"current state batch {key} input binding differs")
        if index == 1:
            expected_model_hash = None
        else:
            _training_plan, summary = ft.validate_model_evidence(work, index - 1, cfg, current)
            expected_model_hash = ex._ensemble_hash(
                [work / relative for relative in summary["model_files"]])
        if info.get("model_hash") != expected_model_hash:
            raise ValueError(f"current state batch {key} model lineage differs")
        if info.get("feedback_audit"):
            ft.validate_feedback_binding(work, index, current)
            if info.get("trained_model_dir"):
                ft.validate_model_evidence(work, index, cfg, current)
        if index < next_batch - 1 and not info.get("trained_model_dir"):
            raise ValueError(f"current state batch {key} lacks training before successor")


def finalize_existing(work_dir: str | Path, batch: int, *,
                      evidence_dir: str | Path | None = None) -> Path:
    work = Path(work_dir).resolve()
    paths = _paths(work, batch, Path(evidence_dir) if evidence_dir else None)
    if paths["receipt"].exists():
        raise FileExistsError(f"refusing to overwrite selection receipt: {paths['receipt']}")
    plan, state_raw, _dataset_raw, plan_sha = _validate_plan_files(
        work, paths, allow_dataset_extension=True)
    pre = json.loads(state_raw.decode("utf-8"))
    post_raw = (work / "state.json").read_bytes()
    post = json.loads(post_raw.decode("utf-8"))
    info = post.get("batches", {}).get(str(batch))
    if not isinstance(info, dict):
        raise ValueError("selected batch is absent from current state")
    input_dir = ex._safe_input_path(work, info["input_dir"])
    _validate_successor(pre, post, batch, input_dir, plan["predecessor_model_hash"], work)
    rows = _validate_bundle(work, plan, input_dir)
    post_sha_after = pb.file_sha256(work / "state.json")
    if post_sha_after != _sha_bytes(post_raw):
        raise ValueError("state changed during transition receipt validation")
    input_files = {path.name: pb.file_sha256(path)
                   for path in sorted(input_dir.iterdir()) if path.is_file()}
    receipt: dict[str, Any] = {
        "schema_version": 1,
        "kind": RECEIPT_KIND,
        "status": "completed_replayed_transition_parent_selection",
        "policy_id": POLICY_ID,
        "work_dir": str(work),
        "batch": batch,
        "plan_path": paths["plan"].relative_to(work).as_posix(),
        "plan_sha256": plan_sha,
        "plan_content_id": plan["content_id"],
        "pre_state_sha256": plan["pre_state_sha256"],
        "post_state_sha256": post_sha_after,
        "input_dir": input_dir.relative_to(work).as_posix(),
        "input_files": input_files,
        "input_manifest_sha256": pb.file_sha256(input_dir / "manifest.json"),
        "candidate_pool_content_id": plan["candidate_pool_content_id"],
        "combined_ranking_content_id": plan["combined_ranking_content_id"],
        "selected_pattern_sha256": [row["pattern_sha256"] for row in rows],
        "arm_counts": dict(Counter(row["selection_arm"] for row in rows)),
        "completion_written_last": True,
        "candidate_sm_or_arm_ranking_changed": False,
        "opt_in_parent_selection_changed": True,
    }
    receipt["content_id"] = ex.content_id(receipt)
    _write_json_x(paths["receipt"], receipt)
    return paths["receipt"]


def select_with_transition(work_dir: str | Path, batch: int, *,
                           evidence_dir: str | Path | None = None) -> Path:
    work = Path(work_dir).resolve()
    paths = _paths(work, batch, Path(evidence_dir) if evidence_dir else None)
    if any(paths[key].exists() for key in ("state", "dataset", "plan", "receipt")):
        raise FileExistsError("refusing to reuse transition selection evidence paths")
    state_raw = (work / "state.json").read_bytes()
    dataset_raw = (work / "dataset_manifest.json").read_bytes()
    plan = _make_plan(work, batch, state_raw, dataset_raw, allow_dataset_extension=False)
    if (pb.file_sha256(work / "state.json") != _sha_bytes(state_raw)
            or pb.file_sha256(work / "dataset_manifest.json") != _sha_bytes(dataset_raw)):
        raise ValueError("selection inputs changed during transition plan validation")
    _write_bytes_x(paths["state"], state_raw)
    _write_bytes_x(paths["dataset"], dataset_raw)
    _write_json_x(paths["plan"], plan)
    ex.select_batch(work, batch, measured_parent_context=plan["measured_parent_context"])
    return finalize_existing(work, batch, evidence_dir=paths["root"])


def validate_completed_receipt(work_dir: str | Path, receipt_path: str | Path, *,
                               allow_later_lifecycle: bool = True) -> dict[str, Any]:
    work = Path(work_dir).resolve()
    receipt_file = Path(receipt_path).resolve()
    receipt, receipt_sha = _read_json_once(receipt_file)
    claimed = receipt.get("content_id")
    unsigned = dict(receipt); unsigned.pop("content_id", None)
    expected_receipt_keys = {
        "schema_version", "kind", "status", "policy_id", "work_dir", "batch",
        "plan_path", "plan_sha256", "plan_content_id", "pre_state_sha256",
        "post_state_sha256", "input_dir", "input_files", "input_manifest_sha256",
        "candidate_pool_content_id", "combined_ranking_content_id",
        "selected_pattern_sha256", "arm_counts", "completion_written_last",
        "candidate_sm_or_arm_ranking_changed", "opt_in_parent_selection_changed",
        "content_id",
    }
    if (set(receipt) != expected_receipt_keys or receipt.get("schema_version") != 1
            or receipt.get("kind") != RECEIPT_KIND
            or receipt.get("status") != "completed_replayed_transition_parent_selection"
            or receipt.get("policy_id") != POLICY_ID
            or receipt.get("work_dir") != str(work)
            or receipt.get("completion_written_last") is not True
            or receipt.get("candidate_sm_or_arm_ranking_changed") is not False
            or receipt.get("opt_in_parent_selection_changed") is not True
            or claimed != ex.content_id(unsigned)):
        raise ValueError("transition selection receipt content differs")
    batch = int(receipt["batch"])
    paths = _paths(work, batch, receipt_file.parent)
    if paths["receipt"] != receipt_file:
        raise ValueError("transition selection receipt path is not canonical")
    plan, state_raw, _dataset_raw, plan_sha = _validate_plan_files(
        work, paths, allow_dataset_extension=allow_later_lifecycle)
    if (receipt.get("plan_sha256") != plan_sha
            or receipt.get("plan_content_id") != plan["content_id"]):
        raise ValueError("transition selection receipt plan binding differs")
    current_state_raw = (work / "state.json").read_bytes()
    current_dataset_raw = (work / "dataset_manifest.json").read_bytes()
    current = json.loads(current_state_raw.decode("utf-8"))
    if not isinstance(current, dict):
        raise ValueError("current state is not a JSON object")
    info = current.get("batches", {}).get(str(batch))
    if not isinstance(info, dict):
        raise ValueError("receipt batch is absent from current state")
    input_dir = ex._safe_input_path(work, info["input_dir"])
    rows = _validate_bundle(work, plan, input_dir)
    pre = json.loads(state_raw.decode("utf-8"))
    _validate_current_state(work, pre, current, batch)
    expected_post = _expected_successor(
        pre, batch, input_dir, plan["predecessor_model_hash"], work)
    expected_post_raw = json.dumps(
        expected_post, indent=2, ensure_ascii=False, sort_keys=True).replace(
            "\n", os.linesep).encode("utf-8")
    if (receipt.get("pre_state_sha256") != plan["pre_state_sha256"]
            or receipt.get("plan_path") != paths["plan"].relative_to(work).as_posix()
            or receipt.get("input_dir") != input_dir.relative_to(work).as_posix()
            or receipt.get("input_manifest_sha256") != pb.file_sha256(input_dir / "manifest.json")
            or receipt.get("arm_counts") != dict(Counter(row["selection_arm"] for row in rows))
            or receipt.get("post_state_sha256") != _sha_bytes(expected_post_raw)):
        raise ValueError("receipt post-state hash is not the exact semantic successor")
    stable = {key: info.get(key) for key in
              ("input_dir", "selected", "model_hash", "input_manifest_sha256")}
    expected_stable = {
        "input_dir": input_dir.relative_to(work).as_posix(), "selected": 60,
        "model_hash": plan["predecessor_model_hash"],
        "input_manifest_sha256": pb.file_sha256(input_dir / "manifest.json")}
    if stable != expected_stable:
        raise ValueError("current state changed selection-stable batch fields")
    if allow_later_lifecycle and info.get("feedback_audit"):
        ft.validate_feedback_binding(work, batch, current)
        if info.get("trained_model_dir"):
            cfg = ex.validate_exploration_config(ex._load_yaml(work / "config.yaml"))
            ft.validate_model_evidence(work, batch, cfg, current)
    elif allow_later_lifecycle and info.get("trained_model_dir"):
        raise ValueError("trained model exists without validated feedback")
    else:
        post = copy.deepcopy(pre)
        post["batches"][str(batch)] = dict(info)
        post["next_batch"] = batch + 1
        _validate_successor(pre, post, batch, input_dir, plan["predecessor_model_hash"], work)
    expected_files = {path.name: pb.file_sha256(path)
                      for path in sorted(input_dir.iterdir()) if path.is_file()}
    if (receipt.get("input_files") != expected_files
            or receipt.get("selected_pattern_sha256") !=
            [row["pattern_sha256"] for row in rows]
            or receipt.get("candidate_pool_content_id") != plan["candidate_pool_content_id"]
            or receipt.get("combined_ranking_content_id") != plan["combined_ranking_content_id"]
            or pb.file_sha256(receipt_file) != receipt_sha):
        raise ValueError("transition selection completed evidence differs")
    if (pb.file_sha256(work / "state.json") != _sha_bytes(current_state_raw)
            or pb.file_sha256(work / "dataset_manifest.json") !=
            _sha_bytes(current_dataset_raw)):
        raise ValueError("current lifecycle sources changed during receipt validation")
    return receipt


def make_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    for name in ("select", "finalize"):
        item = sub.add_parser(name)
        item.add_argument("--work-dir", required=True, type=Path)
        item.add_argument("--batch", required=True, type=int)
        item.add_argument("--evidence-dir", type=Path)
    check = sub.add_parser("validate")
    check.add_argument("--work-dir", required=True, type=Path)
    check.add_argument("--receipt", required=True, type=Path)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = make_parser().parse_args(argv)
    if args.command == "select":
        path = select_with_transition(args.work_dir, args.batch,
                                      evidence_dir=args.evidence_dir)
    elif args.command == "finalize":
        path = finalize_existing(args.work_dir, args.batch,
                                 evidence_dir=args.evidence_dir)
    else:
        value = validate_completed_receipt(args.work_dir, args.receipt)
        print(json.dumps(value, sort_keys=True))
        return 0
    print(path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
