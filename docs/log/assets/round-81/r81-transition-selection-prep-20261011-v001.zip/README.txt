R81 transition selection preparation only.
Source is exact Git blob content from 7928468be57fa86dc81015320d948b98d4d105d9.
Do not extract over the live GAN checkout. The R80 controller sources remain unchanged.
Merge only after the R80 closeout/native binding handoff; obtain an actual independent R81 release.
Measured transition parent preference is soft, outside five-margin WM, with an uncalibrated 0.1 dB tradeoff cap.
Candidate ranking remains the existing five-margin ensemble; it has no transition-output head.
Exact raw CPU prediction replay has not been verified on all three worker environments.
Review files describe their respective pre-commit cutoffs; no full validate_release/HFSS result exists.
