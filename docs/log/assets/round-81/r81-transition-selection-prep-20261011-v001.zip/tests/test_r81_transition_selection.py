"""Focused generated checks for opt-in measured-transition parent selection."""
from __future__ import annotations

import json
import shutil
from collections import Counter
from pathlib import Path

import numpy as np
import pytest
import torch
import yaml

from script import exploration as ex
from script import filter_training as ft
from script import profiled_batch as pb
from script import r81_transition_selection as selection
from script import r81_transition_soft as soft
from script import r81_worker_entry as entry
from antenna.measurement import measurement_id, score_spec_id


REPO = Path(__file__).parents[1]


def _response(index: int) -> torch.Tensor:
    freqs = soft.EXPECTED_FREQS
    s21 = np.full(49, -25.0, dtype=np.float32)
    s21[(freqs >= 26.0) & (freqs <= 30.0)] = -2.0 + (index % 3) * 0.02
    left = (freqs >= 20.0) & (freqs <= 26.0)
    right = (freqs >= 30.0) & (freqs <= 36.0)
    s21[left] = np.linspace(-25.0, s21[left][-1], int(left.sum()), dtype=np.float32)
    s21[right] = np.linspace(s21[right][0], -25.0, int(right.sum()), dtype=np.float32)
    if index % 2:
        li = np.flatnonzero((freqs > 20.0) & (freqs < 26.0))
        ri = np.flatnonzero((freqs > 30.0) & (freqs < 36.0))
        s21[li] += np.where(np.arange(len(li)) % 2, 1.0, -1.0).astype(np.float32)
        s21[ri] += np.where(np.arange(len(ri)) % 2, -1.0, 1.0).astype(np.float32)
    return torch.stack((torch.full((49,), -12.0), torch.from_numpy(s21),
                        torch.full((49,), -12.0)))


def _prepare_formal_lifecycle(tmp_path: Path) -> tuple[Path, Path]:
    cfg = yaml.safe_load((REPO / "configs/dual_r81_wide_filter.yaml").read_text(encoding="utf-8"))
    prior = tmp_path / "prior"; prior.mkdir()
    seeds = tmp_path / "seeds"; seeds.mkdir()
    prior_rows, seed_rows = [], []
    for index in range(60):
        pattern = torch.tensor(ex.enforce_dual_geometry(
            np.random.default_rng(index + 8101).random((25, 25)) < 0.5), dtype=torch.float32)
        old_response = torch.stack((torch.full((17,), -12.0), torch.full((17,), -2.0),
                                    torch.full((17,), -12.0)))
        old = prior / f"old-{index}.pt"
        torch.save((pattern, old_response), old)
        digest = pb.pattern_sha256(pattern)
        prior_rows.append({
            "id": f"old-{index}", "sample_file": old.name,
            "sample_sha256": pb.file_sha256(old), "pattern_sha256": digest,
            "lineage_id": f"family-{index}", "canonical_group_id": f"family-{index}",
            "labels": list(soft.EXPECTED_LABELS),
            "freqs_ghz": np.arange(24.0, 32.1, 0.5).tolist(),
            "geometry": cfg["measurement"]["geometry"],
            "provenance": {"kind": "generated_integration_fixture"},
        })
        torch.save(pattern, seeds / f"seed-{index}.pt")
        group = "history" if index < 20 else ("specialist" if index < 40 else "random")
        seed_rows.append({
            "id": f"seed-{index}", "pattern_file": f"seed-{index}.pt",
            "pattern_sha256": digest, "lineage_id": f"family-{index}",
            "source_group": group,
        })
    pb.atomic_json(prior / "manifest.json", prior_rows)
    pb.atomic_json(seeds / "manifest.json", seed_rows)
    cfg["exploration"].update(
        training_protocol=ft.PROTOCOL, hidden_dims=[8], epochs=1, pretrain_epochs=1,
        batch_train_size=16, holdout_fraction=0.2,
        filter_prior={"manifest": str(prior / "manifest.json"), "sample_root": str(prior),
                      "expected_manifest_sha256": pb.file_sha256(prior / "manifest.json")},
    )
    config = tmp_path / "config.yaml"
    config.write_text(yaml.safe_dump(cfg, sort_keys=False), encoding="utf-8")
    dataset = tmp_path / "dataset"; dataset.mkdir()
    work = tmp_path / "work"
    ex.prepare_run(config, dataset, work, [seeds])
    input_dir = work / "batches/batch-001_input"
    profile = pb.load_profile_config(input_dir / "config.yaml")
    store = dataset / "batch-001"
    rows = pb.prepare_store(input_dir, store, profile)
    results = {}
    for index, row in enumerate(rows):
        pattern = torch.load(input_dir / row["pattern_file"], weights_only=True)
        response = _response(index)
        entry = pb.observation(response, None, row, pattern, profile, elapsed=0.01)
        sample = store / entry["sample_file"]
        torch.save((pattern, response), sample)
        entry["sample_sha256"] = pb.file_sha256(sample)
        results[row["id"]] = entry
    pb.atomic_json(store / "results.json", results)
    ex.import_feedback(work, 1, store / "results.json")
    ex.train_models(work, 1)
    return work, dataset


def _complete_feedback(work: Path, dataset: Path, batch: int) -> None:
    input_dir = work / f"batches/batch-{batch:03d}_input"
    profile = pb.load_profile_config(input_dir / "config.yaml")
    store = dataset / f"batch-{batch:03d}"
    rows = pb.prepare_store(input_dir, store, profile)
    results = {}
    for index, row in enumerate(rows):
        pattern = torch.load(input_dir / row["pattern_file"], weights_only=True)
        response = _response(index + batch * 100)
        entry = pb.observation(response, None, row, pattern, profile, elapsed=0.01)
        sample = store / entry["sample_file"]
        torch.save((pattern, response), sample)
        entry["sample_sha256"] = pb.file_sha256(sample)
        results[row["id"]] = entry
    pb.atomic_json(store / "results.json", results)
    ex.import_feedback(work, batch, store / "results.json")
    ex.train_models(work, batch)


def test_optional_preference_changes_first_and_only_geometry_ties():
    patterns = [np.zeros((25, 25), bool) for _ in range(3)]
    patterns[0][0, 0] = True
    patterns[1][0, 1] = True
    patterns[2][0, :2] = True
    hashes = [ex.pattern_sha256(pattern) for pattern in patterns]
    default = ex.maxmin_hamming_indices(patterns, 3)
    preferred = ex.maxmin_hamming_indices(
        patterns, 3, preference_order={hashes[0]: 2, hashes[1]: 0, hashes[2]: 1})
    assert default[0] == min(range(3), key=lambda i: hashes[i])
    assert preferred[0] == 1
    assert preferred[1] == 0  # distance two beats the better-ranked distance-one row


def test_default_candidate_generation_has_no_new_manifest_field():
    pattern = ex.enforce_dual_geometry(np.random.default_rng(7).random((25, 25)) < 0.5)
    rows = [{"id": "seed", "pattern": pattern, "pattern_sha256": ex.pattern_sha256(pattern)}]
    candidates = ex.generate_candidates(rows, 8, seed=3, single=False)
    assert all("parent_truth_provenance" not in row for row in candidates)
    opt_in = ex.generate_candidates(rows, 8, seed=3, single=False,
                                    emit_parent_truth_provenance=True)
    assert all("parent_truth_provenance" in row for row in opt_in)
    assert all(row["parent_truth_provenance"] is None for row in opt_in)


def test_future_runtime_closure_is_opt_in_and_default_closure_is_unchanged(monkeypatch):
    digest = "b" * 64
    monkeypatch.setattr(entry, "_git_is_ancestor", lambda _commit: True)
    monkeypatch.setattr(entry, "_git_blob_sha", lambda _commit, _path: digest)
    monkeypatch.setattr(entry, "_git_path_clean", lambda _commit, _path: True)
    legacy = {"git_commit": "a" * 40,
              "files": {path: digest for path in entry.RUNTIME_FILES}}
    entry._validate_runtime(legacy)
    with pytest.raises(ValueError, match="producer set"):
        entry._validate_runtime(legacy, require_transition=True)
    future = {"git_commit": "a" * 40,
              "files": {path: digest for path in entry.TRANSITION_RUNTIME_FILES}}
    entry._validate_runtime(future, require_transition=True)


def test_complete_opt_in_lifecycle_and_authenticated_replay(tmp_path):
    work, dataset = _prepare_formal_lifecycle(tmp_path)
    receipt_path = selection.select_with_transition(work, 2)
    receipt = selection.validate_completed_receipt(work, receipt_path)
    assert receipt["status"] == "completed_replayed_transition_parent_selection"
    plan = pb.read_json(work / receipt["plan_path"])
    assert len(plan["candidate_pool"]) == 1024
    assert sum(row["candidate_group"] == "fresh_random" for row in plan["candidate_pool"]) == 512
    assert len(plan["selected_parents"]) == 32
    assert plan["selected_parents"][0]["parent_truth_provenance"]["preference_ordinal"] == 0
    # This fixture measures every supplied seed in batch 1, so the existing
    # de-duplication leaves no unmeasured seed parent and uses 32 current rows.
    assert all(row["parent_truth_provenance"] is not None
               for row in plan["selected_parents"])
    rows = pb.read_json(work / receipt["input_dir"] / "manifest.json")
    assert Counter(row["selection_arm"] for row in rows) == {
        "best_min_margin": 20, "uncertainty": 20, "random": 20}
    assert all(row.get("parent_truth_provenance") is None
               for row in rows if row["candidate_group"] == "fresh_random")
    assert all(not (selection.FORBIDDEN_CANDIDATE_TRUTH & set(row)) for row in rows)
    state = pb.read_json(work / "state.json")
    assert state["next_batch"] == 3 and state["measured_budget"] == 60
    assert state["batches"]["2"]["feedback_audit"] is None
    with pytest.raises(ValueError, match="refusing to rerun"):
        ex.select_batch(work, 2, measured_parent_context=plan["measured_parent_context"])

    original_receipt = receipt_path.read_bytes()
    forged_receipt = pb.read_json(receipt_path)
    forged_receipt["pre_state_sha256"] = "0" * 64
    forged_receipt.pop("content_id")
    forged_receipt["content_id"] = ex.content_id(forged_receipt)
    pb.atomic_json(receipt_path, forged_receipt)
    with pytest.raises(ValueError, match="semantic successor"):
        selection.validate_completed_receipt(work, receipt_path)
    receipt_path.write_bytes(original_receipt)

    original_state = (work / "state.json").read_bytes()
    forged_state = pb.read_json(work / "state.json")
    forged_state["unexpected_later_field"] = True
    pb.atomic_json(work / "state.json", forged_state)
    with pytest.raises(ValueError, match="top-level schema"):
        selection.validate_completed_receipt(work, receipt_path)
    (work / "state.json").write_bytes(original_state)

    _complete_feedback(work, dataset, 2)
    selection.validate_completed_receipt(work, receipt_path)
    receipt3_path = selection.select_with_transition(work, 3)
    receipt3 = selection.validate_completed_receipt(work, receipt3_path)
    plan3 = pb.read_json(work / receipt3["plan_path"])
    assert len(plan3["combined_ranking"]["ranking"]) == 120
    assert len(plan3["sidecar_payloads"]) == 2
    selection.validate_completed_receipt(work, receipt_path)

    shutil.copytree(work / "batches/batch-001_input", dataset / "dedust_r81b1_input")
    shutil.copytree(work / "batches/batch-002_input", dataset / "dedust_r81b2_input")
    shutil.copytree(work / "batches/batch-003_input", dataset / "dedust_r81b3_input")
    cfg = ex.validate_exploration_config(ex._load_yaml(work / "config.yaml"))
    binding = {
        "work_dir": str(work),
        "files": {path.relative_to(work).as_posix(): pb.file_sha256(path)
                  for path in work.rglob("*") if path.is_file()},
        "transition_selection_receipts": {
            "2": {"path": receipt_path.relative_to(work).as_posix(),
                  "sha256": pb.file_sha256(receipt_path)},
            "3": {"path": receipt3_path.relative_to(work).as_posix(),
                  "sha256": pb.file_sha256(receipt3_path)}},
    }
    formal = {1: {"job": {"input": "dedust_r81b1_input"}},
              2: {"job": {"input": "dedust_r81b2_input"}},
              3: {"job": {"input": "dedust_r81b3_input"}}}
    expected_profile = {
        "measurement_id": measurement_id(cfg["measurement"]),
        "score_spec_id": score_spec_id(cfg["score_spec"]),
        "runtime": cfg.get("runtime", {}),
    }
    entry._validate_exploration(binding, dataset, 3, formal, expected_profile)
    downgraded = dict(binding)
    downgraded.pop("transition_selection_receipts")
    with pytest.raises(ValueError, match="requires authenticated receipts"):
        entry._validate_exploration(downgraded, dataset, 3, formal, expected_profile)

    manifest_path = work / receipt3["input_dir"] / "manifest.json"
    original_manifest = manifest_path.read_bytes()
    original_state3 = (work / "state.json").read_bytes()
    original_receipt3 = receipt3_path.read_bytes()

    def rehash_batch3() -> None:
        forged_state = pb.read_json(work / "state.json")
        forged_state["batches"]["3"]["input_manifest_sha256"] = pb.file_sha256(manifest_path)
        pb.atomic_json(work / "state.json", forged_state)
        forged_receipt = pb.read_json(receipt3_path)
        input_dir = work / forged_receipt["input_dir"]
        rows_now = pb.read_json(manifest_path)
        forged_receipt["post_state_sha256"] = pb.file_sha256(work / "state.json")
        forged_receipt["input_manifest_sha256"] = pb.file_sha256(manifest_path)
        forged_receipt["input_files"] = {
            path.name: pb.file_sha256(path)
            for path in sorted(input_dir.iterdir()) if path.is_file()}
        forged_receipt["selected_pattern_sha256"] = [
            row["pattern_sha256"] for row in rows_now]
        forged_receipt.pop("content_id")
        forged_receipt["content_id"] = ex.content_id(forged_receipt)
        pb.atomic_json(receipt3_path, forged_receipt)

    # An arbitrary truth-like alias remains invalid even after every
    # caller-controlled manifest/state/receipt hash is recomputed.
    extra_field = pb.read_json(manifest_path)
    extra_field[0]["soft_target"] = [0.0]
    pb.atomic_json(manifest_path, extra_field)
    rehash_batch3()
    with pytest.raises(ValueError, match="deterministic selector replay"):
        selection.validate_completed_receipt(work, receipt3_path)
    manifest_path.write_bytes(original_manifest)
    (work / "state.json").write_bytes(original_state3)
    receipt3_path.write_bytes(original_receipt3)

    # Replace an exactly selected row with a different candidate from the same
    # deterministic pool, then recompute every caller-controlled hash/receipt.
    tampered = pb.read_json(manifest_path)
    cfg = ex.validate_exploration_config(ex._load_yaml(work / "config.yaml"))
    frozen = pb.read_json(work / "transition_selection/batch-003-pre-state.json")
    _parents, candidates, _seed = selection._replay_candidate_pool(
        work, 3, frozen, plan3["measured_parent_context"], cfg["exploration"])
    used = {row["pattern_sha256"] for row in tampered}
    replacement = next(row for row in candidates if row["pattern_sha256"] not in used)
    predictions, uncertainty, _model_hash = ex.predict_ensemble(
        work, 2, [row["pattern"] for row in candidates])
    candidate_index = replacement["candidate_index"]
    old_file = work / receipt3["input_dir"] / tampered[0]["pattern_file"]
    new_id = (f"{frozen['id_prefix']}_b03_000_"
              f"{replacement['pattern_sha256'][:8]}")
    new_file = work / receipt3["input_dir"] / f"{new_id}.pt"
    old_file.unlink()
    torch.save(torch.as_tensor(replacement["pattern"], dtype=torch.float32), new_file)
    for key, value in selection._candidate_summary(replacement).items():
        tampered[0][key] = value
    tampered[0].update({
        "id": new_id, "pattern_file": new_file.name,
        "prediction_valid": True,
        "prediction": predictions[candidate_index].astype(float).tolist(),
        "predicted_uncertainty": float(uncertainty[candidate_index]),
    })
    pb.atomic_json(manifest_path, tampered)
    rehash_batch3()
    with pytest.raises(ValueError, match="deterministic selector replay"):
        selection.validate_completed_receipt(work, receipt3_path)


def test_tampered_plan_rejects_without_completion_receipt(tmp_path):
    work, _dataset = _prepare_formal_lifecycle(tmp_path)
    evidence = work / "transition_selection"
    state_raw = (work / "state.json").read_bytes()
    dataset_raw = (work / "dataset_manifest.json").read_bytes()
    plan = selection._make_plan(work, 2, state_raw, dataset_raw,
                                allow_dataset_extension=False)
    evidence.mkdir()
    (evidence / "batch-002-pre-state.json").write_bytes(state_raw)
    (evidence / "batch-002-pre-dataset.json").write_bytes(dataset_raw)
    plan["measured_parent_context"]["parents"][
        next(iter(plan["measured_parent_context"]["parents"]))]["preference_ordinal"] = 59
    plan.pop("content_id")
    plan["content_id"] = ex.content_id(plan)
    pb.atomic_json(evidence / "batch-002-plan.json", plan)
    with pytest.raises(ValueError, match="authenticated replay"):
        selection.finalize_existing(work, 2)
    assert not (evidence / "batch-002-receipt.json").exists()


def test_post_state_without_receipt_is_recoverable_only_by_finalize(tmp_path):
    work, _dataset = _prepare_formal_lifecycle(tmp_path)
    paths = selection._paths(work, 2, None)
    state_raw = (work / "state.json").read_bytes()
    dataset_raw = (work / "dataset_manifest.json").read_bytes()
    plan = selection._make_plan(work, 2, state_raw, dataset_raw,
                                allow_dataset_extension=False)
    selection._write_bytes_x(paths["state"], state_raw)
    selection._write_bytes_x(paths["dataset"], dataset_raw)
    selection._write_json_x(paths["plan"], plan)
    ex.select_batch(work, 2, measured_parent_context=plan["measured_parent_context"])
    assert not paths["receipt"].exists()
    recovered = selection.finalize_existing(work, 2)
    assert recovered == paths["receipt"] and recovered.is_file()
    with pytest.raises(FileExistsError, match="overwrite"):
        selection.finalize_existing(work, 2)
