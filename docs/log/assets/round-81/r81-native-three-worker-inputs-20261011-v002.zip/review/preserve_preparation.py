"""Preserve the actual native input split, without dispatch or training."""
import hashlib
import json
from pathlib import Path
from collections import Counter
import zipfile
from datetime import datetime, timezone

REPO = Path(__file__).resolve().parents[2]
WORK = Path(__file__).parent
ROOT = WORK / 'staged_formal_b1_shards'
def sha_bytes(raw):
    return hashlib.sha256(raw).hexdigest()
def sha(path):
    return sha_bytes(path.read_bytes())
evidence = json.loads((WORK / 'source_evidence.json').read_text(encoding='utf-8'))
split = json.loads((ROOT / 'split_receipt.json').read_text(encoding='utf-8'))
assert sha(ROOT / 'split_receipt.json') == evidence['local_offline_split']['split_receipt_sha256']
canonical_path = Path(evidence['actual_formal_batch_1']['canonical_input']) / 'manifest.json'
canonical_raw = canonical_path.read_bytes()
assert sha_bytes(canonical_raw) == evidence['actual_formal_batch_1']['manifest_sha256'] == split['canonical_manifest_sha256']
canonical = json.loads(canonical_raw.decode('utf-8'))
assert len(canonical) == 60 and len(set(row['id'] for row in canonical)) == 60
assert len(set(row['pattern_sha256'] for row in canonical)) == 60
assert dict(Counter(row['selection_arm'] for row in canonical)) == {'history':20,'specialist':20,'random':20}
assert split['round_robin'] is True and split['shard_size'] == 20 and len(split['shards']) == 3
all_ids = []
for ordinal, entry in enumerate(split['shards']):
    child = ROOT / entry['name']
    assert entry['name'] == f'shard-{ordinal+1:03d}_input'
    manifest = json.loads((child / 'manifest.json').read_text(encoding='utf-8'))
    assert manifest == canonical[ordinal::3] and len(manifest) == 20
    assert sha(child / 'manifest.json') == entry['manifest_sha256']
    assert [row['id'] for row in manifest] == entry['ids']
    for name in ('config.yaml','measurement.json','score_spec.json'):
        assert sha(child / name) == split['canonical_metadata_sha256'][name]
    for row, binding in zip(manifest, entry['items']):
        assert row['id'] == binding['id'] and row['pattern_sha256'] == binding['pattern_sha256']
        assert binding['pattern_file'] == row['id'] + '.pt'
        assert sha(child / binding['pattern_file']) == binding['file_sha256']
    all_ids.extend(entry['ids'])
assert len(set(all_ids)) == 60 and set(all_ids) == {row['id'] for row in canonical}
assert canonical_path.read_bytes() == canonical_raw
for name, binding in evidence['source_files'].items():
    assert sha(REPO / name) == binding['sha256']

payloads = {'design.json': (WORK / 'design.json').read_bytes(),
            'source_evidence.json': (WORK / 'source_evidence.json').read_bytes(),
            'review/preserve_preparation.py': Path(__file__).read_bytes(),
            'canonical/manifest.json': canonical_raw,
            'producer/script/profiled_shards.py': (REPO / 'script/profiled_shards.py').read_bytes()}
for path in sorted(ROOT.rglob('*')):
    if path.is_file():
        payloads['native-split/' + path.relative_to(ROOT).as_posix()] = path.read_bytes()
archive = REPO / 'docs/log/assets/round-81/r81-native-three-worker-inputs-20261011-v002.zip'
inventory = {name: {'bytes':len(raw), 'sha256':sha_bytes(raw)} for name, raw in payloads.items()}
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED) as z:
    for name, raw in payloads.items():
        z.writestr(name, raw)
    z.writestr('archive_manifest.json', json.dumps(inventory, indent=2, ensure_ascii=False))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name, expected in inventory.items():
        value = z.read(name)
        assert len(value) == expected['bytes'] and sha_bytes(value) == expected['sha256']
result = {'schema_version':1, 'status':'actual_native_input_partition_verified_formal_control_plane_pending',
          'recorded_utc':datetime.now(timezone.utc).isoformat(),
          'actual_input':evidence['actual_formal_batch_1'],
          'actual_split':evidence['local_offline_split'],
          'source_evidence_sha256':sha(WORK / 'source_evidence.json'),
          'design_sha256':sha(WORK / 'design.json'),
          'root_checks':{'exact_round_robin_rows':True, 'unique_exact_union':True,
                         'all_60_copied_pattern_file_hashes':True, 'unchanged_profile_bytes':True,
                         'source_files_unchanged':True, 'archive_members_verified':len(payloads)},
          'archive':{'path':archive.relative_to(REPO).as_posix(), 'sha256':sha(archive),
                     'bytes':archive.stat().st_size},
          'scope':{'nas_writes':False,'queue_mutation':False,'hfss':False,'model_or_training':False,
                   'main_runtime_changed':False,'symmetry_requirement':None},
          'limitations':['Formal sharded entry/launcher is not implemented or deployed at this cutoff.',
                         'First recorder preserved a complete v001 archive but failed before JSON publication due to an st_size call typo; corrected fresh v002 never overwrites that prefix.',
                         'No completed child result, aggregation, feedback, model update or performance exists.',
                         'Three-by-20 changes scheduling only, preserving the logical60 and 20/20/20 arm totals.',
                         'EngineeringOnly release and queue remain unchanged; formal dispatch requires its actual complete results.']}
record = REPO / 'docs/log/assets/r81_formal_sharding_preparation_20261011.json'
with record.open('x', encoding='utf-8', newline='\n') as stream:
    json.dump(result, stream, indent=2, ensure_ascii=False)
    stream.write('\n')
print(json.dumps({'record_sha256':sha(record),'archive':result['archive'],'verified_rows':60}, ensure_ascii=False))
