from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
task_roots = {
    'assembly': 'r81_actual_engineering_assembly_20261011_v001/run_assembly.ps1',
    'closeout': 'r80_actual_closeout_20261011_v001/run_closeout.ps1',
}
records = {}
for role, relative in task_roots.items():
    source = ROOT / 'tmp' / relative
    original = source.read_bytes()
    assert not original.startswith(b'\xef\xbb\xbf')
    text = original.decode('utf8')
    output = HERE / ('run_' + role + '_utf8_bom.ps1')
    payload = b'\xef\xbb\xbf' + original
    with output.open('xb') as stream:
        stream.write(payload)
    assert output.read_text(encoding='utf-8-sig') == text
    records[role] = {'source': str(source), 'source_sha256': hashlib.sha256(original).hexdigest(),
                     'output': str(output), 'output_sha256': hashlib.sha256(payload).hexdigest(),
                     'decoded_script_exactly_unchanged': True}
receipt = {'status': 'transport_only_bom_correction_prepared', 'commands': records,
           'failed_v001_logs_preserved': True, 'runtime_or_profile_changed': False}
with (HERE / 'preparation_receipt.json').open('x', encoding='utf8') as stream:
    json.dump(receipt, stream, indent=2)
print(json.dumps(receipt))
