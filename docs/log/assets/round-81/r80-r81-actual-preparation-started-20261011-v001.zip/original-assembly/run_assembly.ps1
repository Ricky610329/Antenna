$ErrorActionPreference = 'Stop'
$env:PYTHONIOENCODING = 'utf-8'
$env:OMP_NUM_THREADS = '4'
$taskRepo = 'C:\Users\ricky\Documents\GitHub\Antenna'
$taskPython = 'C:\Users\ricky\miniforge3\envs\ant\python.exe'
$taskR81Root = "\\140.123.106.219\temp\碩二_鄒穎麒's\antenna\experiments\r81_wide_filter_20261007"
$taskCompletion = Join-Path $taskR81Root 'release_inputs\r80_native5000_completion_v001\r80_completion_binding.json'
$taskEngineering = Join-Path $taskR81Root 'engineering_v001'
if (Test-Path -LiteralPath $taskEngineering) { throw 'Preserve existing engineering attempt; no automatic reuse.' }
New-Item -ItemType Directory -Path $taskEngineering | Out-Null
New-Item -ItemType Directory -Path (Join-Path $taskEngineering 'release') | Out-Null
Set-Location -LiteralPath $taskRepo
& $taskPython "$taskRepo\tmp\r81_engineering_release_assembler_20261011_v001\assemble_r81_engineering_release.py" `
  --r80-completion $taskCompletion `
  --r80-completion-sha256 '4a5d14d4fc3dc863b4fe38497351207a686157d579a0110f5bd6de009951b0a2' `
  --runtime-commit '66dfc5c7f37e060b903feed72edbdc12c46ddb6e' `
  --wide-profile "$taskRepo\configs\dual_r81_wide_filter.yaml" `
  --wide-profile-sha256 '1ca15eba360b44dc1246b98640c199c3d44538fe29a91e11a661222ae6cc121a' `
  --prior-config "$taskRepo\tmp\r81_masked_prior_config_20261010_v001\config.yaml" `
  --prior-config-sha256 'b3ff008492862593b361bc217eb39a5c56943e158e2f04dab50b0078c6d279b6' `
  --history-root "\\140.123.106.219\temp\碩二_鄒穎麒's\antenna\dataset" `
  --dataset-root (Join-Path $taskEngineering 'dataset') `
  --controller-work-dir (Join-Path $taskEngineering 'controller') `
  --release-output (Join-Path $taskEngineering 'release\r81_engineering_only_20261011_v001.json') `
  --release-id 'r81_engineering_only_20261011_v001' --priority 5
if ($LASTEXITCODE -ne 0) { throw 'Assembly failed; preserve its prefix, do not retry or start workers.' }
