$ErrorActionPreference = 'Stop'

$python = 'C:\Users\ricky\miniforge3\envs\ant\python.exe'
$repo = 'C:\Users\ricky\Documents\GitHub\Antenna'
$delivery = "\\140.123.106.219\temp\碩二_鄒穎麒's\antenna\experiments\r81_wide_filter_20261007\release_inputs\r80_native5000_completion_v001"
$r80Dataset = "\\140.123.106.219\temp\碩二_鄒穎麒's\antenna\experiments\r80_symmetry_20261007\dataset"
$r81Dataset = "\\140.123.106.219\temp\碩二_鄒穎麒's\antenna\experiments\r81_wide_filter_20261007\engineering_v001\dataset"
$outDir = "\\140.123.106.219\temp\碩二_鄒穎麒's\antenna\experiments\r80_symmetry_20261007\analysis_versions\final5000_20261011_v001"

# Required after the native terminal watch/action pair is complete and the
# portable r80_completion_binding.json has been rendered and independently hashed.
$completionBindingSha256 = '<REQUIRED_EXACT_SHA256_AFTER_NATIVE_TERMINAL_GATE>'

Set-Location -LiteralPath $repo
& $python "$repo\tmp\r80_final_closeout_driver_20261011_v004\final_closeout_driver.py" closeout `
  --census-report "$delivery\census_raw_report.json" `
  --census-report-sha256 '941ee94df71814d2c724eabaf92949e33fc53fd10a8025bfe84057326afaec8b' `
  --rows-json "$delivery\census_rows.json" `
  --rows-sha256 'b45b646f68f5e601ec4224641eb778a17c748e81a37a61d2bf0c3c77387ad329' `
  --pair-proofs-json "$delivery\census_pair_proofs.json" `
  --pair-proofs-sha256 '51a69201ea764bf3f41f2349205d195150bf6d22b5a9bf46b82372f30d015d92' `
  --r80-completion-binding "$delivery\r80_completion_binding.json" `
  --r80-completion-binding-sha256 $completionBindingSha256 `
  --r81-private-dataset $r81Dataset `
  --r81-private-dataset-path-sha256 '7184a15058b8d4b6c5bb3445568810ccb93fe6e48bd6ea1f5aa18c8949fb2970' `
  --release-commit '66dfc5c7f37e060b903feed72edbdc12c46ddb6e' `
  --expected-cutoff-id '031af34de9a0a7868782a0e4ebfa783defda937ad593f1c92a4b11275b21dbe1' `
  --expected-jobs-sha256 'f9c76f9b8c948026eb5fb859d55437258e8f28bbfb802e792461f15bdac42f09' `
  --repeat-store "$r80Dataset\dedust_r80repeat1" `
  --repeat-store "$r80Dataset\dedust_r80repeat2" `
  --repeat-store "$r80Dataset\dedust_r80bestrep01" `
  --out-dir $outDir
