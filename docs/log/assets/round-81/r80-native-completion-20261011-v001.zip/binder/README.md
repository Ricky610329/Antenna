# R81 portable R80-completion binder

`bind_r80_completion.py` is a create-only offline copier for the final R80
completion evidence consumed by the existing `script/r81_worker_entry.py`
gate. It does not prepare R81 inputs, touch `jobs.json`, call a controller,
start HFSS, or launch a worker.

The binder requires the final watch snapshot and its SHA-256 on the command
line. Before creating the destination it validates the exact 44-file native
runtime at commit `66dfc5c7f37e060b903feed72edbdc12c46ddb6e` and invokes the unchanged
native `_validate_r80` gate using local source paths. A live/nonterminal watch
or a 4998/pending action therefore fails before any destination write.

The tracked census has two intentional hashes because Git stores LF bytes and
this Windows checkout has CRLF bytes:

- native Git blob SHA-256: `1ce52488dad964c8a845812c627c5681ff747967ab1048a1dfe418421bf3957a`
- checkout physical SHA-256: `98f4b829881cb2c99d03d74e2ac500a257d65bd46d5605b6f30d59bd36d3c835`

The native binding uses the Git blob SHA. The source manifest separately
records the physical checkout hash.

After the local gate passes, the binder exclusively creates one fresh direct
child of:

`\\140.123.106.219\temp\碩二_鄒穎麒's\antenna\experiments\r81_wide_filter_20261007\release_inputs`

It copies and rehashes exactly eight inputs: watch snapshot, action receipt,
raw census report, rows, pair proofs, query producer, validation producer, and
the canonical profile. It preserves the action and profile producer paths in
the portable binding. It then invokes the unchanged native gate against the
copied paths, writes source/archive manifests exclusively, and writes
`r80_completion_binding.json` exclusively as the final filesystem write.
Any earlier failure preserves the created prefix and leaves no completion
binding. The final exclusive write is never deleted or retried automatically.
If that write is interrupted or fails, an unverified partial completion path
may remain and requires manual review; it is not a successful receipt.

The R81 dataset path must be a fresh UNC path under the same private
experiment, outside `release_inputs`, and end in `dataset`. The binder checks
it but does not create it.

## Command after the final native watch exists

This is a template only. Replace `<FINAL_WATCH_SHA256>` with the independently
captured hash of the terminal snapshot. Do not use the current nonterminal
watch.

```powershell
$python = 'C:\Users\ricky\miniforge3\envs\ant\python.exe'
& $python tmp/r81_completion_binder_20261011_v002/bind_r80_completion.py `
  --watch-status "C:\Users\ricky\Documents\GitHub\Antenna\tmp\r80_factory_20261007\controller_diverse_sm_v1\watch_status.json" `
  --watch-status-sha256 "<FINAL_WATCH_SHA256>" `
  --runtime-commit "66dfc5c7f37e060b903feed72edbdc12c46ddb6e" `
  --destination "\\140.123.106.219\temp\碩二_鄒穎麒's\antenna\experiments\r81_wide_filter_20261007\release_inputs\r80_native5000_completion_v001" `
  --r81-dataset-root "\\140.123.106.219\temp\碩二_鄒穎麒's\antenna\experiments\r81_wide_filter_20261007\engineering_v001\dataset"
```

No command in this directory has been run against the live watch or private
NAS. Actual terminal validation and archive creation remain pending.
