"""Create a portable, immutable R80-completion evidence bundle for R81.

This is an offline copier/binder.  It does not prepare R81 inputs, mutate a
queue, invoke a controller, start HFSS, or launch a worker.  The existing
``script.r81_worker_entry`` validation functions remain authoritative.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
from pathlib import Path
from typing import Any


REPO = Path(__file__).resolve().parents[2]
if str(REPO) not in sys.path:
    sys.path.insert(0, str(REPO))

from script import profiled_batch as pb  # noqa: E402
from script import r81_worker_entry as entry  # noqa: E402


RUNTIME_COMMIT = "66dfc5c7f37e060b903feed72edbdc12c46ddb6e"
CENSUS_REPO_PATH = "docs/log/assets/r80_final_census_20261011_v001.json"
# The native gate binds git-show bytes.  The checkout bytes use CRLF and are
# intentionally recorded separately below.
CENSUS_GIT_BLOB_SHA256 = "1ce52488dad964c8a845812c627c5681ff747967ab1048a1dfe418421bf3957a"
CENSUS_CHECKOUT_SHA256 = "98f4b829881cb2c99d03d74e2ac500a257d65bd46d5605b6f30d59bd36d3c835"
EXPECTED_RUNTIME_FILE_COUNT = 44

PRIVATE_EXPERIMENT_ROOT = Path(
    r"\\140.123.106.219\temp\碩二_鄒穎麒's\antenna\experiments\r81_wide_filter_20261007"
)
RELEASE_INPUTS_ROOT = PRIVATE_EXPERIMENT_ROOT / "release_inputs"

FIXED_SOURCES = {
    "census_raw_report": {
        "path": REPO / "tmp/r80_best_render_20261011_v036/report.json",
        "sha256": "941ee94df71814d2c724eabaf92949e33fc53fd10a8025bfe84057326afaec8b",
        "archive_name": "census_raw_report.json",
    },
    "census_rows": {
        "path": REPO / "tmp/r80_best_render_20261011_v036/rows.json",
        "sha256": "b45b646f68f5e601ec4224641eb778a17c748e81a37a61d2bf0c3c77387ad329",
        "archive_name": "census_rows.json",
    },
    "census_pair_proofs": {
        "path": REPO / "tmp/r80_best_render_20261011_v036/pair_proofs.json",
        "sha256": "51a69201ea764bf3f41f2349205d195150bf6d22b5a9bf46b82372f30d015d92",
        "archive_name": "census_pair_proofs.json",
    },
    "census_query_producer": {
        "path": REPO / "tmp/r80_best_render_20261011_v036/query_and_freeze.py",
        "sha256": "da6a0034241d4d6f22ecfd1ce0272b4dbd06ec252737278b0539b4bec2b631ac",
        "archive_name": "query_and_freeze.py",
    },
    "census_validation_producer": {
        "path": REPO / "tmp/r80_final_census_validation_20261011_v001/validate_saved_census.py",
        "sha256": "9554bdbdbf264b1b98261e4f34082421e7e77a11ef396a47eb6ddd3d2c0bdb87",
        "archive_name": "validate_saved_census.py",
    },
    "profile": {
        "path": REPO / "configs/single_r80_symmetry_factory.yaml",
        "sha256": "89132be0455eb0a0affe036bc95122862de5dc34582f0fd83a022f37c6717095",
        "archive_name": "single_r80_symmetry_factory.yaml",
    },
}

ARCHIVE_NAMES = {
    "watch_status": "watch_status.json",
    "action_receipt": "action_receipt.json",
    **{role: value["archive_name"] for role, value in FIXED_SOURCES.items()},
}


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _json_bytes(value: Any) -> bytes:
    return (json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode("utf-8")


def _read_json_object(path: Path, label: str) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(value, dict):
        raise ValueError(f"{label} must contain a JSON object")
    return value


def _require_hash(path: Path, expected: str, label: str) -> dict[str, Any]:
    if not path.is_file():
        raise ValueError(f"{label} is not a file: {path}")
    actual = _sha256(path)
    if actual != expected:
        raise ValueError(f"{label} SHA-256 differs: {actual}")
    return {"path": str(path), "sha256": actual, "bytes": path.stat().st_size}


def _normalized(path: Path) -> str:
    return os.path.normcase(os.path.normpath(os.fspath(path)))


def _inside(child: Path, parent: Path) -> bool:
    left, right = _normalized(child), _normalized(parent)
    try:
        return os.path.commonpath((left, right)) == right
    except ValueError:
        return False


def _require_unc(path: Path, label: str) -> None:
    if not path.is_absolute() or not str(path).startswith("\\\\"):
        raise ValueError(f"{label} must be an absolute UNC path")


def _validate_destination_paths(destination: Path, dataset: Path) -> None:
    _require_unc(destination, "destination")
    _require_unc(dataset, "R81 dataset root")
    if destination.parent != RELEASE_INPUTS_ROOT:
        raise ValueError(
            "destination must be one fresh direct child of the private R81 release_inputs directory"
        )
    if destination.exists():
        raise FileExistsError(f"destination already exists: {destination}")
    if not RELEASE_INPUTS_ROOT.is_dir():
        raise ValueError(f"release_inputs parent does not exist: {RELEASE_INPUTS_ROOT}")
    if not _inside(dataset, PRIVATE_EXPERIMENT_ROOT) or dataset == PRIVATE_EXPERIMENT_ROOT:
        raise ValueError("R81 dataset root must be inside the private r81_wide_filter experiment")
    if _inside(dataset, RELEASE_INPUTS_ROOT):
        raise ValueError("R81 dataset root must be separate from release_inputs")
    if dataset.name != "dataset":
        raise ValueError("R81 dataset root must end in the explicit dataset directory")
    if dataset.exists():
        raise FileExistsError(f"R81 dataset root is not fresh: {dataset}")


def _runtime_binding(commit: str) -> dict[str, Any]:
    if len(entry.RUNTIME_FILES) != EXPECTED_RUNTIME_FILE_COUNT:
        raise ValueError(
            f"native runtime inventory has {len(entry.RUNTIME_FILES)} files, expected 44"
        )
    runtime = {
        "git_commit": commit,
        "files": {relative: entry._git_blob_sha(commit, relative) for relative in entry.RUNTIME_FILES},
    }
    entry._validate_runtime(runtime)
    return runtime


def _local_sources(watch_path: Path, watch_sha: str) -> tuple[dict[str, Any], dict[str, dict[str, Any]]]:
    sources: dict[str, dict[str, Any]] = {
        "watch_status": _require_hash(watch_path, watch_sha, "watch snapshot")
    }
    watch = _read_json_object(watch_path, "watch snapshot")
    action_value = watch.get("last_receipt")
    action_sha = watch.get("last_receipt_sha256")
    if not isinstance(action_value, str) or not Path(action_value).is_absolute():
        raise ValueError("watch last_receipt must be an absolute producer path")
    if not isinstance(action_sha, str):
        raise ValueError("watch last_receipt_sha256 is missing")
    action_path = Path(action_value)
    sources["action_receipt"] = _require_hash(action_path, action_sha, "watch action receipt")
    action = _read_json_object(action_path, "watch action receipt")

    for role, fixed in FIXED_SOURCES.items():
        sources[role] = _require_hash(fixed["path"], fixed["sha256"], role)

    census_path = REPO / CENSUS_REPO_PATH
    census_physical = _require_hash(
        census_path, CENSUS_CHECKOUT_SHA256, "tracked census checkout bytes"
    )
    git_blob = entry._git_blob_sha(RUNTIME_COMMIT, CENSUS_REPO_PATH)
    if git_blob != CENSUS_GIT_BLOB_SHA256:
        raise ValueError(f"tracked census Git blob SHA-256 differs: {git_blob}")

    profile_producer = action.get("profile_config")
    if not isinstance(profile_producer, str) or not Path(profile_producer).is_absolute():
        raise ValueError("action profile_config must preserve an absolute producer path")

    context = {
        "action_producer_path": action_value,
        "profile_producer_path": profile_producer,
        "census_checkout": census_physical,
        "census_git_blob_sha256": git_blob,
    }
    return context, sources


def _binding(
    paths: dict[str, Path], sources: dict[str, dict[str, Any]], context: dict[str, Any]
) -> dict[str, Any]:
    profile = pb.load_profile_config(paths["profile"])
    if profile is None:
        raise ValueError("R80 profile could not be loaded")
    from antenna.measurement import measurement_id, score_spec_id

    def item(role: str) -> dict[str, str]:
        return {"path": str(paths[role]), "sha256": sources[role]["sha256"]}

    return {
        "watch_status": item("watch_status"),
        "action_receipt": {
            **item("action_receipt"),
            "producer_path": context["action_producer_path"],
        },
        "census": {
            "repo_path": CENSUS_REPO_PATH,
            "sha256": CENSUS_GIT_BLOB_SHA256,
        },
        "profile": {
            **item("profile"),
            "producer_path": context["profile_producer_path"],
        },
        "census_raw_report": item("census_raw_report"),
        "census_rows": item("census_rows"),
        "census_pair_proofs": item("census_pair_proofs"),
        "census_query_producer": item("census_query_producer"),
        "census_validation_producer": item("census_validation_producer"),
        "measurement_id": measurement_id(profile.measurement),
        "score_spec_id": score_spec_id(profile.score_spec),
    }


def _copy_exclusive(source: Path, destination: Path, expected: str) -> dict[str, Any]:
    digest = hashlib.sha256()
    count = 0
    with source.open("rb") as reader, destination.open("xb") as writer:
        while True:
            block = reader.read(1024 * 1024)
            if not block:
                break
            writer.write(block)
            digest.update(block)
            count += len(block)
        writer.flush()
        os.fsync(writer.fileno())
    copied = digest.hexdigest()
    if copied != expected:
        raise ValueError(f"source changed while copying {source}: {copied}")
    rehashed = _sha256(destination)
    if rehashed != expected:
        raise ValueError(f"destination rehash differs for {destination}: {rehashed}")
    return {"path": str(destination), "sha256": rehashed, "bytes": count}


def _write_exclusive(path: Path, payload: bytes) -> str:
    with path.open("xb") as stream:
        stream.write(payload)
        stream.flush()
        os.fsync(stream.fileno())
    digest = _sha256(path)
    expected = hashlib.sha256(payload).hexdigest()
    if digest != expected:
        raise ValueError(f"written file rehash differs: {path}")
    return digest


def bind(args: argparse.Namespace) -> dict[str, Any]:
    watch_path = Path(args.watch_status).resolve(strict=True)
    destination = Path(args.destination)
    dataset = Path(args.r81_dataset_root)
    if args.runtime_commit != RUNTIME_COMMIT:
        raise ValueError(f"runtime commit must be the pinned final-census commit {RUNTIME_COMMIT}")

    # Read-only phase.  Both unchanged native gates run before the destination
    # directory is created or any output byte is written.
    context, sources = _local_sources(watch_path, args.watch_status_sha256)
    runtime = _runtime_binding(args.runtime_commit)
    local_paths = {role: Path(info["path"]) for role, info in sources.items()}
    local_binding = _binding(local_paths, sources, context)
    local_native_report = entry._validate_r80(local_binding, dataset, args.runtime_commit)
    _validate_destination_paths(destination, dataset)

    destination.mkdir()
    archived: dict[str, dict[str, Any]] = {}
    portable_paths: dict[str, Path] = {}
    for role in (
        "watch_status",
        "action_receipt",
        "census_raw_report",
        "census_rows",
        "census_pair_proofs",
        "census_query_producer",
        "census_validation_producer",
        "profile",
    ):
        target = destination / ARCHIVE_NAMES[role]
        portable_paths[role] = target
        archived[role] = _copy_exclusive(Path(sources[role]["path"]), target, sources[role]["sha256"])

    portable_binding = _binding(portable_paths, sources, context)
    portable_native_report = entry._validate_r80(portable_binding, dataset, args.runtime_commit)
    if portable_native_report != local_native_report:
        raise ValueError("portable and local native R80 validation reports differ")

    source_manifest = {
        "schema_version": 1,
        "kind": "r80_completion_source_manifest",
        "runtime": runtime,
        "census": {
            "repo_path": CENSUS_REPO_PATH,
            "git_blob_sha256": CENSUS_GIT_BLOB_SHA256,
            "checkout_path": context["census_checkout"]["path"],
            "checkout_sha256": context["census_checkout"]["sha256"],
            "checkout_bytes": context["census_checkout"]["bytes"],
        },
        "original_eight_inputs": sources,
        "producer_paths": {
            "action_receipt": context["action_producer_path"],
            "profile": context["profile_producer_path"],
        },
    }
    source_manifest_path = destination / "source_manifest.json"
    source_manifest_sha = _write_exclusive(source_manifest_path, _json_bytes(source_manifest))

    binding_payload = _json_bytes(portable_binding)
    binding_sha = hashlib.sha256(binding_payload).hexdigest()
    archive_manifest = {
        "schema_version": 1,
        "kind": "r80_completion_archive_manifest",
        "status": "portable_native_validation_passed_before_completion_binding",
        "destination": str(destination),
        "r81_dataset_root": str(dataset),
        "runtime_commit": args.runtime_commit,
        "runtime_file_count": len(runtime["files"]),
        "archived_eight_inputs": archived,
        "source_manifest": {
            "path": str(source_manifest_path),
            "sha256": source_manifest_sha,
        },
        "completion_binding": {
            "path": str(destination / "r80_completion_binding.json"),
            "expected_sha256": binding_sha,
            "write_order": "exclusive_final_write",
        },
        "native_r80_report": portable_native_report,
        "operations": {
            "hfss_started": False,
            "controller_invoked": False,
            "queue_mutated": False,
            "worker_started": False,
            "r81_inputs_prepared": False,
        },
    }
    archive_manifest_path = destination / "archive_manifest.json"
    archive_manifest_sha = _write_exclusive(archive_manifest_path, _json_bytes(archive_manifest))

    expected_prefix = set(ARCHIVE_NAMES.values()) | {"source_manifest.json", "archive_manifest.json"}
    actual_prefix = {path.name for path in destination.iterdir()}
    if actual_prefix != expected_prefix:
        raise ValueError(
            f"exclusive destination prefix inventory differs: {sorted(actual_prefix)}"
        )

    # This is deliberately the final filesystem write.  It is never deleted or
    # retried automatically: a failed write may leave an unverified partial that
    # requires manual review, while every earlier failure leaves it absent.
    binding_path = destination / "r80_completion_binding.json"
    written_binding_sha = _write_exclusive(binding_path, binding_payload)
    if written_binding_sha != binding_sha:
        raise ValueError("final completion binding SHA-256 differs")

    return {
        "schema_version": 1,
        "status": "portable_completion_binding_created",
        "destination": str(destination),
        "r81_dataset_root": str(dataset),
        "runtime_commit": args.runtime_commit,
        "runtime_file_count": len(runtime["files"]),
        "original_input_count": len(archived),
        "source_manifest_sha256": source_manifest_sha,
        "archive_manifest_sha256": archive_manifest_sha,
        "completion_binding_sha256": written_binding_sha,
        "native_r80_report": portable_native_report,
        "final_write": str(binding_path),
    }


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Copy and bind an already-terminal R80 completion for portable R81 use."
    )
    parser.add_argument("--watch-status", required=True, help="Pinned local final watch snapshot")
    parser.add_argument("--watch-status-sha256", required=True, help="SHA-256 of that snapshot")
    parser.add_argument("--runtime-commit", required=True, help="Pinned native-runtime commit")
    parser.add_argument("--destination", required=True, help="Fresh private UNC release_inputs child")
    parser.add_argument("--r81-dataset-root", required=True, help="Fresh private UNC R81 dataset path")
    return parser


def main() -> int:
    result = bind(_parser().parse_args())
    print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
