from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
watch_source = ROOT / 'tmp/r80_factory_20261007/controller_diverse_sm_v1/watch_status.json'
watch_bytes = watch_source.read_bytes()
watch = json.loads(watch_bytes)
assert watch['status'] == 'symmetry_collection_complete'
assert watch['valid_unique'] == 5000
assert watch['launch_id'] == '5a181a47c95a4ab1a8377d803f9da3c1'
assert watch['settings_sha256'] == '4d323a7bbad61218e473dc9d1586cd77dd970199bd3c9864c34a2f4ad93b0a38'
action_source = Path(watch['last_receipt'])
action_bytes = action_source.read_bytes()
sha = lambda b: hashlib.sha256(b).hexdigest()
assert sha(action_bytes) == watch['last_receipt_sha256'] == '6dfab17ee6db6eb66a1ddca3a9218bdb23cb2082f6d1932ebf1faa12c42b8916'
action = json.loads(action_bytes)
assert action['status'] == 'idle'
assert action['valid_unique'] == action['target_valid_unique'] == 5000
assert action['pending_unique'] == 0 and action['planned_jobs'] == []
assert action['audit']['valid_unique_patterns'] == 5000
for name, data in [('watch_status.json', watch_bytes), ('action_receipt.json', action_bytes)]:
    with (HERE / name).open('xb') as stream:
        stream.write(data)
assert watch_source.read_bytes() == watch_bytes
assert action_source.read_bytes() == action_bytes
report = {'status': 'terminal_native_watch_and_action_saved',
          'watch_snapshot': str(HERE / 'watch_status.json'), 'watch_sha256': sha(watch_bytes),
          'action_snapshot': str(HERE / 'action_receipt.json'), 'action_producer_path': str(action_source),
          'action_sha256': sha(action_bytes), 'valid_unique': 5000, 'pending_unique': 0,
          'finished_utc': watch['finished_utc'], 'latest_data_version': watch['latest_data_version'],
          'queue_or_marker_mutation': False, 'worker_or_hfss_started': False}
with (HERE / 'capture_receipt.json').open('x', encoding='utf8') as stream:
    json.dump(report, stream, ensure_ascii=False, indent=2)
print(json.dumps(report, ensure_ascii=False))
