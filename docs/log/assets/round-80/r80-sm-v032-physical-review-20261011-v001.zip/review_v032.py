from __future__ import annotations

import hashlib
import json
import math
import sys
import time
from pathlib import Path

import torch


REPO = Path(__file__).resolve().parents[2]
if str(REPO) not in sys.path:
    sys.path.insert(0, str(REPO))

from script import exploration
from script import symmetry_training as training


ROOT = REPO / "tmp" / "r80_factory_20261007" / "training_familydev_v1"
CYCLE_ID = "0dcc7ec592d614214817cf3e3117ab8460c18355eb13b9e758160b6c8ac9a94f"
CYCLE = (
    REPO
    / "tmp"
    / "r80_factory_20261007"
    / "controller_diverse_sm_v1"
    / "cycles"
    / CYCLE_ID
    / "action_receipt.json"
)
SNAPSHOT = CYCLE.parent / "training_snapshot"
HEALTH = (
    REPO
    / "tmp"
    / "r80_restored_health_20261010_v005"
    / "health_restored_20261011_0604.json"
)
INCREMENT = (
    REPO
    / "tmp"
    / "r80_increment_best_monitor_20261010_v001"
    / "increment_0dcc7ec5_20261011.json"
)
PRIOR_REVIEW = (
    REPO
    / "tmp"
    / "r80_sm_v029_physical_review_20261011_v001"
    / "physical_checks.json"
)
OUT = Path(__file__).with_name("physical_checks.json")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def tensor_digest(state: dict[str, torch.Tensor]) -> str:
    digest = hashlib.sha256()
    for name in sorted(state):
        tensor = state[name].detach().cpu().contiguous()
        digest.update(name.encode("utf-8"))
        digest.update(str(tensor.dtype).encode("ascii"))
        digest.update(json.dumps(list(tensor.shape)).encode("ascii"))
        digest.update(tensor.numpy().tobytes())
    return digest.hexdigest()


def aliases(row: dict) -> set[str]:
    return {str(row["lineage_id"]), str(row.get("canonical_group_id", row["lineage_id"]))}


def rel(path: Path) -> str:
    return str(path.relative_to(REPO)).replace("\\", "/")


def main() -> None:
    started = time.time()
    protocol_path = ROOT / "protocol.json"
    legacy_path = ROOT / "legacy" / "manifest.json"
    manifest_paths = {v: ROOT / "data" / f"data-v{v:03d}" / "manifest.json" for v in (29, 30, 31, 32)}
    receipt_paths = {v: ROOT / "data" / f"data-v{v:03d}" / "receipt.json" for v in (29, 30, 31, 32)}
    summary_path = ROOT / "models" / "data-v032" / "summary.json"
    member_paths = [ROOT / "models" / "data-v032" / f"member-{seed}.pt" for seed in (0, 1, 2)]
    prior_member0_path = ROOT / "models" / "data-v029" / "member-0.pt"
    snapshot_meta_paths = [SNAPSHOT / name for name in ("manifest.json", "results.json", "source_bindings.json")]
    source_paths = [REPO / "script" / "symmetry_training.py", REPO / "script" / "exploration.py"]
    bound_paths = [
        protocol_path,
        legacy_path,
        *manifest_paths.values(),
        *receipt_paths.values(),
        summary_path,
        *member_paths,
        prior_member0_path,
        CYCLE,
        HEALTH,
        INCREMENT,
        PRIOR_REVIEW,
        *snapshot_meta_paths,
        *source_paths,
    ]
    hashes_before = {rel(path): sha256(path) for path in bound_paths}

    protocol = read_json(protocol_path)
    legacy = read_json(legacy_path)
    rows = {v: read_json(path) for v, path in manifest_paths.items()}
    receipts = {v: read_json(path) for v, path in receipt_paths.items()}
    summary = read_json(summary_path)
    cycle = read_json(CYCLE)
    health = read_json(HEALTH)
    increment = read_json(INCREMENT)
    prior_review = read_json(PRIOR_REVIEW)
    snapshot_manifest = read_json(SNAPSHOT / "manifest.json")

    checks: dict[str, bool] = {}
    checks["prior_v029_physical_review_passed"] = (
        prior_review["status"] == "passed"
        and prior_review["failures"] == []
        and len(prior_review["checks"]) == 43
    )
    checks["prior_v029_norm_baseline_hash_exact"] = (
        hashes_before[rel(prior_member0_path)]
        == prior_review["hashes_after"][rel(prior_member0_path)]
    )
    checks["protocol_id_exact"] = (
        exploration.content_id({k: value for k, value in protocol.items() if k != "protocol_id"})
        == protocol["protocol_id"]
    )
    expected_receipts = {
        29: (4009, 92),
        30: (4063, 54),
        31: (4144, 81),
        32: (4232, 88),
    }
    for version in (29, 30, 31, 32):
        receipt = receipts[version]
        cumulative, new = expected_receipts[version]
        checks[f"v{version:03d}_manifest_id_exact"] = (
            exploration.content_id(rows[version]) == receipt["manifest_id"]
        )
        checks[f"v{version:03d}_receipt_counts_exact"] = (
            receipt["data_version"] == version
            and len(rows[version]) == receipt["cumulative_observations"] == cumulative
            and receipt["cumulative_valid_unique"] == cumulative
            and receipt["new_observations"] == receipt["new_valid_unique"] == new
        )

    indexed = {version: {row["id"]: row for row in manifest} for version, manifest in rows.items()}
    checks["all_manifest_ids_unique"] = all(len(indexed[v]) == len(rows[v]) for v in indexed)
    checks["v029_rows_semantically_frozen_through_v032"] = all(
        indexed[version].get(key) == value
        for version in (30, 31, 32)
        for key, value in indexed[29].items()
    )
    checks["successive_old_rows_semantically_frozen"] = all(
        indexed[newer].get(key) == value
        for older, newer in ((29, 30), (30, 31), (31, 32))
        for key, value in indexed[older].items()
    )
    version_deltas = {
        f"v{older:03d}_to_v{newer:03d}": sorted(set(indexed[newer]) - set(indexed[older]))
        for older, newer in ((29, 30), (30, 31), (31, 32))
    }
    delta29_32_ids = sorted(set(indexed[32]) - set(indexed[29]))
    checks["successive_delta_counts_exact"] = [len(value) for value in version_deltas.values()] == [54, 81, 88]
    checks["cumulative_v029_to_v032_delta_exact"] = (
        len(delta29_32_ids) == 223 and not (set(indexed[29]) - set(indexed[32]))
    )

    patterns = {version: {row["pattern_sha256"] for row in manifest} for version, manifest in rows.items()}
    added_patterns = {indexed[32][key]["pattern_sha256"] for key in delta29_32_ids}
    checks["all_v032_patterns_unique"] = len(patterns[32]) == len(rows[32])
    checks["cumulative_added_patterns_new_unique"] = (
        len(added_patterns) == 223 and not (added_patterns & patterns[29])
    )

    added_rows = [indexed[32][key] for key in delta29_32_ids]
    added_source_ids = {row["source_observation_id"] for row in added_rows}
    added_sample_files = {row["sample_file"] for row in added_rows}
    added_rad_files = {row["rad_file"] for row in added_rows}
    checks["added_raw_bindings_unique"] = (
        len(added_source_ids) == len(added_sample_files) == len(added_rad_files) == 223
    )
    checks["added_raw_names_match_declared_hashes"] = all(
        Path(row["sample_file"]).stem == row["source_sample_sha256"]
        and Path(row["rad_file"]).stem == row["source_rad_sha256"]
        for row in added_rows
    )
    checks["added_raw_files_exist"] = all(
        (ROOT / row["sample_file"]).is_file() and (ROOT / row["rad_file"]).is_file()
        for row in added_rows
    )
    checks["added_raw_file_hashes_exact"] = all(
        sha256(ROOT / row["sample_file"]) == row["source_sample_sha256"]
        and sha256(ROOT / row["rad_file"]) == row["source_rad_sha256"]
        for row in added_rows
    )

    train_rows = [row for row in rows[32] if row["split"] == "profile_train"]
    hold_rows = [row for row in rows[32] if row["split"] == "profile_holdout"]
    added_train = [row for row in added_rows if row["split"] == "profile_train"]
    added_hold = [row for row in added_rows if row["split"] == "profile_holdout"]
    train_aliases = set().union(*(aliases(row) for row in train_rows))
    hold_aliases = set().union(*(aliases(row) for row in hold_rows))
    train_patterns = {row["pattern_sha256"] for row in train_rows}
    hold_patterns = {row["pattern_sha256"] for row in hold_rows}
    checks["profile_train_holdout_alias_separated"] = not (train_aliases & hold_aliases)
    checks["profile_train_holdout_pattern_separated"] = not (train_patterns & hold_patterns)
    checks["profile_split_counts_exact"] = len(train_rows) == 3186 and len(hold_rows) == 1046
    checks["delta_split_counts_exact"] = len(added_train) == 189 and len(added_hold) == 34
    checks["summary_profile_ids_exact"] = (
        summary["profile_train_ids"] == [row["id"] for row in train_rows]
        and summary["profile_holdout_ids"] == [row["id"] for row in hold_rows]
    )

    legacy_train = [row for row in legacy if row["split"] == "legacy_train"]
    legacy_hold = [row for row in legacy if row["split"] == "legacy_holdout"]
    legacy_train_aliases = {str(row["lineage_id"]) for row in legacy_train}
    legacy_hold_aliases = {str(row["lineage_id"]) for row in legacy_hold}
    checks["legacy_train_holdout_family_separated"] = not (legacy_train_aliases & legacy_hold_aliases)
    current_hold_groups = (
        {str(row["canonical_group_id"]) for row in hold_rows}
        | {str(row["lineage_id"]) for row in hold_rows}
    )
    expected_legacy_exclusions = [
        row["id"]
        for row in legacy_train
        if row["pattern_sha256"] in hold_patterns or str(row["lineage_id"]) in current_hold_groups
    ]
    usable_legacy_count = len(legacy_train) - len(expected_legacy_exclusions)
    checks["legacy_current_holdout_exclusion_exact"] = (
        summary["legacy_train_exclusions_for_current_holdout"] == expected_legacy_exclusions
    )
    checks["summary_counts_exact"] = summary["counts"] == {
        "profile_train": len(train_rows),
        "profile_holdout": len(hold_rows),
        "legacy_train": usable_legacy_count,
        "legacy_holdout": len(legacy_hold),
    }

    expected_binding = {
        "measurement_id": protocol["measurement_id"],
        "score_spec_id": protocol["score_spec_id"],
        "protocol_id": protocol["protocol_id"],
        "data_version": 32,
        "manifest_id": receipts[32]["manifest_id"],
        "cumulative_valid_unique": receipts[32]["cumulative_valid_unique"],
    }
    checks["summary_binding_exact"] = summary["binding"] == expected_binding
    checks["summary_protocol_manifest_exact"] = (
        summary["protocol_id"] == protocol["protocol_id"]
        and summary["manifest_id"] == receipts[32]["manifest_id"]
        and summary["data_version"] == 32
    )
    checks["summary_member_seeds_exact"] = summary["member_seeds"] == [0, 1, 2]
    cycle_summary = cycle["trained_model_summary"]
    checks["cycle_completed_model_binding_exact"] = (
        cycle["cycle_id"] == CYCLE_ID
        and cycle["latest_data_version"] == 32
        and cycle["trained_this_cycle"] is True
        and cycle["new_unique_available_before_training"] == 88
        and cycle_summary["binding"] == expected_binding
        and cycle_summary["sha256"] == sha256(summary_path)
        and Path(cycle_summary["path"]).resolve() == summary_path.resolve()
        and cycle["predictor_binding"] == expected_binding
    )
    health_watch = health["watch_status"]
    checks["health_completed_cycle_binding_exact"] = (
        health["new_launch_id"] == "5a181a47c95a4ab1a8377d803f9da3c1"
        and health["runtime_file_bindings_verified"] == 19
        and Path(health_watch["last_receipt"]).resolve() == CYCLE.resolve()
        and health_watch["last_receipt_sha256"] == sha256(CYCLE)
        and health_watch["latest_data_version"] == 32
        and health_watch["valid_unique"] == cycle["valid_unique"] == 4243
    )

    snapshot_hashes = {path.name: sha256(path) for path in snapshot_meta_paths}
    snapshot_patterns = {row["pattern_sha256"] for row in snapshot_manifest}
    v31_v32_patterns = {indexed[32][key]["pattern_sha256"] for key in version_deltas["v031_to_v032"]}
    checks["current_cycle_snapshot_metadata_exact"] = (
        cycle["training_snapshot"]["count"] == len(snapshot_manifest) == 88
        and cycle["training_snapshot"]["manifest_sha256"] == snapshot_hashes["manifest.json"]
        and cycle["training_snapshot"]["results_sha256"] == snapshot_hashes["results.json"]
        and cycle["training_snapshot"]["source_bindings_sha256"] == snapshot_hashes["source_bindings.json"]
        and snapshot_patterns == v31_v32_patterns
    )
    checks["existing_increment_replay_bound_without_raw_repeat"] = (
        increment["status"] == "passed_local_existing_increment_raw_replay"
        and increment["cycle_id"] == CYCLE_ID
        and increment["completed_cycle_receipt"]["sha256"] == sha256(CYCLE)
        and increment["existing_training_snapshot"]["count"] == 88
        and increment["existing_training_snapshot"]["hashes"] == snapshot_hashes
        and increment["raw_rows_replayed"] == 88
        and increment["positive_rows"] == 0
        and increment["requires_full_census"] is False
    )

    cfg = protocol["model"]
    expected_steps = (
        math.ceil(usable_legacy_count / cfg["batch_size"]) * cfg["legacy_epochs"]
        + math.ceil(len(train_rows) / cfg["batch_size"]) * cfg["current_epochs"]
    )
    member_results = []
    saved_checkpoints = []
    for seed, path, model_entry in zip((0, 1, 2), member_paths, summary["member_models"]):
        actual_hash = sha256(path)
        saved = torch.load(path, weights_only=False, map_location="cpu")
        saved_checkpoints.append(saved)
        expected_signature = exploration.content_id(
            {
                "protocol_id": protocol["protocol_id"],
                "manifest_id": receipts[32]["manifest_id"],
                "legacy_manifest_id": summary["legacy_manifest_id"],
                "member_seed": seed,
            }
        )
        optimizer = saved["optimizer_state"]
        steps = sorted({int(value["step"].item()) for value in optimizer["state"].values()})
        optimizer_finite = all(
            torch.isfinite(tensor).all().item()
            for value in optimizer["state"].values()
            for key, tensor in value.items()
            if key in {"exp_avg", "exp_avg_sq"}
        )
        model_finite = all(torch.isfinite(tensor).all().item() for tensor in saved["model_state"].values())
        member_results.append(
            {
                "member_seed": seed,
                "file_sha256": actual_hash,
                "summary_hash_match": model_entry == {"member_seed": seed, "file": path.name, "sha256": actual_hash},
                "signature": saved["signature"],
                "signature_match": saved["signature"] == expected_signature,
                "binding_match": saved["binding"] == expected_binding,
                "legacy_manifest_match": saved["legacy_manifest_id"] == summary["legacy_manifest_id"],
                "development_metadata_match": saved.get("development_training") == summary.get("development_training"),
                "complete": saved["complete"] is True,
                "fresh_initialization_metadata": saved["fresh_initialization"] is True,
                "phase_names": saved["phase_names"],
                "terminal_phase": int(saved["phase"]),
                "terminal_epoch": int(saved["epoch"]),
                "optimizer_steps": steps,
                "expected_optimizer_steps": expected_steps,
                "optimizer_steps_match": steps == [expected_steps],
                "optimizer_state_entries": len(optimizer["state"]),
                "optimizer_moments_finite": optimizer_finite,
                "model_tensor_count": len(saved["model_state"]),
                "model_tensors_finite": model_finite,
                "model_tensor_digest": tensor_digest(saved["model_state"]),
            }
        )

    checks["member_hashes_exact"] = all(row["summary_hash_match"] for row in member_results)
    checks["checkpoint_signatures_exact_unique"] = (
        all(row["signature_match"] for row in member_results)
        and len({row["signature"] for row in member_results}) == 3
    )
    checks["checkpoint_bindings_and_metadata_exact"] = all(
        row["binding_match"] and row["legacy_manifest_match"] and row["development_metadata_match"]
        for row in member_results
    )
    checks["checkpoint_complete_terminal_phases"] = all(
        row["complete"]
        and row["phase_names"] == ["legacy_pretrain", "current_profile"]
        and row["terminal_phase"] == 2
        and row["terminal_epoch"] == 0
        for row in member_results
    )
    checks["checkpoint_optimizer_steps_exact"] = all(row["optimizer_steps_match"] for row in member_results)
    checks["checkpoint_tensors_finite"] = all(
        row["optimizer_moments_finite"] and row["model_tensors_finite"] for row in member_results
    )
    checks["checkpoint_member_seeds_exact_distinct"] = (
        all(int(saved["member_seed"]) == seed for seed, saved in zip((0, 1, 2), saved_checkpoints))
        and len({row["model_tensor_digest"] for row in member_results}) == 3
    )
    checks["protocol_fresh_training_contract_exact"] = (
        cfg["legacy_epochs"] == 30
        and cfg["current_epochs"] == 100
        and protocol["policy"]["fresh_initialization_each_version"] is True
        and protocol["policy"]["early_stopping"] is False
        and all(saved["fresh_initialization"] is True for saved in saved_checkpoints)
    )

    checks["checkpoint_train_only_norm_identical_across_members"] = all(
        all(torch.equal(a, b) for a, b in zip(saved_checkpoints[0][name], saved[name]))
        for saved in saved_checkpoints[1:]
        for name in ("input_norm", "target_norm")
    )
    added_train_loaded = training._load_dataset(
        ROOT, added_rows, "profile_train", protocol["frequencies_ghz"]
    )
    old_checkpoint = torch.load(prior_member0_path, weights_only=False, map_location="cpu")
    incremental_norm_diffs: dict[str, dict[str, float]] = {}
    for name, added_tensor in (("input_norm", added_train_loaded[0]), ("target_norm", added_train_loaded[1])):
        old_mean, old_std = old_checkpoint[name]
        new_mean, new_std = saved_checkpoints[0][name]
        old_variance = torch.where(old_std == 1, torch.zeros_like(old_std), old_std.square())
        added_mean = added_tensor.mean(dim=0)
        added_variance = added_tensor.var(dim=0, unbiased=False)
        old_count = len([row for row in rows[29] if row["split"] == "profile_train"])
        added_count = len(added_train_loaded[2])
        combined_count = old_count + added_count
        combined_mean = (old_mean * old_count + added_mean * added_count) / combined_count
        combined_variance = (
            (old_variance + old_mean.square()) * old_count
            + (added_variance + added_mean.square()) * added_count
        ) / combined_count - combined_mean.square()
        combined_std = combined_variance.clamp_min(0).sqrt()
        combined_std[combined_std < 1e-6] = 1.0
        incremental_norm_diffs[name] = {
            "mean_max_abs_diff": float((combined_mean - new_mean).abs().max().item()),
            "std_max_abs_diff": float((combined_std - new_std).abs().max().item()),
        }
    checks["incremental_train_only_norm_reconstruction_float32_tolerance"] = (
        incremental_norm_diffs["input_norm"]["mean_max_abs_diff"] <= 1e-6
        and incremental_norm_diffs["input_norm"]["std_max_abs_diff"] <= 1e-6
        and incremental_norm_diffs["target_norm"]["mean_max_abs_diff"] <= 2e-6
        and incremental_norm_diffs["target_norm"]["std_max_abs_diff"] <= 1e-6
    )

    hashes_after = {rel(path): sha256(path) for path in bound_paths}
    checks["all_bound_bytes_unchanged_during_review"] = hashes_before == hashes_after
    failures = sorted(name for name, passed in checks.items() if not passed)
    result = {
        "schema_version": 1,
        "kind": "r80_sm_v032_saved_physical_checks_v001",
        "status": "passed" if not failures else "failed",
        "scope": "one bounded completed data-v029 to data-v032/model-v032 physical review; the distinct 88-row current-cycle snapshot is metadata-bound to the existing raw replay without repeating raw WM/radiation work",
        "hashes_before": hashes_before,
        "hashes_after": hashes_after,
        "completed_cycle": {
            "cycle_id": cycle["cycle_id"],
            "action_receipt_sha256": sha256(CYCLE),
            "status": cycle["status"],
            "trained_this_cycle": cycle["trained_this_cycle"],
            "latest_data_version": cycle["latest_data_version"],
            "trained_model_summary_sha256": cycle_summary["sha256"],
            "fitted_model_cumulative_valid_unique": receipts[32]["cumulative_valid_unique"],
            "action_cutoff_valid_unique": cycle["valid_unique"],
            "health_observed_utc": health["observed_utc"],
            "health_last_completed_utc": health_watch["last_completed_utc"],
        },
        "version_growth": {
            "v029_rows": len(rows[29]),
            "v030_rows": len(rows[30]),
            "v031_rows": len(rows[31]),
            "v032_rows": len(rows[32]),
            "versions_advanced": 3,
            "successive_new_rows": [54, 81, 88],
            "cumulative_new_rows": len(delta29_32_ids),
            "cumulative_new_patterns": len(added_patterns),
            "cumulative_new_profile_train": len(added_train),
            "cumulative_new_profile_holdout": len(added_hold),
        },
        "current_cycle_snapshot": {
            "count": len(snapshot_manifest),
            "metadata_hashes": snapshot_hashes,
            "patterns_equal_v031_to_v032_delta": snapshot_patterns == v31_v32_patterns,
            "existing_increment_replay_sha256": sha256(INCREMENT),
            "existing_increment_positive_rows": increment["positive_rows"],
            "existing_increment_best_factory_margin_db": increment["increment_best"]["factory_margin_db"],
            "raw_replayed_by_this_review": False,
        },
        "added_raw_bindings": {
            "source_observation_ids": len(added_source_ids),
            "sample_files": len(added_sample_files),
            "radiation_files": len(added_rad_files),
            "all_names_match_declared_hashes": checks["added_raw_names_match_declared_hashes"],
            "all_files_exist": checks["added_raw_files_exist"],
            "all_446_file_sha256_values_match_manifest": checks["added_raw_file_hashes_exact"],
        },
        "split_findings": {
            "profile_train": len(train_rows),
            "profile_holdout": len(hold_rows),
            "profile_train_aliases": len(train_aliases),
            "profile_holdout_aliases": len(hold_aliases),
            "alias_overlap": sorted(train_aliases & hold_aliases),
            "pattern_overlap_count": len(train_patterns & hold_patterns),
            "legacy_train": usable_legacy_count,
            "legacy_holdout": len(legacy_hold),
            "legacy_train_exclusions_for_current_holdout": len(expected_legacy_exclusions),
        },
        "training_contract": {
            "legacy_epochs": cfg["legacy_epochs"],
            "current_epochs": cfg["current_epochs"],
            "batch_size": cfg["batch_size"],
            "legacy_train_rows": usable_legacy_count,
            "current_train_rows": len(train_rows),
            "expected_optimizer_steps": expected_steps,
            "normalization_source": "saved norms are byte-identical across all three members; incremental reconstruction used the frozen v029 train-only norm plus only 189 newly added train rows",
            "incremental_norm_float32_max_abs_diffs": incremental_norm_diffs,
            "separate_per_epoch_log_present": False,
        },
        "members": member_results,
        "checks": checks,
        "failures": failures,
        "limits": [
            "No model was instantiated and no forward, inference, training, prediction, HFSS, NAS, process, dispatch, worker, queue, marker, source or runtime mutation was run.",
            "The prior v029 43-check audit was not rerun. Its saved receipt/hash is bound, prior manifest rows are compared semantically, and only the 223 new v029-to-v032 sample/radiation pairs were freshly hashed.",
            "The 88-row current-cycle raw WM/radiation replay was not repeated. This review binds the immutable snapshot metadata to the existing replay, which reported zero positive rows and best factory margin -4.3684728145599365 dB.",
            "The train-only norms are byte-identical across all three v032 members. Because the v029 saved norm is float32 aggregate metadata rather than the original unreduced tensors, the incremental reconstruction from only 189 new train rows differs by at most 1.9073486328125e-06; unchanged raw rows were deliberately not reread.",
            "Fresh initialization is supported by protocol/checkpoint metadata, unique signatures and distinct terminal tensor digests. Initial pre-training tensor bytes are not saved and were not independently replayed.",
            "The 30+100 epoch history is supported by protocol, terminal phase metadata and exact Adam step tensors. No separate per-epoch log exists and no per-epoch history claim is made.",
            "Saved metrics/accuracy were not recomputed because that would require model forward inference. No model-quality, SM-improvement, causal-improvement or best-trigger claim is made.",
            "The descriptive development holdout is not an untouched independent validation set.",
            "The fitted v032 model binds 4,232 unique rows. The same completed action receipt reports a later 4,243 valid-unique cutoff; that later count is not substituted into the model binding.",
        ],
        "elapsed_seconds": time.time() - started,
    }
    OUT.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"status": result["status"], "failures": failures, "check_count": len(checks), "elapsed_seconds": result["elapsed_seconds"]}, sort_keys=True))


if __name__ == "__main__":
    main()
