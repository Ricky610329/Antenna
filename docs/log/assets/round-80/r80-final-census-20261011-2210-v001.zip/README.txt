R80 saved final census, cutoff 2026-10-11 22:10 Taipei.
5000 unique / 5005 successful raw observations; four COM errors excluded.
This is saved summary/rows/proof/source evidence, not the full raw dataset archive.
Native final watch/action gate and R80 complete freeze/statistics remain separate.
Paths preserve original repo-relative producer layout; no live queue or markers changed.
