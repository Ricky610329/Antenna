import hashlib
import json
import math
import re
from datetime import datetime, timezone
from pathlib import Path

from antenna.measurement import measurement_id, score_spec_id
from script import profiled_batch as pb


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
SOURCE = ROOT / "tmp/r80_best_render_20261011_v036"
OUTPUT = HERE / "final_census_status_ready.json"

EXPECTED_QUERY_SHA256 = "da6a0034241d4d6f22ecfd1ce0272b4dbd06ec252737278b0539b4bec2b631ac"
EXPECTED_R81_ENTRY_SHA256 = "cd578a22c4f0ca33374bee12cee0c2b7ada1a98abc54530a2f54a3fb79aa023c"
TARGET_UNIQUE = 5000
HEX64 = re.compile(r"[0-9a-f]{64}")


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def relative(path: Path) -> str:
    return path.relative_to(ROOT).as_posix()


def bound(path: Path) -> dict[str, object]:
    return {"repo_path": relative(path), "sha256": sha256(path), "bytes": path.stat().st_size}


def assert_hex_map(value: object, expected_keys: set[str], label: str) -> None:
    assert isinstance(value, dict), f"{label} is not an object"
    assert set(value) == expected_keys, f"{label} keys differ"
    assert all(isinstance(v, str) and HEX64.fullmatch(v) for v in value.values()), label


required = [SOURCE / name for name in
            ("report.json", "rows.json", "pair_proofs.json", "query_and_freeze.py")]
assert all(path.is_file() for path in required), "v036 saved census is not complete"
assert not OUTPUT.exists(), "refusing to overwrite an existing validation result"

report_path, rows_path, proofs_path, query_path = required
assert sha256(query_path) == EXPECTED_QUERY_SHA256
assert report_path.stat().st_mtime_ns >= rows_path.stat().st_mtime_ns
assert report_path.stat().st_mtime_ns >= proofs_path.stat().st_mtime_ns

report = read_json(report_path)
rows = read_json(rows_path)
proofs = read_json(proofs_path)
assert isinstance(report, dict) and isinstance(rows, list) and isinstance(proofs, list)
assert report["status"] == "read_only_query_complete"
assert report["query_script_sha256"] == EXPECTED_QUERY_SHA256
assert report["rows_sha256"] == sha256(rows_path)
assert report["pair_proofs_sha256"] == sha256(proofs_path)
assert report["controller_locks_acquired"] is False
assert report["queue_or_source_mutation"] is False
assert report["exact_prior_metrics_reused"] == 0
assert report["reported_best_independently_raw_replayed"] is True
assert report["raw_replayed_this_query"] == report["successful_including_repeats"] == len(rows)
assert isinstance(report["jobs_sha256_at_scan_start"], str)
assert HEX64.fullmatch(report["jobs_sha256_at_scan_start"])

profile_path = ROOT / "configs/single_r80_symmetry_factory.yaml"
profile = pb.load_profile_config(profile_path)
mid = measurement_id(profile.measurement)
sid = score_spec_id(profile.score_spec)
assert profile.port == "single" and profile.scope == "symmetry_filter_20261007"
assert report["measurement_id"] == mid and report["score_spec_id"] == sid

expected_rows: dict[tuple[str, str], tuple[int, int, dict, dict]] = {}
error_rows = []
manifest_row_count = 0
result_entry_count = 0
successful_result_count = 0
proof_stores: set[str] = set()
input_keys = {"config.yaml", "measurement.json", "score_spec.json", "manifest.json"}
store_keys = {"measurement.json", "score_spec.json", "manifest.json", "results.json"}

for proof in proofs:
    assert isinstance(proof, dict) and set(proof) == {
        "input", "store", "rows", "results", "input_metadata_sha256",
        "store_metadata_sha256",
    }
    store = Path(proof["store"]).name
    assert store and store not in proof_stores
    proof_stores.add(store)
    manifest = proof["rows"]
    results = proof["results"]
    assert isinstance(manifest, list) and isinstance(results, dict)
    assert_hex_map(proof["input_metadata_sha256"], input_keys, "input metadata hashes")
    assert_hex_map(proof["store_metadata_sha256"], store_keys, "store metadata hashes")
    assert (proof["input_metadata_sha256"]["manifest.json"] ==
            proof["store_metadata_sha256"]["manifest.json"])
    ids = [row["id"] for row in manifest]
    assert len(ids) == len(set(ids))
    assert set(results) <= set(ids)
    manifest_row_count += len(manifest)
    result_entry_count += len(results)
    for row_index, manifest_row in enumerate(manifest):
        assert manifest_row["measurement_id"] == mid
        assert manifest_row["score_spec_id"] == sid
        assert manifest_row["port"] == "single"
        assert HEX64.fullmatch(manifest_row["pattern_sha256"])
        entry = results.get(manifest_row["id"])
        if entry is None:
            continue
        assert isinstance(entry, dict)
        if "error" in entry:
            error_rows.append({"store": store, "id": manifest_row["id"], "entry": entry})
            continue
        assert entry["status"] == "ok"
        assert entry["measurement_id"] == mid and entry["score_spec_id"] == sid
        assert entry["pattern_sha256"] == manifest_row["pattern_sha256"]
        if "lineage_id" in manifest_row:
            assert entry["lineage_id"] == manifest_row["lineage_id"]
        assert HEX64.fullmatch(entry["sample_sha256"])
        assert HEX64.fullmatch(entry["rad_sha256"])
        key = (store, manifest_row["id"])
        assert key not in expected_rows
        expected_rows[key] = (len(expected_rows), row_index, manifest_row, entry)
        successful_result_count += 1

assert successful_result_count == len(rows)
assert report["result_errors"] == error_rows
assert len({(row["store"], row["id"]) for row in rows}) == len(rows)
assert [(row["pair_index"], row["row_index"]) for row in rows] == sorted(
    (row["pair_index"], row["row_index"]) for row in rows)

unique: dict[str, tuple[tuple[bool, int, int], dict]] = {}
repeat_rows = 0
for saved_row in rows:
    key = (saved_row["store"], saved_row["id"])
    assert key in expected_rows
    _ordinal, row_index, manifest_row, entry = expected_rows[key]
    assert saved_row["row_index"] == row_index
    assert saved_row["pattern_sha256"] == manifest_row["pattern_sha256"]
    assert saved_row["sample_sha256"] == entry["sample_sha256"]
    assert saved_row["rad_sha256"] == entry["rad_sha256"]
    expected_repeat = manifest_row.get("kind") in ("repeat", "notarize")
    assert saved_row["repeat"] is expected_repeat
    repeat_rows += int(expected_repeat)
    for name in ("s11_margin_db", "gain_margin_db", "factory_margin_db",
                 "radiation_margin_db", "radiation_margin_clipped_db"):
        assert isinstance(saved_row[name], (int, float)) and math.isfinite(saved_row[name])
    assert saved_row["factory_margin_db"] == min(
        saved_row["s11_margin_db"], saved_row["gain_margin_db"])
    priority = (saved_row["repeat"], saved_row["pair_index"], saved_row["row_index"])
    pattern = saved_row["pattern_sha256"]
    if pattern not in unique or priority < unique[pattern][0]:
        unique[pattern] = (priority, saved_row)

assert len(unique) == report["unique_successful_patterns"] == TARGET_UNIQUE
duplicate_raw_observations = len(rows) - len(unique)
nonrepeat_patterns = {row["pattern_sha256"] for row in rows if not row["repeat"]}
assert all(row["pattern_sha256"] in nonrepeat_patterns for row in rows if row["repeat"])
assert duplicate_raw_observations == repeat_rows

best = max((item[1] for item in unique.values()), key=lambda row: row["factory_margin_db"])
for name, value in best.items():
    if name in report["best"]:
        assert report["best"][name] == value
assert report["best"]["factory_margin_db"] == min(
    -10 - report["best"]["worst_inband_s11_db"],
    report["best"]["minimum_inband_gain_dbi"] - 4,
)

prior_path = ROOT / "docs/log/assets/r80_best_status_20261011_0744.json"
prior = read_json(prior_path)
best_identity = ("id", "pattern_sha256", "sample_sha256", "rad_sha256", "factory_margin_db")
assert all(report["best"][name] == prior["best"][name] for name in best_identity), (
    "new best requires a new summary/polar workflow before final status can be prepared"
)

polar_dir = ROOT / "docs/log/assets/round-80/best-symmetric-polar-20261009-v006"
polar_query_path = polar_dir / "best_query_receipt.json"
polar_plot_path = polar_dir / "sample_plot_receipt.json"
polar_figure_path = polar_dir / "sample_card.png"
polar_query = read_json(polar_query_path)
polar_plot = read_json(polar_plot_path)
for name in best_identity:
    if name in polar_query["best"]:
        assert polar_query["best"][name] == report["best"][name]
assert polar_plot["sample_id"] == report["best"]["id"]
assert polar_plot["pattern_sha256"] == report["best"]["pattern_sha256"]
assert polar_plot["sample_sha256"] == report["best"]["sample_sha256"]
assert polar_plot["radiation_sha256"] == report["best"]["rad_sha256"]
assert polar_plot["figure_sha256"] == sha256(polar_figure_path)

r81_entry_path = ROOT / "script/r81_worker_entry.py"
assert sha256(r81_entry_path) == EXPECTED_R81_ENTRY_SHA256

record = dict(report)
record.update({
    "validation_status": "passed_saved_raw_summary_validation",
    "validation_source_version": "r80_final_saved_census_v1",
    "validation_completed_utc": datetime.now(timezone.utc).isoformat(),
    "target_unique": TARGET_UNIQUE,
    "query_report_sha256": sha256(report_path),
    "validation_script_sha256": sha256(Path(__file__)),
    "query_evidence": {
        "raw_report": bound(report_path),
        "rows": bound(rows_path),
        "pair_proofs": bound(proofs_path),
        "query_producer": bound(query_path),
    },
    "validation_results": {
        "proof_store_count": len(proofs),
        "manifest_row_count": manifest_row_count,
        "result_entry_count": result_entry_count,
        "successful_result_count": successful_result_count,
        "raw_row_count": len(rows),
        "unique_pattern_count": len(unique),
        "repeat_observation_count": repeat_rows,
        "duplicate_raw_observation_count": duplicate_raw_observations,
        "result_error_count": len(error_rows),
        "all_manifest_rows_match_measurement_and_score_spec": True,
        "all_successful_results_match_measurement_and_score_spec": True,
        "all_saved_rows_link_to_saved_success_results": True,
        "best_recomputed_from_unique_saved_rows": True,
        "best_independently_raw_replayed_in_query": True,
        "cached_or_prior_metric_rows_used": 0,
    },
    "prior_historical_census": bound(prior_path),
    "prior_historical_unique": prior["unique_successful_patterns"],
    "new_unique_since_prior_historical_census": len(unique) - prior["unique_successful_patterns"],
    "new_best_since_prior_historical_census": False,
    "best_summary_reference": bound(polar_query_path),
    "best_polar_reference": {
        "plot_receipt": bound(polar_plot_path),
        "figure": bound(polar_figure_path),
        "unchanged_best_figure_reused": True,
    },
    "profile_reference": bound(profile_path),
    "r81_closeout_entry_reference": bound(r81_entry_path),
    "full_dataset_archive_created": False,
    "native_final_gate_complete": False,
    "native_terminal_watch_or_action_validated_here": False,
    "runtime_or_queue_or_markers_mutated": False,
    "model_forward_or_training_run": False,
    "nas_source_data_replayed_by_validator": False,
    "limits_additional": [
        "This validates the saved v036 raw summary, rows and pair proofs only; it does not create or validate a full dataset archive.",
        "It does not assert that the native watcher/action final gate has completed; the last completed native watch before this query was 4998/v43 while its current cycle was still running.",
        "Saved pair-proof structure, identities and hashes were checked without reopening source/store paths or replaying model/HFSS computations.",
        "The unchanged best polar figure represents one frozen HFSS solve plus the separately recorded independent positive repeat, not mesh or frequency-continuum certification.",
    ],
})

OUTPUT.write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({
    "status": record["validation_status"],
    "output": relative(OUTPUT),
    "output_sha256": sha256(OUTPUT),
    "unique": len(unique),
    "raw": len(rows),
    "repeats": repeat_rows,
    "best": report["best"],
}, ensure_ascii=False))
