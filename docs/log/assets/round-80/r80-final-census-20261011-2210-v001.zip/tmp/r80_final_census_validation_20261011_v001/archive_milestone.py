import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
sha = lambda data: hashlib.sha256(data).hexdigest()
status_source = HERE / 'final_census_status_ready.json'
status_bytes = status_source.read_bytes()
assert sha(status_bytes) == '98f4b829881cb2c99d03d74e2ac500a257d65bd46d5605b6f30d59bd36d3c835'
status = json.loads(status_bytes)
assert status['unique_successful_patterns'] == 5000
assert status['validation_status'] == 'passed_saved_raw_summary_validation'
tracked = ROOT / 'docs/log/assets/r80_final_census_20261011_v001.json'
with tracked.open('xb') as handle:
    handle.write(status_bytes)
payloads = {record['repo_path']: (ROOT / record['repo_path']).read_bytes()
            for record in status['query_evidence'].values()}
for record in status['query_evidence'].values():
    assert sha(payloads[record['repo_path']]) == record['sha256']
validator_path = 'tmp/r80_final_census_validation_20261011_v001/validate_saved_census.py'
payloads[validator_path] = (ROOT / validator_path).read_bytes()
assert sha(payloads[validator_path]) == status['validation_script_sha256']
payloads[tracked.relative_to(ROOT).as_posix()] = status_bytes
payloads[Path(__file__).relative_to(ROOT).as_posix()] = Path(__file__).read_bytes()
payloads['README.txt'] = (
    'R80 saved final census, cutoff 2026-10-11 22:10 Taipei.\n'
    '5000 unique / 5005 successful raw observations; four COM errors excluded.\n'
    'This is saved summary/rows/proof/source evidence, not the full raw dataset archive.\n'
    'Native final watch/action gate and R80 complete freeze/statistics remain separate.\n'
    'Paths preserve original repo-relative producer layout; no live queue or markers changed.\n'
).encode('utf8')
manifest = {name: {'sha256': sha(data), 'bytes': len(data)} for name, data in payloads.items()}
archive = ROOT / 'docs/log/assets/round-80/r80-final-census-20261011-2210-v001.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as out:
    for name, data in payloads.items():
        out.writestr(name, data)
    out.writestr('manifest.json', json.dumps(manifest, indent=2).encode('utf8'))
with zipfile.ZipFile(archive) as check:
    assert check.testzip() is None
    for name, data in payloads.items():
        assert check.read(name) == data
assert tracked.read_bytes() == status_bytes

board = ROOT / 'configs/ONGOING.md'
text = board.read_text(encoding='utf8')
anchor = '- **當前工作**：'
assert text.count(anchor) == 1
line = ('- **10/11 22:10有效唯一5,000達成**：原有全量raw census完成5,000唯一／5,005含5重測，零cached／prior metrics；315保存store、4 COM失敗排除。獨立保存證據核對通過，最佳仍WM+.0216822624dB，沒有新最佳。立即開始R81備料，不限制金屬／場型對稱；R80完整資料凍結、重測殘差、統計圖表同步收尾。尚待原主控寫出5000／零pending的terminal watch與idle action，不能用21:39的4998 action代替，也尚無R81 release或HFSS。下一例行22:34。 [全量與驗證](../docs/log/assets/r80_final_census_20261011_v001.json)／[保存證據封存](../docs/log/assets/round-80/r80-final-census-20261011-2210-v001.zip)。\n')
text = text.replace(anchor, line + anchor, 1)
text = text.replace('- **最新全量（10/11 07:44，使用者詢問）**：', '- **歷史全量（10/11 07:44，使用者詢問；現由22:10取代）**：', 1)
text = text.replace('- **尚待完成R80**：有效唯一5,000（使用者後來更正目標，覆盖最初三批／10,000；repeat與prediction不計）、完整凍結資料與真值稽核', '- **尚待完成R80收尾**：有效唯一5,000已於22:10驗證（repeat與prediction不計）；原生零pending完成綁定、完整凍結資料與真值稽核', 1)
text = text.replace('目前R80實證未到5,000，release gate正確拒絕提前啟動。', 'R80全量raw已有5,000；原主控terminal watch／idle action的零pending gate仍待完成，尚未建立release。', 1)
board.write_text(text, encoding='utf8', newline='\n')
log = ROOT / 'docs/log/round-80-symmetry-exploration.md'
text = log.read_text(encoding='utf8')
title, remainder = text.split('\n\n', 1)
new_top = ('最新狀態（2026-10-11 22:10全量完成）：**5,000／5,000有效唯一金屬LR對稱實測，100%**；全5,005含重測raw重新計分，零cached metrics，315保存store與4排除COM失敗。獨立保存rows／proofs／最佳核對通過。最佳仍WM **+.0216822624dB**，沒有新最佳；最差帶內S11−10.0960884094dB、最低Gain4.0216822624dBi。R81新spec備料立即開始且不限制金屬／場型對稱；R80完整freeze、重測殘差、統計圖表並行收尾。原主控最後觀察仍在running_cycle／上輪4998，R81實際HFSS需等原生5000／零pending terminal watch與idle action及實際release，未宣稱已啟動。下一例行22:34。 [最終全量證據](assets/r80_final_census_20261011_v001.json)／[保存證據封存](assets/round-80/r80-final-census-20261011-2210-v001.zip)／[既有最佳極座標圖](assets/round-80/best-symmetric-polar-20261009-v006/sample_card.png)。\n\n')
log.write_text(title + '\n\n' + new_top + '歷史開篇（22:10全量取代）：' + remainder, encoding='utf8', newline='\n')
print(json.dumps({'status': 'archived_and_documented', 'tracked': str(tracked), 'status_sha256': sha(status_bytes), 'archive': str(archive), 'archive_bytes': archive.stat().st_size, 'archive_sha256': sha(archive.read_bytes()), 'crc_and_payload_bytes_verified': True}))
