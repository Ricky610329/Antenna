import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import torch

from antenna.measurement import measurement_id, score_spec_id
from script import profiled_batch as pb
from script.symmetry_factory_cycle import _safe_child, _snapshot_successes_from_proofs
from script.symmetry_incumbent_shell_pilot import _metric_from_observation
from script.symmetry_analysis import analyze_profile_stores

torch.set_num_threads(4)
out = Path(__file__).resolve().parent
assert not (out / 'report.json').exists()
started = datetime.now(timezone.utc).isoformat()
settings = pb.read_json(Path('tmp/r80_factory_20261007/watch_settings_backlog_v1.json'))
root = Path(settings['dataset_root'])
cfg = pb.load_profile_config(Path('configs/single_r80_symmetry_factory.yaml'))
mid, sid = measurement_id(cfg.measurement), score_spec_id(cfg.score_spec)
queue_bytes = (root / 'jobs.json').read_bytes()
jobs = [j for j in json.loads(queue_bytes) if j.get('scope') == cfg.scope]
proofs, observations, errors = [], [], []
cutoffs = out / 'cutoffs'
cutoffs.mkdir(exist_ok=False)
for pair_index, job in enumerate(jobs):
    inp, store = _safe_child(root, job['input']), _safe_child(root, job['store'])
    input_hashes = {n: pb.file_sha256(inp / n) for n in
                    ('config.yaml', 'measurement.json', 'score_spec.json', 'manifest.json')}
    local_cfg = pb.load_profile_config(inp / 'config.yaml')
    assert local_cfg.scope == cfg.scope
    assert measurement_id(local_cfg.measurement) == mid
    assert score_spec_id(local_cfg.score_spec) == sid
    assert measurement_id(pb.read_json(inp / 'measurement.json')) == mid
    assert score_spec_id(pb.read_json(inp / 'score_spec.json')) == sid
    rows = pb.read_json(inp / 'manifest.json')
    rp = store / 'results.json'
    if not rp.is_file():
        continue
    raw_results = rp.read_bytes()
    results = json.loads(raw_results)
    (cutoffs / (job['store'] + '.json')).write_bytes(raw_results)
    store_hashes = {n: pb.file_sha256(store / n) for n in
                    ('measurement.json', 'score_spec.json', 'manifest.json')}
    store_hashes['results.json'] = hashlib.sha256(raw_results).hexdigest()
    assert measurement_id(pb.read_json(store / 'measurement.json')) == mid
    assert score_spec_id(pb.read_json(store / 'score_spec.json')) == sid
    assert pb.read_json(store / 'manifest.json') == rows
    row_lookup = {r['id']: r for r in rows}
    assert len(row_lookup) == len(rows)
    assert set(results) <= set(row_lookup)
    for row_index, row in enumerate(rows):
        entry = results.get(row['id'])
        if not isinstance(entry, dict):
            continue
        if 'error' in entry:
            errors.append({'store': store.name, 'id': row['id'], 'entry': entry})
            continue
        assert entry.get('status') == 'ok'
        assert entry['measurement_id'] == mid and entry['score_spec_id'] == sid
        metric, binding = _metric_from_observation(store, row, entry, local_cfg)
        observations.append({**metric, 'store': store.name,
                             'sample_sha256': binding['sample_sha256'],
                             'rad_sha256': binding['rad_sha256'],
                             'repeat': row.get('kind') in ('repeat', 'notarize'),
                             'pair_index': pair_index, 'row_index': row_index})
    current = pb.read_json(rp)
    for name, entry in results.items():
        if entry.get('status') == 'ok' and 'error' not in entry:
            assert current.get(name) == entry, 'successful cutoff entry changed'
    assert all(pb.file_sha256(inp / n) == h for n, h in input_hashes.items())
    assert all(pb.file_sha256(store / n) == h for n, h in store_hashes.items()
               if n != 'results.json')
    proofs.append({'input': str(inp), 'store': str(store), 'rows': rows,
                   'results': results, 'input_metadata_sha256': input_hashes,
                   'store_metadata_sha256': store_hashes})
    if pair_index % 25 == 0:
        print(f'raw replay: jobs={pair_index + 1}/{len(jobs)}, successes={len(observations)}', flush=True)

winners = {}
for item in observations:
    key = item['pattern_sha256']
    priority = (item['repeat'], item['pair_index'], item['row_index'])
    if key not in winners or priority < winners[key][0]:
        winners[key] = (priority, item)
unique = [p[1] for p in winners.values()]
best = max(unique, key=lambda r: r['factory_margin_db'])
chosen_proof = next(p for p in proofs if Path(p['store']).name == best['store'])
chosen_row = next(r for r in chosen_proof['rows'] if r['id'] == best['id'])
chosen_entry = chosen_proof['results'][best['id']]
replayed, binding = _metric_from_observation(Path(chosen_proof['store']), chosen_row, chosen_entry, cfg)
for key, value in replayed.items():
    assert best[key] == value
sample_path = Path(binding['sample_path'])
_, response = torch.load(sample_path, weights_only=True, map_location='cpu')
response = np.asarray(response, dtype=np.float64)
band = (np.asarray(chosen_entry['freqs']) >= 26.5) & (np.asarray(chosen_entry['freqs']) <= 29.5)
best = {**best, 'worst_inband_s11_db': float(response[0, band].max()),
        'minimum_inband_gain_dbi': float(response[1, band].min())}
assert best['factory_margin_db'] == min(-10 - best['worst_inband_s11_db'],
                                      best['minimum_inband_gain_dbi'] - 4)
pb.atomic_json(out / 'rows.json', observations)
pb.atomic_json(out / 'pair_proofs.json', proofs)
frozen = _snapshot_successes_from_proofs({'pair_proofs': proofs}, out / 'best_frozen_store',
                                        [best['pattern_sha256']], cfg)
analyze_profile_stores([frozen], out / 'analysis/analysis.json', out / 'analysis/arrays.npz')
report = {'schema_version': 1, 'started_utc': started,
          'completed_utc': datetime.now(timezone.utc).isoformat(),
          'status': 'read_only_query_complete', 'measurement_id': mid, 'score_spec_id': sid,
          'unique_successful_patterns': len(unique),
          'successful_including_repeats': len(observations),
          'raw_replayed_this_query': len(observations), 'exact_prior_metrics_reused': 0,
          'reported_best_independently_raw_replayed': True,
          'best': best, 'result_errors': errors,
          'jobs_sha256_at_scan_start': hashlib.sha256(queue_bytes).hexdigest(),
          'rows_sha256': pb.file_sha256(out / 'rows.json'),
          'pair_proofs_sha256': pb.file_sha256(out / 'pair_proofs.json'),
          'query_script_sha256': pb.file_sha256(Path(__file__)),
          'controller_locks_acquired': False, 'queue_or_source_mutation': False,
          'limits': ['Each store has its own saved cutoff; later worker results or queue additions are excluded.',
                     'Unique representatives prefer nonrepeat observations, then queue/manifest order.',
                     'Single HFSS solve performance, not repeat certification or field-symmetry proof.']}
pb.atomic_json(out / 'report.json', report)
print(json.dumps(report, ensure_ascii=False), flush=True)
