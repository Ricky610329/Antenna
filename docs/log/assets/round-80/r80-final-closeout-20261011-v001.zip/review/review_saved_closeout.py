from __future__ import annotations

import hashlib
import json
import math
import os
import zipfile
from datetime import datetime, timezone
from pathlib import Path

import numpy as np


REPO = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent
NAS_ROOT = Path(os.environ["R80_CLOSEOUT_DIR"])
DOC_RECORD = REPO / "docs/log/assets/r80_final_closeout_20261011.json"
ARCHIVE = REPO / "docs/log/assets/round-80/r80-final-closeout-20261011-v001.zip"

EXPECTED = {
    "closeout_status": "completed_final5000_closeout_after_native_r80_release_gate",
    "source_bindings_sha256": "d67994f3094044153ec36a43b9aff647cfdd8c8571d2f7880ddb2ee97e90bf3c",
    "combined_json_sha256": "188f4fe03759358ded93224551c18cee96e02f1bd1723d6e8e1de3a7896f2642",
    "combined_npz_sha256": "11033babc2fa5c3d2303b0fa87e9054b6c725c1fee91cec940121d6716ab63bd",
    "geometry_terrain_sha256": "651aa8d31cd0d07725343e6eeed93ea9628974e85c6bbcf8146957b8a2087e3e",
    "frequency_responses_sha256": "76dda879c1ca8a1f1d082272821e67d4ad30fa2d9756b34cc182191eb95687fc",
    "native_commit": "c736c2a7cdfad9bbfc050710f2565aaee4447ec8",
    "release_commit": "66dfc5c7f37e060b903feed72edbdc12c46ddb6e",
    "completion_binding_sha256": "4a5d14d4fc3dc863b4fe38497351207a686157d579a0110f5bd6de009951b0a2",
}

PROFILE_FILES = {
    "dedust_r80repeat1_efc86b3048": (
        "analysis/repeat_dedust_r80repeat1_efc86b3048.json",
        "analysis/repeat_dedust_r80repeat1_efc86b3048.npz",
    ),
    "dedust_r80repeat2_db47909258": (
        "analysis/repeat_dedust_r80repeat2_db47909258.json",
        "analysis/repeat_dedust_r80repeat2_db47909258.npz",
    ),
    "dedust_r80bestrep01_bbe54206fb": (
        "analysis/repeat_dedust_r80bestrep01_bbe54206fb.json",
        "analysis/repeat_dedust_r80bestrep01_bbe54206fb.npz",
    ),
}


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def file_info(path: Path) -> dict:
    data = path.read_bytes()
    return {"path": str(path), "sha256": sha256_bytes(data), "bytes": len(data)}


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def json_bytes(value) -> bytes:
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def max_error(actual, expected) -> float:
    a = np.asarray(actual, dtype=np.float64)
    b = np.asarray(expected, dtype=np.float64)
    if not np.array_equal(np.isnan(a), np.isnan(b)):
        raise AssertionError("NaN masks differ")
    finite = np.isfinite(a) & np.isfinite(b)
    if np.any(finite):
        return float(np.max(np.abs(a[finite] - b[finite])))
    return 0.0


def radial_descriptors(theta, curves_db):
    """Independent NumPy replay of the descriptive saved-curve formulas."""
    theta = np.asarray(theta, dtype=np.float64).reshape(-1)
    curves = np.asarray(curves_db, dtype=np.float64)
    if curves.ndim != 2 or curves.shape[1] != theta.size:
        raise AssertionError("invalid radiation array shape")
    result = {}
    lookup = {round(float(t), 8): i for i, t in enumerate(theta) if np.isfinite(t)}
    for limit in (45, 90):
        positive = []
        negative = []
        for index, value in enumerate(theta):
            if np.isfinite(value) and 0 < value <= limit:
                opposite = lookup.get(round(float(-value), 8))
                if opposite is not None:
                    positive.append(index)
                    negative.append(opposite)
        pos = curves[:, positive]
        neg = curves[:, negative]
        valid = np.isfinite(pos) & np.isfinite(neg)
        with np.errstate(over="ignore", invalid="ignore"):
            pos_power = np.power(10.0, pos / 10.0)
            neg_power = np.power(10.0, neg / 10.0)
        valid &= np.isfinite(pos_power) & np.isfinite(neg_power)
        pos_power = np.where(valid, pos_power, 0.0)
        neg_power = np.where(valid, neg_power, 0.0)
        denominator = np.sum(pos_power + neg_power, axis=1, dtype=np.float64)
        numerator = np.sum(np.abs(pos_power - neg_power), axis=1, dtype=np.float64)
        result[f"mirror_power_{limit}"] = np.divide(
            numerator,
            denominator,
            out=np.full(curves.shape[0], np.nan),
            where=denominator > 0,
        )
        db_sum = np.sum(np.where(valid, np.abs(pos - neg), 0.0), axis=1, dtype=np.float64)
        counts = np.sum(valid, axis=1)
        result[f"mirror_db_mae_{limit}"] = np.divide(
            db_sum,
            counts,
            out=np.full(curves.shape[0], np.nan),
            where=counts > 0,
        )
        result[f"mirror_pairs_{limit}"] = counts

    with np.errstate(over="ignore", invalid="ignore"):
        power = np.power(10.0, curves / 10.0)
    power[~np.isfinite(power)] = np.nan
    front = np.abs(theta) <= 90.0
    back = np.abs(theta) > 90.0
    front_power = power[:, front]
    back_power = power[:, back]
    front_curves = curves[:, front]
    peak = np.max(np.where(np.isfinite(front_curves), front_curves, -np.inf), axis=1)
    main = np.isfinite(front_curves) & (front_curves >= peak[:, None] - 3.0)
    main_power = np.where(main, front_power, 0.0)
    main_sum = np.sum(main_power, axis=1, dtype=np.float64)
    result["power_centroid_deg"] = np.divide(
        np.sum(main_power * theta[front], axis=1, dtype=np.float64),
        main_sum,
        out=np.full(curves.shape[0], np.nan),
        where=main_sum > 0,
    )
    front_count = np.sum(np.isfinite(front_power), axis=1)
    back_count = np.sum(np.isfinite(back_power), axis=1)
    front_mean = np.divide(
        np.nansum(front_power, axis=1, dtype=np.float64),
        front_count,
        out=np.full(curves.shape[0], np.nan),
        where=front_count > 0,
    )
    back_mean = np.divide(
        np.nansum(back_power, axis=1, dtype=np.float64),
        back_count,
        out=np.full(curves.shape[0], np.nan),
        where=back_count > 0,
    )
    denominator = front_mean + back_mean
    result["front_back_imbalance"] = np.divide(
        front_mean - back_mean,
        denominator,
        out=np.full(curves.shape[0], np.nan),
        where=np.isfinite(denominator) & (denominator > 0),
    )
    with np.errstate(divide="ignore", invalid="ignore"):
        result["front_back_db"] = 10.0 * np.log10(front_mean / back_mean)
    finite = np.isfinite(curves)
    argmax = np.argmax(np.where(finite, curves, -np.inf), axis=1)
    result["argmax_deg_diagnostic"] = theta[argmax].astype(float)
    result["argmax_deg_diagnostic"][~np.any(finite, axis=1)] = np.nan
    return result


def deterministic_zip(path: Path, entries: dict[str, bytes]) -> list[dict]:
    manifest = []
    path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name in sorted(entries):
            data = entries[name]
            info = zipfile.ZipInfo(name, date_time=(2026, 10, 11, 22, 58, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, data)
            manifest.append({"path": name, "sha256": sha256_bytes(data), "bytes": len(data)})
    return manifest


def main():
    if DOC_RECORD.exists() or ARCHIVE.exists():
        raise FileExistsError("fresh output already exists")

    receipt_path = NAS_ROOT / "closeout_receipt.json"
    source_bindings_path = NAS_ROOT / "source_bindings.json"
    combined_json_path = NAS_ROOT / "analysis/combined.json"
    combined_npz_path = NAS_ROOT / "analysis/combined.npz"
    residual_json_path = NAS_ROOT / "analysis/repeat_residuals.json"
    residual_npz_path = NAS_ROOT / "analysis/repeat_residuals.npz"
    plot_receipt_path = NAS_ROOT / "population_figures/plot_receipt.json"

    receipt_info = file_info(receipt_path)
    source_info = file_info(source_bindings_path)
    combined_json_info = file_info(combined_json_path)
    combined_npz_info = file_info(combined_npz_path)
    assert source_info["sha256"] == EXPECTED["source_bindings_sha256"]
    assert combined_json_info["sha256"] == EXPECTED["combined_json_sha256"]
    assert combined_npz_info["sha256"] == EXPECTED["combined_npz_sha256"]

    receipt = load_json(receipt_path)
    source_bindings = load_json(source_bindings_path)
    combined = load_json(combined_json_path)
    residual = load_json(residual_json_path)
    plot_receipt = load_json(plot_receipt_path)
    assert receipt["status"] == EXPECTED["closeout_status"]
    assert receipt["source_bindings_sha256"] == source_info["sha256"]
    assert receipt["native_gate"]["r80_completion_binding_sha256"] == EXPECTED["completion_binding_sha256"]
    assert receipt["native_gate"]["release_git_commit"] == EXPECTED["release_commit"]
    assert source_bindings["unchanged"] is True
    assert plot_receipt["analysis_sha256"] == combined_json_info["sha256"]
    assert plot_receipt["npz_sha256"] == combined_npz_info["sha256"]
    assert plot_receipt["figures"]["geometry_terrain.png"] == EXPECTED["geometry_terrain_sha256"]
    assert plot_receipt["figures"]["frequency_responses.png"] == EXPECTED["frequency_responses_sha256"]
    assert plot_receipt["scope"]["descriptive_only"] is True
    assert plot_receipt["scope"]["causal_claim"] is False
    assert plot_receipt["scope"]["hfss_or_training_run"] is False

    output_hashes = {key.replace("\\", "/"): value for key, value in receipt["outputs_before_closeout_receipt"].items()}
    for relative, info in (
        ("source_bindings.json", source_info),
        ("analysis/combined.json", combined_json_info),
        ("analysis/combined.npz", combined_npz_info),
    ):
        assert output_hashes[relative] == info["sha256"]

    with np.load(combined_npz_path, allow_pickle=False) as saved:
        arrays = {name: saved[name] for name in saved.files}
    ids = arrays["ids"].astype(str)
    patterns = arrays["patterns"]
    pattern_hashes = arrays["pattern_sha256"].astype(str)
    assert ids.shape == (5000,)
    assert patterns.shape == (5000, 25, 25)
    assert len(set(ids.tolist())) == 5000
    assert len(set(pattern_hashes.tolist())) == 5000
    assert len(combined["rows"]) == 5000
    assert [row["id"] for row in combined["rows"]] == ids.tolist()
    assert [row["pattern_sha256"] for row in combined["rows"]] == pattern_hashes.tolist()
    assert combined["counts"]["validated_complete_source_rows"] == 5005
    assert combined["counts"]["unique_selected_rows"] == 5000
    assert combined["counts"]["duplicate_rows_removed"] == 5
    assert combined["counts"]["symmetry_class"] == {"exact": 5000}
    assert np.array_equal(patterns[:, :, :12], patterns[:, :, 13:][:, :, ::-1])
    assert np.count_nonzero(arrays["geometry_mismatch_fraction"]) == 0

    row_scalar_keys = [key for key in combined["quantiles"] if key in arrays]
    for key in row_scalar_keys:
        values = np.asarray(arrays[key], dtype=np.float64)
        expected_values = np.asarray([row[key] for row in combined["rows"]], dtype=np.float64)
        assert np.allclose(values, expected_values, rtol=0.0, atol=0.0, equal_nan=True)

    quantile_errors = {}
    quantile_levels = (("q05", 0.05), ("q25", 0.25), ("q50", 0.50), ("q75", 0.75), ("q95", 0.95))
    for key, summary in combined["quantiles"].items():
        values = np.asarray(arrays[key], dtype=np.float64)
        finite = values[np.isfinite(values)]
        assert int(summary["finite_count"]) == finite.size
        replay = np.quantile(finite, [level for _, level in quantile_levels])
        recorded = np.asarray([summary[name] for name, _ in quantile_levels], dtype=np.float64)
        error = max_error(replay, recorded)
        assert error <= 1e-12
        quantile_errors[key] = error

    radial_errors = {}
    by_cut = {}
    for cut_index, cut_name in enumerate(("phi0", "phi90")):
        replay = radial_descriptors(arrays["radiation_theta_deg"], arrays["radiation"][:, cut_index, :])
        by_cut[cut_name] = replay
        for metric, values in replay.items():
            key = f"{cut_name}_{metric}"
            error = max_error(values, arrays[key])
            assert error <= 1e-12
            radial_errors[key] = error
    for metric in ("mirror_power_45", "mirror_power_90", "mirror_db_mae_45", "mirror_db_mae_90", "front_back_imbalance", "front_back_db"):
        replay = np.mean(np.stack([by_cut["phi0"][metric], by_cut["phi90"][metric]]), axis=0)
        key = f"field_{metric}"
        error = max_error(replay, arrays[key])
        assert error <= 1e-12
        radial_errors[key] = error
    replay_centroid = np.mean(
        np.abs(np.stack([by_cut["phi0"]["power_centroid_deg"], by_cut["phi90"]["power_centroid_deg"]])),
        axis=0,
    )
    centroid_error = max_error(replay_centroid, arrays["field_abs_power_centroid_deg"])
    assert centroid_error <= 1e-12
    radial_errors["field_abs_power_centroid_deg"] = centroid_error

    s11_margin = np.asarray(arrays["s11_band_margin_db"], dtype=np.float64)
    gain_margin = np.asarray(arrays["gain_band_margin_db"], dtype=np.float64)
    wm = np.minimum(s11_margin, gain_margin)
    best_index = int(np.argmax(wm))
    positive_indices = np.flatnonzero(wm > 0.0)

    with np.load(residual_npz_path, allow_pickle=False) as saved:
        residual_arrays = {name: saved[name] for name in saved.files}
    assert residual["counts"] == {"repeat_observations_compared": 5, "repeat_profiles": 3}
    assert len(residual["records"]) == 5
    profiles = {}
    profile_infos = {}
    for profile_name, (profile_json_name, profile_npz_name) in PROFILE_FILES.items():
        profile_json_path = NAS_ROOT / profile_json_name
        profile_npz_path = NAS_ROOT / profile_npz_name
        profile_json_info = file_info(profile_json_path)
        profile_npz_info = file_info(profile_npz_path)
        assert output_hashes[profile_json_name] == profile_json_info["sha256"]
        assert output_hashes[profile_npz_name] == profile_npz_info["sha256"]
        profile_json = load_json(profile_json_path)
        with np.load(profile_npz_path, allow_pickle=False) as saved:
            profile_npz = {name: saved[name] for name in saved.files}
        assert [row["id"] for row in profile_json["rows"]] == profile_npz["ids"].astype(str).tolist()
        assert [row["pattern_sha256"] for row in profile_json["rows"]] == profile_npz["pattern_sha256"].astype(str).tolist()
        profiles[profile_name] = (profile_json, profile_npz)
        profile_infos[profile_name] = {"json": profile_json_info, "npz": profile_npz_info}

    original_index = {value: index for index, value in enumerate(ids.tolist())}
    repeat_replays = []
    for record_index, record in enumerate(residual["records"]):
        profile_json, profile_npz = profiles[record["repeat_profile"]]
        repeat_ids = profile_npz["ids"].astype(str).tolist()
        original = original_index[record["original_id"]]
        repeat = repeat_ids.index(record["repeat_id"])
        assert pattern_hashes[original] == record["pattern_sha256"]
        assert str(profile_npz["pattern_sha256"][repeat]) == record["pattern_sha256"]
        assert np.array_equal(patterns[original], profile_npz["patterns"][repeat])
        assert np.array_equal(arrays["response_freqs_ghz"], profile_npz["response_freqs_ghz"])
        assert np.array_equal(arrays["radiation_theta_deg"], profile_npz["radiation_theta_deg"])
        response_delta = profile_npz["responses"][repeat] - arrays["responses"][original]
        radiation_delta = profile_npz["radiation"][repeat] - arrays["radiation"][original]
        assert np.array_equal(response_delta, residual_arrays["response_delta_db"][record_index])
        assert np.array_equal(radiation_delta, residual_arrays["radiation_delta_db"][record_index])
        assert str(residual_arrays["repeat_profile"][record_index]) == record["repeat_profile"]
        assert str(residual_arrays["pattern_sha256"][record_index]) == record["pattern_sha256"]
        assert str(residual_arrays["original_id"][record_index]) == record["original_id"]
        assert str(residual_arrays["repeat_id"][record_index]) == record["repeat_id"]
        response_max = np.max(np.abs(response_delta), axis=1).astype(float)
        radiation_max = np.max(np.abs(radiation_delta), axis=1).astype(float)
        assert np.array_equal(response_max, np.asarray(record["s11_gain_curve_max_abs_repeat_delta_db"]))
        assert np.array_equal(radiation_max, np.asarray(record["phi0_phi90_curve_max_abs_repeat_delta_db"]))
        original_wm = float(min(arrays["s11_band_margin_db"][original], arrays["gain_band_margin_db"][original]))
        repeat_wm = float(min(profile_npz["s11_band_margin_db"][repeat], profile_npz["gain_band_margin_db"][repeat]))
        assert original_wm == record["original_wm_db"]
        assert repeat_wm == record["repeat_wm_db"]
        assert repeat_wm - original_wm == record["repeat_minus_original_wm_db"]
        assert float(profile_npz["s11_band_margin_db"][repeat] - arrays["s11_band_margin_db"][original]) == record["repeat_minus_original_s11_margin_db"]
        assert float(profile_npz["gain_band_margin_db"][repeat] - arrays["gain_band_margin_db"][original]) == record["repeat_minus_original_gain_margin_db"]
        repeat_replays.append(
            {
                "repeat_profile": record["repeat_profile"],
                "pattern_sha256": record["pattern_sha256"],
                "original_id": record["original_id"],
                "repeat_id": record["repeat_id"],
                "original_wm_db": original_wm,
                "repeat_wm_db": repeat_wm,
                "repeat_minus_original_wm_db": repeat_wm - original_wm,
                "s11_gain_curve_max_abs_repeat_delta_db": response_max.tolist(),
                "phi0_phi90_curve_max_abs_repeat_delta_db": radiation_max.tolist(),
                "pattern_exactly_equal": True,
                "frequency_grid_exactly_equal": True,
                "theta_grid_exactly_equal": True,
            }
        )

    assert np.array_equal(residual_arrays["response_freqs_ghz"], arrays["response_freqs_ghz"])
    assert np.array_equal(residual_arrays["radiation_theta_deg"], arrays["radiation_theta_deg"])
    residual_json_info = file_info(residual_json_path)
    residual_npz_info = file_info(residual_npz_path)
    assert output_hashes["analysis/repeat_residuals.json"] == residual_json_info["sha256"]
    assert output_hashes["analysis/repeat_residuals.npz"] == residual_npz_info["sha256"]

    frequency_summary = {}
    for name in ("s11_db", "gain_db"):
        quantiles = np.quantile(np.asarray(arrays[name], dtype=np.float64), [0.25, 0.50, 0.75], axis=0)
        frequency_summary[name] = {
            "freqs_ghz": arrays["response_freqs_ghz"].astype(float).tolist(),
            "q25": quantiles[0].tolist(),
            "q50": quantiles[1].tolist(),
            "q75": quantiles[2].tolist(),
        }

    summary = {
        "schema_version": 1,
        "status": "passed_saved_closeout_numerical_review",
        "inputs": {
            "closeout_receipt": receipt_info,
            "source_bindings": source_info,
            "combined_json": combined_json_info,
            "combined_npz": combined_npz_info,
            "repeat_profiles": profile_infos,
            "repeat_residual_json": residual_json_info,
            "repeat_residual_npz": residual_npz_info,
            "plot_receipt": file_info(plot_receipt_path),
        },
        "counts": {
            "unique_representatives": 5000,
            "repeat_observations": 5,
            "repeat_source_stores": 3,
            "combined_duplicate_audit_rows": 5,
            "unique_ids": 5000,
            "unique_pattern_sha256": 5000,
            "exact_lr_geometry": 5000,
            "positive_wm_unique": int(positive_indices.size),
            "s11_band_margin_positive": int(np.sum(s11_margin > 0.0)),
            "gain_band_margin_positive": int(np.sum(gain_margin > 0.0)),
        },
        "best_unique": {
            "array_index": best_index,
            "id": str(ids[best_index]),
            "pattern_sha256": str(pattern_hashes[best_index]),
            "wm_db": float(wm[best_index]),
            "s11_band_margin_db": float(s11_margin[best_index]),
            "gain_band_margin_db": float(gain_margin[best_index]),
            "s11_db_band_max": float(arrays["s11_db_band_max"][best_index]),
            "gain_db_band_min": float(arrays["gain_db_band_min"][best_index]),
        },
        "margin_quantiles": {
            key: combined["quantiles"][key]
            for key in ("s11_band_margin_db", "gain_band_margin_db")
        },
        "radiation_descriptor_medians": {
            key: combined["quantiles"][key]["q50"]
            for key in (
                "phi0_mirror_power_45",
                "phi0_mirror_power_90",
                "phi90_mirror_power_45",
                "phi90_mirror_power_90",
                "field_mirror_power_45",
                "field_mirror_power_90",
                "field_front_back_db",
                "field_abs_power_centroid_deg",
            )
        },
        "npz_radiation_axes": {
            "angle_axis": {"field": "radiation_theta_deg", "shape": [181], "units": "degrees"},
            "stacked_cuts": {"field": "radiation", "shape": [5000, 2, 181], "cut_order": ["phi0", "phi90"]},
            "named_phi0": {"field": "phi0_db", "shape": [5000, 181], "units": "dB"},
            "named_phi90": {"field": "phi90_db", "shape": [5000, 181], "units": "dB"},
        },
        "frequency_response_quantiles": frequency_summary,
        "independent_checks": {
            "combined_json_npz_row_alignment": True,
            "all_5000_ids_and_pattern_hashes_unique": True,
            "all_5000_patterns_exact_left_right_mirrors": True,
            "all_saved_quantiles_replayed": True,
            "quantile_metric_count": len(quantile_errors),
            "max_quantile_abs_error": max(quantile_errors.values()),
            "all_saved_radiation_descriptors_replayed": True,
            "radiation_descriptor_array_count": len(radial_errors),
            "max_radiation_descriptor_abs_error": max(radial_errors.values()),
            "five_repeat_response_radiation_wm_residuals_replayed": True,
        },
        "repeat_replays": repeat_replays,
        "figure_bindings": {
            "geometry_terrain.png": EXPECTED["geometry_terrain_sha256"],
            "frequency_responses.png": EXPECTED["frequency_responses_sha256"],
            "visual_review_by_this_task": False,
        },
        "definitions": {
            "wm_db": "min(s11_band_margin_db, gain_band_margin_db)",
            "band": combined["definitions"]["band"],
            "s11_band_margin_db": combined["definitions"]["s11_band_margin_db"],
            "gain_band_margin_db": combined["definitions"]["gain_band_margin_db"],
            "geometry_mismatch_fraction": combined["definitions"]["geometry_mismatch_fraction"],
            "field_mirror_power": combined["definitions"]["field_mirror_power"],
            "frequency_figure_quantiles": plot_receipt["frequency_quantiles"],
            "geometry_figure_coordinates": plot_receipt["coordinate_policy"],
        },
        "limitations": [
            "Saved-result review only: no raw-store inventory, per-job terminal replay, re-census, model forward/training, HFSS, or mesh certification.",
            "Repeat residual evidence covers only five explicitly mapped repeat observations across three repeat stores and does not certify repeatability of all 5,000 unique geometries.",
            "Radiation mirror, front/back, centroid, geometry-terrain, frequency-quantile, and margin summaries are descriptive; they do not establish accuracy, causality, or a mesh-convergence claim.",
            "The two PNG hashes are bound through the saved plot receipt; visual QA and tracked PNG copying are handled separately by the root task.",
            "This archive intentionally excludes the frozen 5,000 raw samples and the historical 315 source stores.",
        ],
    }
    review_bytes = json_bytes(summary)
    (WORK / "review_results.json").write_bytes(review_bytes)
    (WORK / "population_summary.json").write_bytes(review_bytes)

    producer_path = REPO / "tmp/r80_final_closeout_driver_20261011_v004/final_closeout_driver.py"
    reviewer_path = Path(__file__).resolve()
    producer_info = file_info(producer_path)
    reviewer_info = file_info(reviewer_path)
    transport_path = REPO / "tmp/r81_actual_transport_fix_20261011_v002/run_closeout_utf8_bom.ps1"
    transport_info = file_info(transport_path)
    assert transport_info["sha256"] == "45fece869101daf8df48dc9fc05432f01b7bc96164ab8e027d45fb420df97f20"

    entries = {
        "saved/closeout_receipt.json": receipt_path.read_bytes(),
        "saved/source_bindings.json": source_bindings_path.read_bytes(),
        "saved/analysis/combined.npz": combined_npz_path.read_bytes(),
        "saved/analysis/repeat_residuals.json": residual_json_path.read_bytes(),
        "saved/analysis/repeat_residuals.npz": residual_npz_path.read_bytes(),
        "saved/population_figures/plot_receipt.json": plot_receipt_path.read_bytes(),
        "review/population_summary.json": review_bytes,
        "review/review_saved_closeout.py": reviewer_path.read_bytes(),
        "producer/final_closeout_driver.py": producer_path.read_bytes(),
    }
    for _, (profile_json_name, profile_npz_name) in PROFILE_FILES.items():
        entries[f"saved/{profile_json_name}"] = (NAS_ROOT / profile_json_name).read_bytes()
        entries[f"saved/{profile_npz_name}"] = (NAS_ROOT / profile_npz_name).read_bytes()
    archive_manifest = deterministic_zip(ARCHIVE, entries)
    archive_info = file_info(ARCHIVE)

    prior_record = REPO / "docs/log/assets/r80_r81_actual_preparation_started_20261011.json"
    prior_archive = REPO / "docs/log/assets/round-81/r80-r81-actual-preparation-started-20261011-v001.zip"
    prior_record_info = file_info(prior_record)
    prior_archive_info = file_info(prior_archive)
    assert prior_record_info["sha256"] == "f10dfeba6deb2259443db296b9fcfb282ee5b23ec94e1925da5959545ab4c5df"
    assert prior_archive_info["sha256"] == "15ecbc42ece88a389665a742dfc58d83ff1582b10abe8e3755250dbdfbc8b627"

    now = datetime.now(timezone.utc)
    final_record = {
        "schema_version": 1,
        "status": "passed_saved_result_numerical_review_of_completed_final5000_closeout",
        "recorded_utc": now.isoformat(),
        "recorded_taipei": now.astimezone().isoformat(),
        "closeout": {
            "saved_status": receipt["status"],
            "receipt": receipt_info,
            "source_bindings": source_info,
            "native_completion_commit": EXPECTED["native_commit"],
            "release_git_commit": EXPECTED["release_commit"],
            "portable_completion_binding_sha256": EXPECTED["completion_binding_sha256"],
        },
        "producers": {
            "closeout_driver": producer_info,
            "symmetry_analysis": file_info(REPO / "script/symmetry_analysis.py"),
            "saved_result_reviewer": reviewer_info,
            "actual_utf8_bom_command": transport_info,
            "outer_environment": {
                "PYTHONPATH": str(REPO),
                "encoded_in_transport_script": False,
            },
        },
        "prior_transport_evidence": {
            "record": prior_record_info,
            "archive": prior_archive_info,
            "actual_command_entry": "transport-v002/run_closeout_utf8_bom.ps1",
            "missing_pythonpath_failure_entry": "transport-v002/closeout_missing_pythonpath.log",
            "no_bom_failure_entries": [
                "original-closeout/run_closeout.ps1",
                "original-closeout/closeout.log",
            ],
        },
        "saved_analysis": summary["inputs"],
        "results": {
            "counts": summary["counts"],
            "best_unique": summary["best_unique"],
            "margin_quantiles": summary["margin_quantiles"],
            "radiation_descriptor_medians": summary["radiation_descriptor_medians"],
            "npz_radiation_axes": summary["npz_radiation_axes"],
            "repeat_replays": summary["repeat_replays"],
            "independent_checks": summary["independent_checks"],
        },
        "figures": summary["figure_bindings"],
        "archive": {
            "path": str(ARCHIVE.relative_to(REPO)).replace("\\", "/"),
            "sha256": archive_info["sha256"],
            "bytes": archive_info["bytes"],
            "entry_count": len(archive_manifest),
            "entries": archive_manifest,
            "excludes_frozen_raw_5000_and_historical_315_stores": True,
            "combined_json_omitted_due_to_size_but_directly_reviewed_and_sha_bound": combined_json_info,
        },
        "scope": {
            "saved_result_numerical_review_only": True,
            "nas_writes": False,
            "raw_store_inventory": False,
            "recensus": False,
            "model_forward_or_training": False,
            "hfss": False,
            "tests": False,
            "r81_release_or_worker_delayed": False,
        },
        "limitations": summary["limitations"],
    }
    DOC_RECORD.parent.mkdir(parents=True, exist_ok=True)
    DOC_RECORD.write_bytes(json_bytes(final_record))
    print(json.dumps({
        "status": final_record["status"],
        "record": file_info(DOC_RECORD),
        "archive": archive_info,
        "review_results": file_info(WORK / "review_results.json"),
        "counts": summary["counts"],
        "best_unique": summary["best_unique"],
        "max_quantile_abs_error": summary["independent_checks"]["max_quantile_abs_error"],
        "max_radiation_descriptor_abs_error": summary["independent_checks"]["max_radiation_descriptor_abs_error"],
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
