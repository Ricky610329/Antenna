# R80 FINAL5000 closeout adapter v003

v003 makes the future closeout executable without inventing a terminal schema.
It preserves v001/v002 and reuses the accepted
`script.r81_worker_entry._validate_r80` gate unchanged.

The order is fail closed:

1. Read only the pinned raw census report and require exactly 5,000 unique rows.
2. Verify a pinned `r80_completion` binding, a pinned absolute private R81
   dataset pathname, and the explicit clean release Git HEAD.
3. Invoke `_validate_r80`. This binds the saved watch/action/audit 5,000/zero-
   pending state, tracked validated census, raw report, rows, pair proofs, query
   and validation producers, canonical profile, and their hashes.
4. Require the native binding raw/rows/proofs paths and hashes to be exactly the
   caller inputs. Bind the canonical pair-proof content ID and census jobs hash.
5. Only then read proofs/source metadata and run the existing root snapshots,
   combined/separate profiles, aligned repeat residuals, and population figures.

Repeat stores are explicitly supplied with `--repeat-store`. Residual records
carry the declared source-store mapping, and combined versus repeat-local source
indices are named by their actual scope.

The native gate does not independently replay every job terminal receipt. Its
saved watcher/action/audit plus immutable validated final census are the accepted
completion authority; root proof snapshots and profile replay remain the
physical observation validation.

The private R81 dataset path is compared and passed only as a pathname. This
workflow does not require it to exist and does not read or create it. R81
preparation does not wait for the R80 statistics/figures to finish.

The pathname pin is SHA-256 over UTF-8 `str(Path(path).resolve(strict=False))`,
matching `path_binding_sha` in the adapter.
