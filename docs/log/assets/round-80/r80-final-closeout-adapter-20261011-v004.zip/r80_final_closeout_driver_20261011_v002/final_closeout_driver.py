"""Fail-closed v002 entry point for the prepared R80 closeout utilities.

The v001 closeout accepted self-described terminal evidence.  That contract is
not authoritative enough to publish.  This entry point preserves v001's useful
local census gate and saved-pair residual command, but disables valid FINAL5000
execution until a reviewed producer binds the complete final jobs inventory to
actual job receipts and the census pair proofs.
"""

from __future__ import annotations

import hashlib
import importlib.util
import json
import sys
from pathlib import Path
from typing import Any, Mapping


V001_SHA256 = "f602a69122772b87887ad292e1b8588d4c509ddca79a58653b420a810654cbc5"
V001_PATH = (Path(__file__).resolve().parent.parent
             / "r80_final_closeout_driver_20261011_v001"
             / "final_closeout_driver.py")
R81_VALIDATOR_SHA256_REVIEWED = "cd578a22c4f0ca33374bee12cee0c2b7ada1a98abc54530a2f54a3fb79aa023c"


class AuthoritativeTerminalProducerUnavailable(RuntimeError):
    pass


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _load_v001():
    if _sha256(V001_PATH) != V001_SHA256:
        raise RuntimeError("preserved v001 helper differs from the reviewed binding")
    spec = importlib.util.spec_from_file_location("r80_final_closeout_v001", V001_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot load preserved v001 helper")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def require_authoritative_terminal_producer(_candidate: Mapping[str, Any] | None = None) -> None:
    """Reject every candidate until an authoritative producer contract exists.

    The candidate is intentionally neither parsed nor trusted.  In particular,
    one hash-bound arbitrary file and an advertised success string cannot stand
    in for the complete jobs inventory or actual terminal receipt semantics.
    """

    raise AuthoritativeTerminalProducerUnavailable(
        "FINAL5000 valid mode is disabled: no reviewed producer yet binds the "
        "complete final jobs inventory, exact proof input/store set, fixed "
        "216/218/37 terminal-failure semantics, and one actual terminal receipt "
        "per relevant reserved job")


def _write_rejection(base, args, value: dict[str, Any]) -> None:
    if getattr(args, "gate_receipt", None) is not None:
        base.write_json_exclusive(args.gate_receipt.resolve(), value)


def run_closeout(base, args) -> int:
    report = base.census_gate(args.census_report.resolve(), args.census_report_sha256)
    require_authoritative_terminal_producer({
        "report": report,
        "readiness_path_advertised_but_unread": str(args.readiness_json)
        if args.readiness_json is not None else None,
    })
    raise AssertionError("unreachable")


def main() -> int:
    base = _load_v001()
    args = base.parser().parse_args()
    try:
        if args.command == "replay-existing-pair":
            return base.run_pair_replay(args)
        return run_closeout(base, args)
    except base.GateRejected as exc:
        receipt = {
            "schema_version": 2,
            "status": "rejected_before_final_closeout_side_effects",
            "reason": exc.reason,
            **exc.details,
            "v002_authoritative_terminal_gate": "not_reached_before_exact5000",
            "limitations": [
                "This is a readiness-gap receipt, not a FINAL5000 closeout.",
                "No terminal claim is made and no advertised readiness evidence was read.",
            ],
        }
        _write_rejection(base, args, receipt)
        print(json.dumps(receipt, ensure_ascii=False), file=sys.stderr)
        return 2
    except AuthoritativeTerminalProducerUnavailable as exc:
        receipt = {
            "schema_version": 2,
            "status": "valid_mode_disabled_fail_closed",
            "reason": "authoritative_terminal_producer_unavailable",
            "message": str(exc),
            "census_exact5000_gate_passed": True,
            "rows_read": False,
            "pair_proofs_read": False,
            "advertised_readiness_evidence_read": False,
            "terminal_evidence_read": False,
            "source_metadata_or_artifacts_read": False,
            "destination_checked_or_created": False,
            "nas_read_or_write": False,
            "snapshot_profile_figures_or_hfss": False,
            "required_authoritative_contract": [
                "A hash-bound complete final jobs inventory tied to the census jobs hash.",
                "Exact one-to-one job input/store correspondence with the final pair proofs.",
                "Actual parsed success or exhausted-failure receipts for every relevant reserved job.",
                "Fixed 216/218/37 worker terminal-failure semantics validated by existing project verification functions.",
                "The existing watcher/action exact-5000, zero-pending, query, validation, profile, rows, proofs, and jobs bindings used by the R81 release validator.",
            ],
            "limitations": [
                "The existing R81 validator was reviewed as a reference but is not a reusable per-job terminal-proof producer.",
                "v001 freeze/profile/residual code remains preparation only and is unreachable from v002 closeout valid mode.",
                "R81 preparation is not gated on completion of R80 statistics or figures.",
            ],
        }
        _write_rejection(base, args, receipt)
        print(json.dumps(receipt, ensure_ascii=False), file=sys.stderr)
        return 3


if __name__ == "__main__":
    raise SystemExit(main())
