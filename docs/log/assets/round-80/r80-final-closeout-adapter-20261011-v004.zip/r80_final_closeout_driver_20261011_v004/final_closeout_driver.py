"""R80 FINAL5000 closeout using the accepted native R81 release gate.

The exact-5000 report gate runs first.  Valid mode then invokes the unchanged
``script.r81_worker_entry._validate_r80`` over a hash-pinned r80_completion
binding before reading the caller rows/proofs or touching the destination.
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import re
import sys
from pathlib import Path
from typing import Any


V001_SHA256 = "f602a69122772b87887ad292e1b8588d4c509ddca79a58653b420a810654cbc5"
V001_PATH = (Path(__file__).resolve().parent.parent
             / "r80_final_closeout_driver_20261011_v001"
             / "final_closeout_driver.py")
R81_VALIDATOR_SHA256 = "cd578a22c4f0ca33374bee12cee0c2b7ada1a98abc54530a2f54a3fb79aa023c"
HEX40 = re.compile(r"^[0-9a-f]{40}$")
CLOSEOUT_TRACKED_PRODUCERS = (
    "script/profiled_shards.py",
    "script/symmetry_factory_cycle.py",
    "script/symmetry_analysis.py",
    "script/figs/symmetry_profile.py",
    "script/figs/report_r1r10_style.py",
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def path_binding_sha(path: Path) -> str:
    normalized = str(path.resolve(strict=False))
    return hashlib.sha256(normalized.encode("utf-8")).hexdigest()


def load_v001():
    if sha256(V001_PATH) != V001_SHA256:
        raise RuntimeError("preserved v001 helper differs from the reviewed binding")
    spec = importlib.util.spec_from_file_location("r80_final_closeout_v001", V001_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot load preserved v001 helper")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def require_scoped_release_git(r81, commit: str) -> tuple[str, ...]:
    if not HEX40.fullmatch(commit):
        raise ValueError("release commit must be a full lowercase Git commit id")
    if not r81._git_is_ancestor(commit):
        raise ValueError("release commit is not an ancestor of the current checkout")
    scoped = tuple(sorted(set(r81.RUNTIME_FILES) | set(CLOSEOUT_TRACKED_PRODUCERS)))
    changed = [relative for relative in scoped
               if not r81._git_path_clean(commit, relative)]
    if changed:
        raise ValueError(f"scoped producer differs from release commit: {changed[0]}")
    return scoped


def binding_file_paths(r81, binding: dict[str, Any]) -> dict[str, Path]:
    direct = (
        "watch_status", "action_receipt", "profile", "census_raw_report",
        "census_rows", "census_pair_proofs", "census_query_producer",
        "census_validation_producer",
    )
    paths = {name: Path(binding[name]["path"]).resolve() for name in direct}
    paths["census"] = (r81.REPO / binding["census"]["repo_path"]).resolve()
    return paths


def require_same_census_inputs(base, binding: dict[str, Any], report: Path, report_sha: str,
                               rows: Path, rows_sha: str, proofs: Path, proofs_sha: str) -> None:
    expected = {
        "census_raw_report": (report.resolve(), report_sha),
        "census_rows": (rows.resolve(), rows_sha),
        "census_pair_proofs": (proofs.resolve(), proofs_sha),
    }
    for name, (path, digest) in expected.items():
        item = binding.get(name)
        if (not isinstance(item, dict) or Path(str(item.get("path"))).resolve() != path
                or item.get("sha256") != digest):
            raise ValueError(f"native r80_completion {name} differs from caller census input")


def parser() -> argparse.ArgumentParser:
    root = argparse.ArgumentParser(description=__doc__)
    sub = root.add_subparsers(dest="command", required=True)
    closeout = sub.add_parser("closeout")
    closeout.add_argument("--census-report", type=Path, required=True)
    closeout.add_argument("--census-report-sha256", required=True)
    closeout.add_argument("--rows-json", type=Path, required=True)
    closeout.add_argument("--rows-sha256", required=True)
    closeout.add_argument("--pair-proofs-json", type=Path, required=True)
    closeout.add_argument("--pair-proofs-sha256", required=True)
    closeout.add_argument("--r80-completion-binding", type=Path, required=True)
    closeout.add_argument("--r80-completion-binding-sha256", required=True)
    closeout.add_argument("--r81-private-dataset", type=Path, required=True)
    closeout.add_argument("--r81-private-dataset-path-sha256", required=True)
    closeout.add_argument("--release-commit", required=True)
    closeout.add_argument("--expected-cutoff-id", required=True)
    closeout.add_argument("--expected-jobs-sha256", required=True)
    closeout.add_argument("--repeat-store", action="append", default=[])
    closeout.add_argument("--out-dir", type=Path, required=True)
    closeout.add_argument("--gate-receipt", type=Path)
    replay = sub.add_parser("replay-existing-pair")
    replay.add_argument("--main-json", type=Path, required=True)
    replay.add_argument("--main-npz", type=Path, required=True)
    replay.add_argument("--repeat-json", type=Path, required=True)
    replay.add_argument("--repeat-npz", type=Path, required=True)
    replay.add_argument("--expected-result", type=Path, required=True)
    replay.add_argument("--label", default="existing_saved_pair")
    replay.add_argument("--out-json", type=Path, required=True)
    return root


def run_closeout(base, args: argparse.Namespace) -> int:
    report_path = args.census_report.resolve()
    report = base.census_gate(report_path, args.census_report_sha256)

    binding_path = args.r80_completion_binding.resolve()
    base.require_sha(binding_path, args.r80_completion_binding_sha256,
                     "native r80_completion binding")
    binding = base.read_json(binding_path)
    if not isinstance(binding, dict):
        raise ValueError("native r80_completion binding must be a JSON object")
    dataset = args.r81_private_dataset
    if not dataset.is_absolute():
        raise ValueError("R81 private dataset path must be absolute")
    if path_binding_sha(dataset) != args.r81_private_dataset_path_sha256:
        raise ValueError("R81 private dataset pathname binding differs")

    from script import profiled_batch as pb
    from script import r81_worker_entry as r81
    from script.figs.symmetry_profile import render
    from script.symmetry_analysis import analyze_profile_stores
    from script.symmetry_factory_cycle import (
        _content_id,
        _require_pair_bindings,
        _snapshot_successes_from_proofs,
    )
    from antenna.measurement import measurement_id, score_spec_id

    validator_path = Path(r81.__file__).resolve()
    if sha256(validator_path) != R81_VALIDATOR_SHA256:
        raise ValueError("native R81 validator source differs from the reviewed binding")
    scoped_producer_files = require_scoped_release_git(r81, args.release_commit)
    native_result = r81._validate_r80(binding, dataset, args.release_commit)

    rows_path = args.rows_json.resolve()
    proofs_path = args.pair_proofs_json.resolve()
    rows_sha = base.require_sha(rows_path, args.rows_sha256, "rows")
    proofs_sha = base.require_sha(proofs_path, args.pair_proofs_sha256, "pair proofs")
    require_same_census_inputs(
        base, binding, report_path, args.census_report_sha256,
        rows_path, rows_sha, proofs_path, proofs_sha)
    if (report.get("rows_sha256") != rows_sha
            or report.get("pair_proofs_sha256") != proofs_sha):
        raise ValueError("raw census report differs from caller rows/proofs")

    rows, proofs = base.read_json(rows_path), base.read_json(proofs_path)
    candidates, unique_hashes = base.validate_census_documents(report, rows, proofs)
    cutoff_id = _content_id(proofs)
    if cutoff_id != args.expected_cutoff_id:
        raise ValueError("canonical pair-proof cutoff_id differs from explicit pin")
    jobs_sha = report.get("jobs_sha256_at_scan_start")
    if jobs_sha != args.expected_jobs_sha256:
        raise ValueError("snapshot jobs hash differs from explicit pin")
    groups = base.repeat_groups(candidates, proofs, args.repeat_store)
    if native_result != {"measurement_id": report.get("measurement_id"),
                         "score_spec_id": report.get("score_spec_id")}:
        raise ValueError("native gate profile identity differs from raw final census")

    output = args.out_dir.resolve()
    if output.exists():
        raise FileExistsError(f"closeout destination already exists: {output}")
    bound_paths = binding_file_paths(r81, binding)
    code_paths = [
        Path(__file__).resolve(), V001_PATH, validator_path,
        Path("script/profiled_shards.py").resolve(),
        Path("script/symmetry_factory_cycle.py").resolve(),
        Path("script/symmetry_analysis.py").resolve(),
        Path("script/figs/symmetry_profile.py").resolve(),
        Path("script/figs/report_r1r10_style.py").resolve(),
    ]
    stable_paths = [binding_path] + list(bound_paths.values())
    before = {str(path): sha256(path) for path in code_paths + stable_paths}
    _require_pair_bindings(proofs)
    first_input = Path(proofs[0]["input"])
    cfg = pb.load_profile_config(first_input / "config.yaml")
    if (measurement_id(cfg.measurement) != report.get("measurement_id")
            or score_spec_id(cfg.score_spec) != report.get("score_spec_id")):
        raise ValueError("proof config identity differs from native-gated final census")

    output.mkdir(parents=True, exist_ok=False)
    unique_store = _snapshot_successes_from_proofs(
        {"pair_proofs": proofs}, output / "unique_frozen_store", unique_hashes, cfg)
    repeat_root = output / "repeat_frozen_stores"
    repeat_stores: list[tuple[str, str, Path]] = []
    for source_store, (store_proofs, hashes) in groups.items():
        label = (f"{Path(source_store).name}_"
                 f"{hashlib.sha256(source_store.encode('utf-8')).hexdigest()[:10]}")
        frozen = _snapshot_successes_from_proofs(
            {"pair_proofs": store_proofs}, repeat_root / label, hashes, cfg)
        repeat_stores.append((label, source_store, frozen))

    analysis_root = output / "analysis"
    analysis_root.mkdir()
    combined_json, combined_npz = analysis_root / "combined.json", analysis_root / "combined.npz"
    combined = analyze_profile_stores(
        [unique_store] + [path for _label, _source, path in repeat_stores],
        combined_json, combined_npz)
    repeat_count = sum(len(hashes) for _store, (_proofs, hashes) in groups.items())
    if (combined["counts"]["unique_selected_rows"] != base.TARGET_UNIQUE
            or combined["counts"]["validated_complete_source_rows"]
            != base.TARGET_UNIQUE + repeat_count):
        raise ValueError("combined profile counts differ from final unique plus all repeats")

    repeat_profiles: list[tuple[str, Path, Path]] = []
    store_mapping: dict[str, dict[str, str]] = {}
    for label, source_store, frozen in repeat_stores:
        repeat_json = analysis_root / f"repeat_{label}.json"
        repeat_npz = analysis_root / f"repeat_{label}.npz"
        summary = analyze_profile_stores([frozen], repeat_json, repeat_npz)
        if summary["counts"]["unique_selected_rows"] != summary["counts"]["repeat_or_notarize_selected"]:
            raise ValueError(f"separate repeat profile retained a non-repeat row: {label}")
        repeat_profiles.append((label, repeat_json, repeat_npz))
        store_mapping[label] = {
            "declared_source_store": source_store,
            "frozen_store": str(frozen.resolve()),
            "profile_json": str(repeat_json.resolve()),
            "profile_npz": str(repeat_npz.resolve()),
        }

    residual_summary, residual_arrays = base.profile_residuals(
        combined_json, combined_npz, repeat_profiles)
    residual_summary["repeat_profile_store_mapping"] = store_mapping
    residual_summary["store_index_scope"] = (
        "combined indices address combined.json sources; repeat indices address only the named separate repeat profile")
    for record in residual_summary["records"]:
        label = record["repeat_profile"]
        record["repeat_source_store"] = store_mapping[label]["declared_source_store"]
        record["original_combined_source_store_index"] = record.pop("original_source_store_index")
        record["repeat_profile_local_source_store_index"] = record.pop("repeat_source_store_index")
    residual_json = analysis_root / "repeat_residuals.json"
    residual_npz = analysis_root / "repeat_residuals.npz"
    base.save_residuals(residual_summary, residual_arrays, residual_json, residual_npz)
    figure_receipt = render(combined_json, combined_npz, output / "population_figures")

    _require_pair_bindings(proofs)
    if require_scoped_release_git(r81, args.release_commit) != scoped_producer_files:
        raise ValueError("scoped producer set changed during closeout")
    after = {str(path): sha256(path) for path in code_paths + stable_paths}
    if before != after:
        raise ValueError("code or native-gated final evidence changed during closeout")

    watch = base.read_json(bound_paths["watch_status"])
    action = base.read_json(bound_paths["action_receipt"])
    census = base.read_json(bound_paths["census"])
    native_provenance = {
        "validator": str(validator_path),
        "validator_sha256": R81_VALIDATOR_SHA256,
        "r80_completion_binding": str(binding_path),
        "r80_completion_binding_sha256": args.r80_completion_binding_sha256,
        "release_git_commit": args.release_commit,
        "scoped_producers_clean_before_and_after": True,
        "scoped_git_producer_files": list(scoped_producer_files),
        "r81_private_dataset_path": str(dataset.resolve(strict=False)),
        "r81_private_dataset_path_sha256": args.r81_private_dataset_path_sha256,
        "watch": {"binding": binding["watch_status"], "status": watch.get("status"),
                  "valid_unique": watch.get("valid_unique"),
                  "last_receipt_sha256": watch.get("last_receipt_sha256")},
        "action": {"binding": binding["action_receipt"], "status": action.get("status"),
                   "valid_unique": action.get("valid_unique"),
                   "pending_unique": action.get("pending_unique"),
                   "planned_jobs": action.get("planned_jobs"),
                   "audit": action.get("audit"),
                   "audit_content_id": _content_id(action.get("audit"))},
        "validated_census": {"binding": binding["census"],
                             "validation_status": census.get("validation_status"),
                             "query_report_sha256": census.get("query_report_sha256")},
        "raw_census": binding["census_raw_report"],
        "rows": binding["census_rows"],
        "pair_proofs": binding["census_pair_proofs"],
        "profile": binding["profile"],
        "query_producer": binding["census_query_producer"],
        "validation_producer": binding["census_validation_producer"],
        "canonical_pair_proof_cutoff_id": cutoff_id,
        "snapshot_jobs_sha256": jobs_sha,
        "independent_per_job_terminal_rereplay_by_this_adapter": False,
    }
    source_bindings = {
        "schema_version": 4,
        "native_gate": native_provenance,
        "code_and_evidence_before": before,
        "code_and_evidence_after": after,
        "unchanged": True,
    }
    source_bindings_path = output / "source_bindings.json"
    base.write_json_exclusive(source_bindings_path, source_bindings)
    output_hashes = {str(path.relative_to(output)): sha256(path)
                     for path in sorted(output.rglob("*")) if path.is_file()}
    receipt = {
        "schema_version": 4,
        "status": "completed_final5000_closeout_after_native_r80_release_gate",
        "counts": {
            "unique_representatives": base.TARGET_UNIQUE,
            "repeat_observations": residual_summary["counts"]["repeat_observations_compared"],
            "repeat_source_stores": len(repeat_stores),
            "combined_duplicate_audit_rows": combined["counts"]["duplicate_rows_removed"],
        },
        "native_gate": native_provenance,
        "source_bindings_sha256": sha256(source_bindings_path),
        "figure_receipt": figure_receipt,
        "outputs_before_closeout_receipt": output_hashes,
        "scope": {
            "hfss_training_or_model_inference": False,
            "r81_dataset_read_or_created": False,
            "r81_wait_for_r80_statistics_or_figures": False,
            "physical_validation": "The native final census gate plus proof-bound root snapshot and existing profile replay are authoritative; this adapter does not independently replay every job terminal receipt.",
        },
        "limitations": [
            "The native gate validates saved watcher/action/audit and immutable census producer bindings; it does not independently replay every per-job success/failure receipt.",
            "Repeat residual confidence applies only to explicitly mapped repeated patterns.",
            "Combined duplicate_rows are provenance audit records, not computed repeat residuals.",
            "No mesh certification, causal claim, model evidence, or R81 release/adoption decision is produced.",
        ],
    }
    base.write_json_exclusive(output / "closeout_receipt.json", receipt)
    print(json.dumps(receipt, ensure_ascii=False))
    return 0


def main() -> int:
    base = load_v001()
    args = parser().parse_args()
    try:
        if args.command == "replay-existing-pair":
            return base.run_pair_replay(args)
        return run_closeout(base, args)
    except base.GateRejected as exc:
        receipt = {
            "schema_version": 4,
            "status": "rejected_before_native_gate_or_closeout_side_effects",
            "reason": exc.reason,
            **exc.details,
            "native_r80_release_gate_called": False,
            "limitations": [
                "This is a readiness-gap receipt, not a FINAL5000 closeout.",
                "No native completion or terminal claim is made before exact 5,000.",
            ],
        }
        if args.gate_receipt is not None:
            base.write_json_exclusive(args.gate_receipt.resolve(), receipt)
        print(json.dumps(receipt, ensure_ascii=False), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
