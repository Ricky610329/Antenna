# R80 FINAL5000 closeout adapter v004

v004 preserves v001/v002/v003 and reuses the accepted
`script.r81_worker_entry._validate_r80` gate unchanged.

The order is fail closed:

1. Read only the pinned raw census report and require exactly 5,000 unique rows.
2. Verify a pinned `r80_completion` binding, a pinned absolute private R81
   dataset pathname, and an explicit full release commit that is an ancestor of
   the checkout. Require only the exact native runtime plus closeout producer
   paths to be clean relative to that commit.
3. Invoke `_validate_r80`. This binds the saved watch/action/audit 5,000/zero-
   pending state, tracked validated census, raw report, rows, pair proofs, query
   and validation producers, canonical profile, and their hashes.
4. Require the native binding raw/rows/proofs paths and hashes to be exactly the
   caller inputs. Bind the canonical pair-proof content ID and census jobs hash.
5. Only then read proofs/source metadata and run the existing root snapshots,
   combined/separate profiles, aligned repeat residuals, and population figures.

Repeat stores are explicitly supplied with `--repeat-store`. Residual records
carry the declared source-store mapping, and combined versus repeat-local source
indices are named by their actual scope.

The native gate does not independently replay every job terminal receipt. Its
saved watcher/action/audit plus immutable validated final census are the accepted
completion authority; root proof snapshots and profile replay remain the
physical observation validation.

The private R81 dataset path is compared and passed only as a pathname. This
workflow does not require it to exist and does not read or create it. R81
preparation does not wait for the R80 statistics/figures to finish.

The pathname pin is SHA-256 over UTF-8 `str(Path(path).resolve(strict=False))`,
matching `path_binding_sha` in the adapter.

The exact scoped producer list is returned in both output receipts. Unrelated
tracked documentation and analysis work is outside this check and is neither
read nor required to be clean. The adapter's ignored helper code and all bound
source/census evidence remain protected by the existing before/after SHA-256
maps.
