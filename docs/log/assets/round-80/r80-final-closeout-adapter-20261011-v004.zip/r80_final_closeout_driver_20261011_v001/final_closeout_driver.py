"""Fail-closed R80 FINAL5000 closeout adapter over existing frozen-data APIs.

This module never discovers a live census.  It accepts a hash-pinned census and
an independently produced final-cutoff readiness proof, then delegates freezing,
profiling, and population figures to the established project implementations.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Mapping, Sequence


TARGET_UNIQUE = 5000
QUERY_SCRIPT_SHA256 = "da6a0034241d4d6f22ecfd1ce0272b4dbd06ec252737278b0539b4bec2b631ac"
SHA256_RE = re.compile(r"^[0-9a-f]{64}$")
TERMINAL_STATUSES = {"success", "failed", "error", "cancelled"}
ACTUAL_TERMINAL_EVIDENCE_KINDS = {
    "completed_results_cutoff",
    "terminal_worker_receipt",
    "terminal_failure_receipt",
    "terminal_cancellation_receipt",
}


class GateRejected(RuntimeError):
    def __init__(self, reason: str, details: Mapping[str, Any]):
        super().__init__(reason)
        self.reason = reason
        self.details = dict(details)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def write_json_exclusive(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")


def require_sha(path: Path, expected: str, label: str) -> str:
    if not SHA256_RE.fullmatch(expected):
        raise ValueError(f"{label} expected SHA-256 is malformed")
    actual = sha256(path)
    if actual != expected:
        raise ValueError(f"{label} SHA-256 mismatch: {actual} != {expected}")
    return actual


def resolve_from(document: Path, value: str) -> Path:
    path = Path(value)
    if not path.is_absolute():
        path = document.parent / path
    return path.resolve()


def census_gate(report_path: Path, expected_sha256: str) -> dict[str, Any]:
    """The only phase allowed before the EXACT5000 gate."""

    actual_sha256 = require_sha(report_path, expected_sha256, "census report")
    report = read_json(report_path)
    if report.get("query_script_sha256") != QUERY_SCRIPT_SHA256:
        raise GateRejected("unapproved_census_producer", {
            "expected_query_script_sha256": QUERY_SCRIPT_SHA256,
            "observed_query_script_sha256": report.get("query_script_sha256"),
            "census_report_sha256": actual_sha256,
        })
    observed = report.get("unique_successful_patterns")
    if observed != TARGET_UNIQUE:
        raise GateRejected("exact5000_not_ready", {
            "required_unique_successful_patterns": TARGET_UNIQUE,
            "observed_unique_successful_patterns": observed,
            "gap": TARGET_UNIQUE - observed if isinstance(observed, int) else None,
            "census_report": str(report_path.resolve()),
            "census_report_sha256": actual_sha256,
            "rows_read": False,
            "pair_proofs_read": False,
            "readiness_evidence_read": False,
            "terminal_evidence_read": False,
            "source_metadata_or_artifacts_read": False,
            "destination_checked_or_created": False,
            "nas_read_or_write": False,
            "snapshot_profile_figures_or_hfss": False,
        })
    return report


def successful_candidates(proofs: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
    candidates: list[dict[str, Any]] = []
    for pair_index, proof in enumerate(proofs):
        rows = proof.get("rows")
        results = proof.get("results")
        if not isinstance(rows, list) or not isinstance(results, dict):
            raise ValueError(f"pair proof {pair_index} has invalid rows/results")
        for row_index, row in enumerate(rows):
            entry = results.get(row.get("id"))
            if (not isinstance(entry, dict) or entry.get("status") != "ok"
                    or "error" in entry):
                continue
            candidates.append({
                "pair_index": pair_index,
                "row_index": row_index,
                "input": proof.get("input"),
                "store": proof.get("store"),
                "store_name": Path(str(proof.get("store"))).name,
                "row": row,
                "entry": entry,
                "repeat": row.get("kind") in ("repeat", "notarize"),
                "pattern_sha256": row.get("pattern_sha256"),
                "proof": proof,
            })
    return candidates


def validate_census_documents(report: Mapping[str, Any], rows: Any,
                              proofs: Any) -> tuple[list[dict[str, Any]], list[str]]:
    if not isinstance(rows, list) or not isinstance(proofs, list) or not proofs:
        raise ValueError("rows and pair proofs must be nonempty JSON lists")
    candidates = successful_candidates(proofs)
    if len(candidates) != len(rows):
        raise ValueError("rows do not enumerate every successful proof observation")
    if report.get("successful_including_repeats") != len(rows):
        raise ValueError("census successful count differs from rows")
    if report.get("rows_sha256") is None or report.get("pair_proofs_sha256") is None:
        raise ValueError("census report lacks row/proof bindings")

    compared = ("id", "pattern_sha256", "sample_sha256", "rad_sha256")
    for index, (saved, candidate) in enumerate(zip(rows, candidates)):
        expected = {
            "id": candidate["row"].get("id"),
            "pattern_sha256": candidate["pattern_sha256"],
            "sample_sha256": candidate["entry"].get("sample_sha256"),
            "rad_sha256": candidate["entry"].get("rad_sha256"),
        }
        if any(saved.get(key) != expected[key] for key in compared):
            raise ValueError(f"rows/proofs identity mismatch at observation {index}")
        if (saved.get("pair_index") != candidate["pair_index"]
                or saved.get("row_index") != candidate["row_index"]
                or saved.get("store") != candidate["store_name"]
                or bool(saved.get("repeat")) != candidate["repeat"]):
            raise ValueError(f"rows/proofs provenance mismatch at observation {index}")
        if (candidate["entry"].get("measurement_id") != report.get("measurement_id")
                or candidate["entry"].get("score_spec_id") != report.get("score_spec_id")):
            raise ValueError(f"rows/proofs profile identity mismatch at observation {index}")
        if not SHA256_RE.fullmatch(str(candidate["pattern_sha256"])):
            raise ValueError(f"invalid pattern SHA-256 at observation {index}")

    winners: dict[str, tuple[tuple[bool, int, int], dict[str, Any]]] = {}
    for candidate in candidates:
        digest = candidate["pattern_sha256"]
        priority = (candidate["repeat"], candidate["pair_index"], candidate["row_index"])
        if digest not in winners or priority < winners[digest][0]:
            winners[digest] = (priority, candidate)
    ordered = [item[1]["pattern_sha256"]
               for item in sorted(winners.values(), key=lambda item: item[0])]
    if len(ordered) != TARGET_UNIQUE:
        raise ValueError("proof-derived unique count is not exactly 5000")
    if report.get("unique_successful_patterns") != len(ordered):
        raise ValueError("census unique count differs from proofs")
    return candidates, ordered


def validate_terminal_readiness(readiness_path: Path, readiness: Mapping[str, Any],
                                report_sha: str, rows_sha: str, proofs_sha: str,
                                successful_including_repeats: int,
                                proof_cutoff_id: str) -> tuple[Path, dict[str, str]]:
    if (readiness.get("schema_version") != 1
            or readiness.get("status") != "ready_exact5000_all_reserved_terminal"):
        raise ValueError("final readiness status/schema is not accepted")
    census = readiness.get("census")
    expected_census = {
        "report_sha256": report_sha,
        "rows_sha256": rows_sha,
        "pair_proofs_sha256": proofs_sha,
        "unique_successful_patterns": TARGET_UNIQUE,
        "successful_including_repeats": successful_including_repeats,
    }
    if not isinstance(census, dict) or any(census.get(k) != v for k, v in expected_census.items()):
        raise ValueError("readiness census bindings differ from pinned FINAL5000 inputs")
    if readiness.get("cutoff_id") != proof_cutoff_id:
        raise ValueError("readiness cutoff_id differs from canonical pair proofs")

    jobs = readiness.get("reserved_jobs")
    if not isinstance(jobs, dict):
        raise ValueError("readiness lacks reserved_jobs proof binding")
    terminal_proof_path = resolve_from(readiness_path, str(jobs.get("proof_path", "")))
    terminal_proof_sha = require_sha(
        terminal_proof_path, str(jobs.get("proof_sha256", "")), "terminal proof")
    terminal = read_json(terminal_proof_path)
    count = terminal.get("reserved_count")
    if (terminal.get("schema_version") != 1
            or terminal.get("proof_kind") != "actual_reserved_job_terminal_cutoff"
            or terminal.get("cutoff_id") != proof_cutoff_id
            or terminal.get("terminal_basis") != "actual_receipts_not_state_or_lock_inference"
            or not isinstance(count, int) or count <= 0
            or terminal.get("terminal_count") != count
            or terminal.get("pending_count") != 0
            or terminal.get("all_reserved_jobs_terminal") is not True):
        raise ValueError("terminal proof does not establish all reserved jobs terminal with zero pending")
    if (jobs.get("reserved_count") != count or jobs.get("terminal_count") != count
            or jobs.get("pending_count") != 0 or jobs.get("all_terminal") is not True):
        raise ValueError("readiness reserved-job summary differs from terminal proof")
    items = terminal.get("jobs")
    if not isinstance(items, list) or len(items) != count:
        raise ValueError("terminal proof job inventory does not match reserved_count")
    ids = [item.get("job_id") for item in items if isinstance(item, dict)]
    if len(ids) != count or any(not isinstance(value, str) or not value for value in ids):
        raise ValueError("terminal proof contains invalid job ids")
    if len(set(ids)) != count:
        raise ValueError("terminal proof contains duplicate reserved job ids")

    evidence_hashes = {str(terminal_proof_path): terminal_proof_sha}
    for item in items:
        status = item.get("terminal_status")
        kind = item.get("actual_evidence_kind")
        if status not in TERMINAL_STATUSES or kind not in ACTUAL_TERMINAL_EVIDENCE_KINDS:
            raise ValueError(f"job {item.get('job_id')} lacks accepted actual terminal evidence")
        evidence = resolve_from(terminal_proof_path, str(item.get("actual_evidence_path", "")))
        evidence_hashes[str(evidence)] = require_sha(
            evidence, str(item.get("actual_evidence_sha256", "")),
            f"terminal evidence for {item.get('job_id')}")
    return terminal_proof_path, evidence_hashes


def repeat_groups(candidates: Sequence[Mapping[str, Any]], proofs: Sequence[Mapping[str, Any]],
                  declared: Any) -> dict[str, tuple[list[Mapping[str, Any]], list[str]]]:
    if not isinstance(declared, list) or any(not isinstance(value, str) for value in declared):
        raise ValueError("readiness repeat_source_stores must be an explicit string list")
    if len(set(declared)) != len(declared):
        raise ValueError("readiness repeat_source_stores contains duplicates")
    discovered = {str(item["store"]) for item in candidates if item["repeat"]}
    if set(declared) != discovered:
        raise ValueError("declared repeat stores do not exactly enumerate final-cutoff repeat observations")
    if not discovered:
        raise ValueError("no final-cutoff repeat observations were declared")

    proofs_by_store: dict[str, list[Mapping[str, Any]]] = defaultdict(list)
    for proof in proofs:
        proofs_by_store[str(proof.get("store"))].append(proof)
    groups = {}
    for store in declared:
        if len(proofs_by_store[store]) != 1:
            raise ValueError(f"repeat source store has ambiguous proof cardinality: {store}")
        members = [item for item in candidates if str(item["store"]) == store]
        if any(not item["repeat"] for item in members):
            raise ValueError(
                f"declared repeat source store contains a successful non-repeat observation; "
                f"a more explicit observation-level contract is required: {store}")
        hashes = [str(item["pattern_sha256"]) for item in members]
        counts = Counter(hashes)
        duplicates = sorted(digest for digest, count in counts.items() if count != 1)
        if duplicates:
            raise ValueError(
                f"repeat source store contains same-pattern observations; observation-level freeze required: "
                f"{store}: {duplicates}")
        groups[store] = (proofs_by_store[store], hashes)
    return groups


def profile_residuals(main_json: Path, main_npz: Path,
                      repeat_profiles: Sequence[tuple[str, Path, Path]]) -> tuple[dict[str, Any], dict[str, np.ndarray]]:
    """Generalize the saved one-pair aligned-NPZ subtraction without new scoring."""

    import numpy as np

    main_summary = read_json(main_json)
    with np.load(main_npz, allow_pickle=False) as loaded:
        main = {key: loaded[key] for key in loaded.files}
    main_hashes = [str(value) for value in main["pattern_sha256"].tolist()]
    if len(main_hashes) != len(set(main_hashes)):
        raise ValueError("main profile NPZ contains duplicate pattern hashes")
    main_index = {digest: index for index, digest in enumerate(main_hashes)}
    main_rows = {row["pattern_sha256"]: row for row in main_summary["rows"]}

    records: list[dict[str, Any]] = []
    source_labels: list[str] = []
    pattern_hashes: list[str] = []
    original_ids: list[str] = []
    repeat_ids: list[str] = []
    response_deltas: list[np.ndarray] = []
    radiation_deltas: list[np.ndarray] = []
    for label, repeat_json, repeat_npz in repeat_profiles:
        repeat_summary = read_json(repeat_json)
        with np.load(repeat_npz, allow_pickle=False) as loaded:
            repeat = {key: loaded[key] for key in loaded.files}
        if (not np.array_equal(main["response_freqs_ghz"], repeat["response_freqs_ghz"])
                or not np.array_equal(main["radiation_theta_deg"], repeat["radiation_theta_deg"])):
            raise ValueError(f"repeat profile grids differ from main profile: {label}")
        repeat_rows = {row["pattern_sha256"]: row for row in repeat_summary["rows"]}
        repeat_hashes = [str(value) for value in repeat["pattern_sha256"].tolist()]
        if len(repeat_hashes) != len(set(repeat_hashes)):
            raise ValueError(f"repeat profile contains duplicate pattern hashes: {label}")
        for repeat_index, digest in enumerate(repeat_hashes):
            if digest not in main_index or digest not in main_rows or digest not in repeat_rows:
                raise ValueError(f"repeat pattern absent from main unique profile: {label}: {digest}")
            original_index = main_index[digest]
            if not np.array_equal(main["patterns"][original_index], repeat["patterns"][repeat_index]):
                raise ValueError(f"repeat/main physical patterns differ: {label}: {digest}")
            response_delta = repeat["responses"][repeat_index] - main["responses"][original_index]
            radiation_delta = repeat["radiation"][repeat_index] - main["radiation"][original_index]
            original_row, repeat_row = main_rows[digest], repeat_rows[digest]
            original_wm = min(original_row["s11_band_margin_db"], original_row["gain_band_margin_db"])
            repeat_wm = min(repeat_row["s11_band_margin_db"], repeat_row["gain_band_margin_db"])
            records.append({
                "repeat_profile": label,
                "pattern_sha256": digest,
                "original_id": str(main["ids"][original_index]),
                "repeat_id": str(repeat["ids"][repeat_index]),
                "original_wm_db": original_wm,
                "repeat_wm_db": repeat_wm,
                "repeat_minus_original_wm_db": repeat_wm - original_wm,
                "repeat_minus_original_s11_margin_db": (
                    repeat_row["s11_band_margin_db"] - original_row["s11_band_margin_db"]),
                "repeat_minus_original_gain_margin_db": (
                    repeat_row["gain_band_margin_db"] - original_row["gain_band_margin_db"]),
                "s11_gain_curve_max_abs_repeat_delta_db": np.abs(response_delta).max(axis=1).tolist(),
                "phi0_phi90_curve_max_abs_repeat_delta_db": np.abs(radiation_delta).max(axis=1).tolist(),
                "original_source_store_index": original_row["source_store_index"],
                "repeat_source_store_index": repeat_row["source_store_index"],
            })
            source_labels.append(label)
            pattern_hashes.append(digest)
            original_ids.append(str(main["ids"][original_index]))
            repeat_ids.append(str(repeat["ids"][repeat_index]))
            response_deltas.append(response_delta)
            radiation_deltas.append(radiation_delta)

    if not records:
        raise ValueError("no repeat residual records were produced")
    arrays = {
        "repeat_profile": np.asarray(source_labels, dtype=np.str_),
        "pattern_sha256": np.asarray(pattern_hashes, dtype=np.str_),
        "original_id": np.asarray(original_ids, dtype=np.str_),
        "repeat_id": np.asarray(repeat_ids, dtype=np.str_),
        "response_freqs_ghz": main["response_freqs_ghz"],
        "response_delta_db": np.stack(response_deltas),
        "radiation_theta_deg": main["radiation_theta_deg"],
        "radiation_delta_db": np.stack(radiation_deltas),
    }
    summary = {
        "schema_version": 1,
        "analysis_kind": "repeat_minus_unique_representative_aligned_curve_residuals",
        "definitions": {
            "response_delta_db": "repeat response minus unique representative response on the identical aligned frequency grid",
            "radiation_delta_db": "repeat cut minus unique representative cut on the identical aligned theta grid",
            "wm_delta_db": "repeat WM minus unique representative WM",
        },
        "counts": {"repeat_observations_compared": len(records),
                   "repeat_profiles": len(repeat_profiles)},
        "records": records,
        "limitations": [
            "These are explicit aligned-curve differences, not duplicate_rows audit entries.",
            "Field mirror residuals describe within-observation symmetry and are not repeat error.",
            "Repeat residuals provide physical repeat evidence only for enumerated repeated patterns; they do not certify all 5,000 unique geometries.",
        ],
    }
    return summary, arrays


def save_residuals(summary: dict[str, Any], arrays: dict[str, np.ndarray],
                   out_json: Path, out_npz: Path) -> None:
    import numpy as np

    if out_json.exists() or out_npz.exists():
        raise FileExistsError("repeat residual output already exists")
    np.savez_compressed(out_npz, **arrays)
    bound = dict(summary)
    bound["curve_storage"] = {
        "path": str(out_npz.resolve()),
        "sha256": sha256(out_npz),
        "arrays": {key: list(value.shape) for key, value in arrays.items()},
    }
    write_json_exclusive(out_json, bound)


def run_closeout(args: argparse.Namespace) -> int:
    report_path = args.census_report.resolve()
    report = census_gate(report_path, args.census_report_sha256)
    required = {
        "rows_json": args.rows_json, "rows_sha256": args.rows_sha256,
        "pair_proofs_json": args.pair_proofs_json,
        "pair_proofs_sha256": args.pair_proofs_sha256,
        "readiness_json": args.readiness_json, "readiness_sha256": args.readiness_sha256,
    }
    missing = sorted(key for key, value in required.items() if value is None)
    if missing:
        raise ValueError(f"EXACT5000 mode requires: {missing}")

    rows_path = args.rows_json.resolve()
    proofs_path = args.pair_proofs_json.resolve()
    readiness_path = args.readiness_json.resolve()
    rows_sha = require_sha(rows_path, args.rows_sha256, "rows")
    proofs_sha = require_sha(proofs_path, args.pair_proofs_sha256, "pair proofs")
    readiness_sha = require_sha(readiness_path, args.readiness_sha256, "readiness")
    if report.get("rows_sha256") != rows_sha or report.get("pair_proofs_sha256") != proofs_sha:
        raise ValueError("census report does not bind the supplied rows/pair proofs")
    rows, proofs, readiness = read_json(rows_path), read_json(proofs_path), read_json(readiness_path)
    candidates, unique_hashes = validate_census_documents(report, rows, proofs)

    from antenna.measurement import measurement_id, score_spec_id
    from script import profiled_batch as pb
    from script.figs.symmetry_profile import render
    from script.symmetry_analysis import analyze_profile_stores
    from script.symmetry_factory_cycle import (
        _content_id,
        _require_pair_bindings,
        _snapshot_successes_from_proofs,
    )

    cutoff_id = _content_id(proofs)
    terminal_proof, terminal_evidence_hashes = validate_terminal_readiness(
        readiness_path, readiness, args.census_report_sha256, rows_sha, proofs_sha,
        len(rows), cutoff_id)
    groups = repeat_groups(candidates, proofs, readiness.get("repeat_source_stores"))
    output = args.out_dir.resolve()
    if output.exists():
        raise FileExistsError(f"closeout destination already exists: {output}")

    code_paths = [
        Path(__file__).resolve(), Path("script/profiled_shards.py").resolve(),
        Path("script/symmetry_factory_cycle.py").resolve(),
        Path("script/symmetry_analysis.py").resolve(),
        Path("script/figs/symmetry_profile.py").resolve(),
        Path("script/figs/report_r1r10_style.py").resolve(),
    ]
    stable_paths = [report_path, rows_path, proofs_path, readiness_path, terminal_proof]
    stable_paths.extend(Path(value) for value in terminal_evidence_hashes if Path(value) != terminal_proof)
    before = {str(path): sha256(path) for path in code_paths + stable_paths}
    _require_pair_bindings(proofs)
    first_input = Path(proofs[0]["input"])
    cfg = pb.load_profile_config(first_input / "config.yaml")
    if (measurement_id(cfg.measurement) != report.get("measurement_id")
            or score_spec_id(cfg.score_spec) != report.get("score_spec_id")):
        raise ValueError("proof config identity differs from final census")

    output.mkdir(parents=True, exist_ok=False)
    unique_store = _snapshot_successes_from_proofs(
        {"pair_proofs": proofs}, output / "unique_frozen_store", unique_hashes, cfg)
    repeat_root = output / "repeat_frozen_stores"
    repeat_stores: list[tuple[str, Path]] = []
    for store, (store_proofs, hashes) in groups.items():
        label = f"{Path(store).name}_{hashlib.sha256(store.encode('utf-8')).hexdigest()[:10]}"
        frozen = _snapshot_successes_from_proofs(
            {"pair_proofs": store_proofs}, repeat_root / label, hashes, cfg)
        repeat_stores.append((label, frozen))

    analysis_root = output / "analysis"
    analysis_root.mkdir()
    combined_json, combined_npz = analysis_root / "combined.json", analysis_root / "combined.npz"
    combined = analyze_profile_stores(
        [unique_store] + [path for _label, path in repeat_stores], combined_json, combined_npz)
    if combined["counts"]["unique_selected_rows"] != TARGET_UNIQUE:
        raise ValueError("combined profile does not retain exactly 5000 unique representatives")
    if combined["counts"]["validated_complete_source_rows"] != TARGET_UNIQUE + sum(
            len(hashes) for _store, (_proofs, hashes) in groups.items()):
        raise ValueError("combined profile observation count differs from unique plus all repeats")

    repeat_profiles: list[tuple[str, Path, Path]] = []
    for label, frozen in repeat_stores:
        repeat_json = analysis_root / f"repeat_{label}.json"
        repeat_npz = analysis_root / f"repeat_{label}.npz"
        summary = analyze_profile_stores([frozen], repeat_json, repeat_npz)
        if summary["counts"]["unique_selected_rows"] != summary["counts"]["repeat_or_notarize_selected"]:
            raise ValueError(f"separate repeat profile retained a non-repeat row: {label}")
        repeat_profiles.append((label, repeat_json, repeat_npz))

    residual_summary, residual_arrays = profile_residuals(
        combined_json, combined_npz, repeat_profiles)
    residual_json = analysis_root / "repeat_residuals.json"
    residual_npz = analysis_root / "repeat_residuals.npz"
    save_residuals(residual_summary, residual_arrays, residual_json, residual_npz)
    figure_receipt = render(combined_json, combined_npz, output / "population_figures")

    _require_pair_bindings(proofs)
    after = {str(path): sha256(path) for path in code_paths + stable_paths}
    if before != after:
        raise ValueError("code, census, readiness, terminal, or source evidence changed during closeout")
    source_bindings = {
        "schema_version": 1,
        "census": {"report": args.census_report_sha256, "rows": rows_sha,
                   "pair_proofs": proofs_sha, "cutoff_id": cutoff_id},
        "readiness": {"path": str(readiness_path), "sha256": readiness_sha,
                      "terminal_proof": str(terminal_proof),
                      "terminal_evidence": terminal_evidence_hashes},
        "code_and_inputs_before": before,
        "code_and_inputs_after": after,
        "unchanged": True,
    }
    source_bindings_path = output / "source_bindings.json"
    write_json_exclusive(source_bindings_path, source_bindings)
    output_hashes = {str(path.relative_to(output)): sha256(path)
                     for path in sorted(output.rglob("*")) if path.is_file()}
    receipt = {
        "schema_version": 1,
        "status": "completed_final5000_closeout_from_explicit_frozen_cutoff",
        "counts": {
            "unique_representatives": TARGET_UNIQUE,
            "repeat_observations": residual_summary["counts"]["repeat_observations_compared"],
            "repeat_source_stores": len(repeat_stores),
            "combined_duplicate_audit_rows": combined["counts"]["duplicate_rows_removed"],
        },
        "methods": {
            "freeze": "script.symmetry_factory_cycle._snapshot_successes_from_proofs",
            "profile": "script.symmetry_analysis.analyze_profile_stores",
            "figures": "script.figs.symmetry_profile.render",
            "repeat_residual": "repeat-minus-unique subtraction on existing aligned profile NPZ arrays",
        },
        "source_bindings_sha256": sha256(source_bindings_path),
        "figure_receipt": figure_receipt,
        "outputs_before_closeout_receipt": output_hashes,
        "scope": {
            "hfss_training_or_model_inference": False,
            "live_census_or_queue_discovery": False,
            "source_mutation": False,
            "physical_confidence": "Full physical validation is replayed for the frozen unique/repeat stores; repeat residual confidence applies only to explicitly repeated patterns.",
        },
        "limitations": [
            "The adapter depends on a separately produced, hash-pinned actual-terminal readiness proof and does not infer terminal status from state files, locks, or absence.",
            "Combined duplicate_rows are provenance audit records and are not labeled as computed repeat residuals.",
            "Population quantiles and figures count unique representatives; separate profiles and residual outputs retain repeat observations.",
            "This closeout does not provide mesh certification, repeat coverage for unrepeated patterns, causal evidence, model evidence, or an R81 release decision.",
        ],
    }
    write_json_exclusive(output / "closeout_receipt.json", receipt)
    print(json.dumps(receipt, ensure_ascii=False))
    return 0


def run_pair_replay(args: argparse.Namespace) -> int:
    paths = [args.main_json.resolve(), args.main_npz.resolve(), args.repeat_json.resolve(),
             args.repeat_npz.resolve(), args.expected_result.resolve()]
    before = {str(path): sha256(path) for path in paths}
    summary, _arrays = profile_residuals(
        paths[0], paths[1], [(args.label, paths[2], paths[3])])
    expected = read_json(paths[4])
    if len(summary["records"]) != 1:
        raise ValueError("existing pair replay expected exactly one residual record")
    row = summary["records"][0]
    checks = {
        "original_wm_db": row["original_wm_db"] == expected["original_wm_db"],
        "repeat_wm_db": row["repeat_wm_db"] == expected["repeat_wm_db"],
        "repeat_minus_original_wm_db": (
            row["repeat_minus_original_wm_db"] == expected["repeat_minus_original_wm_db"]),
        "s11_gain_curve_max_abs_repeat_delta_db": (
            row["s11_gain_curve_max_abs_repeat_delta_db"]
            == expected["s11_gain_curve_max_abs_repeat_delta_db"]),
        "phi0_phi90_curve_max_abs_repeat_delta_db": (
            row["phi0_phi90_curve_max_abs_repeat_delta_db"]
            == expected["phi0_phi90_curve_max_abs_repeat_delta_db"]),
    }
    after = {str(path): sha256(path) for path in paths}
    if not all(checks.values()) or before != after:
        raise ValueError("existing saved pair residual replay failed")
    result = {
        "schema_version": 1,
        "status": "passed_existing_saved_pair_aligned_npz_residual_replay",
        "checks": checks,
        "record": row,
        "inputs_before": before,
        "inputs_after": after,
        "inputs_unchanged": True,
        "nas_read_or_write": False,
        "hfss_training_model_or_profile_rerun": False,
        "scope": "One existing local saved original/repeat pair; not FINAL5000 readiness or repeat coverage.",
    }
    write_json_exclusive(args.out_json.resolve(), result)
    print(json.dumps(result, ensure_ascii=False))
    return 0


def parser() -> argparse.ArgumentParser:
    root = argparse.ArgumentParser(description=__doc__)
    sub = root.add_subparsers(dest="command", required=True)
    closeout = sub.add_parser("closeout")
    closeout.add_argument("--census-report", type=Path, required=True)
    closeout.add_argument("--census-report-sha256", required=True)
    closeout.add_argument("--rows-json", type=Path)
    closeout.add_argument("--rows-sha256")
    closeout.add_argument("--pair-proofs-json", type=Path)
    closeout.add_argument("--pair-proofs-sha256")
    closeout.add_argument("--readiness-json", type=Path)
    closeout.add_argument("--readiness-sha256")
    closeout.add_argument("--out-dir", type=Path, required=True)
    closeout.add_argument("--gate-receipt", type=Path)
    replay = sub.add_parser("replay-existing-pair")
    replay.add_argument("--main-json", type=Path, required=True)
    replay.add_argument("--main-npz", type=Path, required=True)
    replay.add_argument("--repeat-json", type=Path, required=True)
    replay.add_argument("--repeat-npz", type=Path, required=True)
    replay.add_argument("--expected-result", type=Path, required=True)
    replay.add_argument("--label", default="existing_saved_pair")
    replay.add_argument("--out-json", type=Path, required=True)
    return root


def main() -> int:
    args = parser().parse_args()
    try:
        if args.command == "closeout":
            return run_closeout(args)
        return run_pair_replay(args)
    except GateRejected as exc:
        receipt = {
            "schema_version": 1,
            "status": "rejected_before_final_closeout_side_effects",
            "reason": exc.reason,
            **exc.details,
            "limitations": [
                "This is a readiness-gap receipt, not a FINAL5000 closeout.",
                "No terminal claim is made because terminal evidence was intentionally not read before EXACT5000.",
            ],
        }
        if getattr(args, "gate_receipt", None) is not None:
            write_json_exclusive(args.gate_receipt.resolve(), receipt)
        print(json.dumps(receipt, ensure_ascii=False), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
