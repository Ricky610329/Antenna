from __future__ import annotations

import hashlib
import json
import math
import sys
import time
from pathlib import Path

import torch


REPO = Path(__file__).resolve().parents[2]
if str(REPO) not in sys.path:
    sys.path.insert(0, str(REPO))

from script import exploration
from script import symmetry_training as training


ROOT = REPO / "tmp" / "r80_factory_20261007" / "training_familydev_v1"
CYCLE_ID = "81fbb84ab00b60764b69a74155d8eac12aab273cf1d0f74ec59e75c099a66907"
CYCLE = (
    REPO
    / "tmp"
    / "r80_factory_20261007"
    / "controller_diverse_sm_v1"
    / "cycles"
    / CYCLE_ID
    / "action_receipt.json"
)
SNAPSHOT = CYCLE.parent / "training_snapshot"
HEALTH = (
    REPO
    / "docs"
    / "log"
    / "assets"
    / "r80_health_20261011_0934.json"
)
INCREMENT = (
    REPO
    / "tmp"
    / "r80_increment_best_monitor_20261010_v001"
    / "increment_81fbb84a_20261011.json"
)
PRIOR_REVIEW = (
    REPO
    / "tmp"
    / "r80_sm_v032_physical_review_20261011_v001"
    / "physical_checks.json"
)
PRIOR_RECORD = REPO / "docs" / "log" / "assets" / "r80_sm_v032_physical_review_20261011.json"
PRIOR_CYCLES = {
    33: "51d8bc929ccdbfd491083d4a9f319381425bbbf819f7cfbe357fd36531d956c1",
    34: "a16c78a17771169da79cf167a4cfe7fc44097a1afd3c0dc4e86c980bbb15a1ac",
}
PRIOR_INCREMENTS = {
    33: REPO / "tmp" / "r80_increment_best_monitor_20261010_v001" / "increment_51d8bc92_20261011.json",
    34: REPO / "tmp" / "r80_increment_best_monitor_20261010_v001" / "increment_a16c78a1_20261011.json",
}
OUT = Path(__file__).with_name("physical_checks.json")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def tensor_digest(state: dict[str, torch.Tensor]) -> str:
    digest = hashlib.sha256()
    for name in sorted(state):
        tensor = state[name].detach().cpu().contiguous()
        digest.update(name.encode("utf-8"))
        digest.update(str(tensor.dtype).encode("ascii"))
        digest.update(json.dumps(list(tensor.shape)).encode("ascii"))
        digest.update(tensor.numpy().tobytes())
    return digest.hexdigest()


def aliases(row: dict) -> set[str]:
    return {str(row["lineage_id"]), str(row.get("canonical_group_id", row["lineage_id"]))}


def rel(path: Path) -> str:
    return str(path.relative_to(REPO)).replace("\\", "/")


def main() -> None:
    started = time.time()
    protocol_path = ROOT / "protocol.json"
    legacy_path = ROOT / "legacy" / "manifest.json"
    manifest_paths = {v: ROOT / "data" / f"data-v{v:03d}" / "manifest.json" for v in (32, 33, 34, 35)}
    receipt_paths = {v: ROOT / "data" / f"data-v{v:03d}" / "receipt.json" for v in (32, 33, 34, 35)}
    summary_path = ROOT / "models" / "data-v035" / "summary.json"
    member_paths = [ROOT / "models" / "data-v035" / f"member-{seed}.pt" for seed in (0, 1, 2)]
    prior_member0_path = ROOT / "models" / "data-v032" / "member-0.pt"
    snapshot_meta_paths = [SNAPSHOT / name for name in ("manifest.json", "results.json", "source_bindings.json")]
    prior_action_paths = {
        version: REPO / "tmp" / "r80_factory_20261007" / "controller_diverse_sm_v1" / "cycles" / cycle_id / "action_receipt.json"
        for version, cycle_id in PRIOR_CYCLES.items()
    }
    prior_snapshot_meta_paths = {
        version: [path.parent / "training_snapshot" / name for name in ("manifest.json", "results.json", "source_bindings.json")]
        for version, path in prior_action_paths.items()
    }
    source_paths = [REPO / "script" / "symmetry_training.py", REPO / "script" / "exploration.py"]
    bound_paths = [
        protocol_path,
        legacy_path,
        *manifest_paths.values(),
        *receipt_paths.values(),
        summary_path,
        *member_paths,
        prior_member0_path,
        CYCLE,
        HEALTH,
        INCREMENT,
        PRIOR_REVIEW,
        PRIOR_RECORD,
        *PRIOR_INCREMENTS.values(),
        *prior_action_paths.values(),
        *(path for paths in prior_snapshot_meta_paths.values() for path in paths),
        *snapshot_meta_paths,
        *source_paths,
    ]
    hashes_before = {rel(path): sha256(path) for path in bound_paths}

    protocol = read_json(protocol_path)
    legacy = read_json(legacy_path)
    rows = {v: read_json(path) for v, path in manifest_paths.items()}
    receipts = {v: read_json(path) for v, path in receipt_paths.items()}
    summary = read_json(summary_path)
    cycle = read_json(CYCLE)
    health = read_json(HEALTH)
    increment = read_json(INCREMENT)
    prior_review = read_json(PRIOR_REVIEW)
    prior_record = read_json(PRIOR_RECORD)
    prior_increments = {version: read_json(path) for version, path in PRIOR_INCREMENTS.items()}
    prior_actions = {version: read_json(path) for version, path in prior_action_paths.items()}
    snapshot_manifest = read_json(SNAPSHOT / "manifest.json")

    checks: dict[str, bool] = {}
    checks["prior_v032_physical_review_passed"] = (
        prior_review["status"] == "passed"
        and prior_review["failures"] == []
        and len(prior_review["checks"]) == 48
        and prior_record["status"] == "passed_bounded_saved_model_integrity_no_forward"
        and prior_record["physical_checks"]["status"] == "passed"
    )
    checks["prior_v032_norm_baseline_hash_exact"] = (
        hashes_before[rel(prior_member0_path)]
        == prior_review["hashes_after"][rel(prior_member0_path)]
    )
    checks["protocol_id_exact"] = (
        exploration.content_id({k: value for k, value in protocol.items() if k != "protocol_id"})
        == protocol["protocol_id"]
    )
    expected_receipts = {
        32: (4232, 88),
        33: (4283, 51),
        34: (4334, 51),
        35: (4403, 69),
    }
    for version in (32, 33, 34, 35):
        receipt = receipts[version]
        cumulative, new = expected_receipts[version]
        checks[f"v{version:03d}_manifest_id_exact"] = (
            exploration.content_id(rows[version]) == receipt["manifest_id"]
        )
        checks[f"v{version:03d}_receipt_counts_exact"] = (
            receipt["data_version"] == version
            and len(rows[version]) == receipt["cumulative_observations"] == cumulative
            and receipt["cumulative_valid_unique"] == cumulative
            and receipt["new_observations"] == receipt["new_valid_unique"] == new
        )

    indexed = {version: {row["id"]: row for row in manifest} for version, manifest in rows.items()}
    checks["all_manifest_ids_unique"] = all(len(indexed[v]) == len(rows[v]) for v in indexed)
    checks["v032_rows_semantically_frozen_through_v035"] = all(
        indexed[version].get(key) == value
        for version in (33, 34, 35)
        for key, value in indexed[32].items()
    )
    checks["successive_old_rows_semantically_frozen"] = all(
        indexed[newer].get(key) == value
        for older, newer in ((32, 33), (33, 34), (34, 35))
        for key, value in indexed[older].items()
    )
    version_deltas = {
        f"v{older:03d}_to_v{newer:03d}": sorted(set(indexed[newer]) - set(indexed[older]))
        for older, newer in ((32, 33), (33, 34), (34, 35))
    }
    delta32_35_ids = sorted(set(indexed[35]) - set(indexed[32]))
    checks["successive_delta_counts_exact"] = [len(value) for value in version_deltas.values()] == [51, 51, 69]
    checks["cumulative_v032_to_v035_delta_exact"] = (
        len(delta32_35_ids) == 171 and not (set(indexed[32]) - set(indexed[35]))
    )

    patterns = {version: {row["pattern_sha256"] for row in manifest} for version, manifest in rows.items()}
    added_patterns = {indexed[35][key]["pattern_sha256"] for key in delta32_35_ids}
    checks["all_v035_patterns_unique"] = len(patterns[35]) == len(rows[35])
    checks["cumulative_added_patterns_new_unique"] = (
        len(added_patterns) == 171 and not (added_patterns & patterns[32])
    )

    added_rows = [indexed[35][key] for key in delta32_35_ids]
    added_source_ids = {row["source_observation_id"] for row in added_rows}
    added_sample_files = {row["sample_file"] for row in added_rows}
    added_rad_files = {row["rad_file"] for row in added_rows}
    checks["added_raw_bindings_unique"] = (
        len(added_source_ids) == len(added_sample_files) == len(added_rad_files) == 171
    )
    checks["added_raw_names_match_declared_hashes"] = all(
        Path(row["sample_file"]).stem == row["source_sample_sha256"]
        and Path(row["rad_file"]).stem == row["source_rad_sha256"]
        for row in added_rows
    )
    checks["added_raw_files_exist"] = all(
        (ROOT / row["sample_file"]).is_file() and (ROOT / row["rad_file"]).is_file()
        for row in added_rows
    )
    checks["added_raw_file_hashes_exact"] = all(
        sha256(ROOT / row["sample_file"]) == row["source_sample_sha256"]
        and sha256(ROOT / row["rad_file"]) == row["source_rad_sha256"]
        for row in added_rows
    )

    train_rows = [row for row in rows[35] if row["split"] == "profile_train"]
    hold_rows = [row for row in rows[35] if row["split"] == "profile_holdout"]
    added_train = [row for row in added_rows if row["split"] == "profile_train"]
    added_hold = [row for row in added_rows if row["split"] == "profile_holdout"]
    train_aliases = set().union(*(aliases(row) for row in train_rows))
    hold_aliases = set().union(*(aliases(row) for row in hold_rows))
    train_patterns = {row["pattern_sha256"] for row in train_rows}
    hold_patterns = {row["pattern_sha256"] for row in hold_rows}
    checks["profile_train_holdout_alias_separated"] = not (train_aliases & hold_aliases)
    checks["profile_train_holdout_pattern_separated"] = not (train_patterns & hold_patterns)
    checks["profile_split_counts_exact"] = len(train_rows) == 3334 and len(hold_rows) == 1069
    checks["delta_split_counts_exact"] = len(added_train) == 148 and len(added_hold) == 23
    checks["summary_profile_ids_exact"] = (
        summary["profile_train_ids"] == [row["id"] for row in train_rows]
        and summary["profile_holdout_ids"] == [row["id"] for row in hold_rows]
    )

    legacy_train = [row for row in legacy if row["split"] == "legacy_train"]
    legacy_hold = [row for row in legacy if row["split"] == "legacy_holdout"]
    legacy_train_aliases = {str(row["lineage_id"]) for row in legacy_train}
    legacy_hold_aliases = {str(row["lineage_id"]) for row in legacy_hold}
    checks["legacy_train_holdout_family_separated"] = not (legacy_train_aliases & legacy_hold_aliases)
    current_hold_groups = (
        {str(row["canonical_group_id"]) for row in hold_rows}
        | {str(row["lineage_id"]) for row in hold_rows}
    )
    expected_legacy_exclusions = [
        row["id"]
        for row in legacy_train
        if row["pattern_sha256"] in hold_patterns or str(row["lineage_id"]) in current_hold_groups
    ]
    usable_legacy_count = len(legacy_train) - len(expected_legacy_exclusions)
    checks["legacy_current_holdout_exclusion_exact"] = (
        summary["legacy_train_exclusions_for_current_holdout"] == expected_legacy_exclusions
    )
    checks["summary_counts_exact"] = summary["counts"] == {
        "profile_train": len(train_rows),
        "profile_holdout": len(hold_rows),
        "legacy_train": usable_legacy_count,
        "legacy_holdout": len(legacy_hold),
    }

    expected_binding = {
        "measurement_id": protocol["measurement_id"],
        "score_spec_id": protocol["score_spec_id"],
        "protocol_id": protocol["protocol_id"],
        "data_version": 35,
        "manifest_id": receipts[35]["manifest_id"],
        "cumulative_valid_unique": receipts[35]["cumulative_valid_unique"],
    }
    checks["summary_binding_exact"] = summary["binding"] == expected_binding
    checks["summary_protocol_manifest_exact"] = (
        summary["protocol_id"] == protocol["protocol_id"]
        and summary["manifest_id"] == receipts[35]["manifest_id"]
        and summary["data_version"] == 35
    )
    checks["summary_member_seeds_exact"] = summary["member_seeds"] == [0, 1, 2]
    cycle_summary = cycle["trained_model_summary"]
    checks["cycle_completed_model_binding_exact"] = (
        cycle["cycle_id"] == CYCLE_ID
        and cycle["latest_data_version"] == 35
        and cycle["trained_this_cycle"] is True
        and cycle["new_unique_available_before_training"] == 69
        and cycle_summary["binding"] == expected_binding
        and cycle_summary["sha256"] == sha256(summary_path)
        and Path(cycle_summary["path"]).resolve() == summary_path.resolve()
        and cycle["predictor_binding"] == expected_binding
    )
    checks["health_completed_cycle_binding_exact"] = (
        health["latest_action_sha256"] == sha256(CYCLE)
        and health["latest_action_summary"]["cycle_id"] == CYCLE_ID
        and health["latest_action_summary"]["latest_data_version"] == 35
        and health["latest_action_summary"]["trained_this_cycle"] is True
        and health["latest_action_summary"]["new_unique_available_before_training"] == 69
        and health["latest_action_summary"]["valid_unique"] == cycle["valid_unique"] == 4420
        and health["reported_model_version"] == 35
        and health["latest_full_unique"] == 4363
        and health["reported_v035_is_not_new_physical_or_accuracy_audit"] is True
    )

    snapshot_hashes = {path.name: sha256(path) for path in snapshot_meta_paths}
    snapshot_patterns = {row["pattern_sha256"] for row in snapshot_manifest}
    v34_v35_patterns = {indexed[35][key]["pattern_sha256"] for key in version_deltas["v034_to_v035"]}
    checks["current_cycle_snapshot_metadata_exact"] = (
        cycle["training_snapshot"]["count"] == len(snapshot_manifest) == 69
        and cycle["training_snapshot"]["manifest_sha256"] == snapshot_hashes["manifest.json"]
        and cycle["training_snapshot"]["results_sha256"] == snapshot_hashes["results.json"]
        and cycle["training_snapshot"]["source_bindings_sha256"] == snapshot_hashes["source_bindings.json"]
        and snapshot_patterns == v34_v35_patterns
    )
    checks["existing_increment_replay_bound_without_raw_repeat"] = (
        increment["status"] == "passed_local_existing_increment_raw_replay"
        and increment["cycle_id"] == CYCLE_ID
        and increment["completed_cycle_receipt"]["sha256"] == sha256(CYCLE)
        and increment["existing_training_snapshot"]["count"] == 69
        and increment["existing_training_snapshot"]["hashes"] == snapshot_hashes
        and increment["raw_rows_replayed"] == 69
        and increment["positive_rows"] == 0
        and increment["increment_best"]["factory_margin_db"] == -4.656144618988037
        and increment["requires_full_census"] is False
    )
    prior_cycle_checks = []
    for version in (33, 34):
        action = prior_actions[version]
        prior_increment = prior_increments[version]
        meta_hashes = {path.name: sha256(path) for path in prior_snapshot_meta_paths[version]}
        delta_patterns = {
            indexed[version][key]["pattern_sha256"]
            for key in version_deltas[f"v{version - 1:03d}_to_v{version:03d}"]
        }
        prior_snapshot_manifest = read_json(prior_snapshot_meta_paths[version][0])
        prior_cycle_checks.append(
            action["cycle_id"] == PRIOR_CYCLES[version]
            and action["latest_data_version"] == version
            and action["trained_this_cycle"] is True
            and action["new_unique_available_before_training"] == 51
            and sha256(prior_action_paths[version]) == prior_increment["completed_cycle_receipt"]["sha256"]
            and prior_increment["status"] == "passed_local_existing_increment_raw_replay"
            and prior_increment["prospective_model_data_version"] == version
            and prior_increment["existing_training_snapshot"]["count"] == 51
            and prior_increment["existing_training_snapshot"]["hashes"] == meta_hashes
            and prior_increment["raw_rows_replayed"] == 51
            and prior_increment["positive_rows"] == 0
            and {row["pattern_sha256"] for row in prior_snapshot_manifest} == delta_patterns
        )
    checks["prior_v033_v034_increment_replays_bound_without_repeat"] = all(prior_cycle_checks)

    cfg = protocol["model"]
    expected_steps = (
        math.ceil(usable_legacy_count / cfg["batch_size"]) * cfg["legacy_epochs"]
        + math.ceil(len(train_rows) / cfg["batch_size"]) * cfg["current_epochs"]
    )
    member_results = []
    saved_checkpoints = []
    for seed, path, model_entry in zip((0, 1, 2), member_paths, summary["member_models"]):
        actual_hash = sha256(path)
        saved = torch.load(path, weights_only=False, map_location="cpu")
        saved_checkpoints.append(saved)
        expected_signature = exploration.content_id(
            {
                "protocol_id": protocol["protocol_id"],
                "manifest_id": receipts[35]["manifest_id"],
                "legacy_manifest_id": summary["legacy_manifest_id"],
                "member_seed": seed,
            }
        )
        optimizer = saved["optimizer_state"]
        steps = sorted({int(value["step"].item()) for value in optimizer["state"].values()})
        optimizer_finite = all(
            torch.isfinite(tensor).all().item()
            for value in optimizer["state"].values()
            for key, tensor in value.items()
            if key in {"exp_avg", "exp_avg_sq"}
        )
        model_finite = all(torch.isfinite(tensor).all().item() for tensor in saved["model_state"].values())
        member_results.append(
            {
                "member_seed": seed,
                "file_sha256": actual_hash,
                "summary_hash_match": model_entry == {"member_seed": seed, "file": path.name, "sha256": actual_hash},
                "signature": saved["signature"],
                "signature_match": saved["signature"] == expected_signature,
                "binding_match": saved["binding"] == expected_binding,
                "legacy_manifest_match": saved["legacy_manifest_id"] == summary["legacy_manifest_id"],
                "development_metadata_match": saved.get("development_training") == summary.get("development_training"),
                "complete": saved["complete"] is True,
                "fresh_initialization_metadata": saved["fresh_initialization"] is True,
                "phase_names": saved["phase_names"],
                "terminal_phase": int(saved["phase"]),
                "terminal_epoch": int(saved["epoch"]),
                "optimizer_steps": steps,
                "expected_optimizer_steps": expected_steps,
                "optimizer_steps_match": steps == [expected_steps],
                "optimizer_state_entries": len(optimizer["state"]),
                "optimizer_moments_finite": optimizer_finite,
                "model_tensor_count": len(saved["model_state"]),
                "model_tensors_finite": model_finite,
                "model_tensor_digest": tensor_digest(saved["model_state"]),
            }
        )

    checks["member_hashes_exact"] = all(row["summary_hash_match"] for row in member_results)
    checks["checkpoint_signatures_exact_unique"] = (
        all(row["signature_match"] for row in member_results)
        and len({row["signature"] for row in member_results}) == 3
    )
    checks["checkpoint_bindings_and_metadata_exact"] = all(
        row["binding_match"] and row["legacy_manifest_match"] and row["development_metadata_match"]
        for row in member_results
    )
    checks["checkpoint_complete_terminal_phases"] = all(
        row["complete"]
        and row["phase_names"] == ["legacy_pretrain", "current_profile"]
        and row["terminal_phase"] == 2
        and row["terminal_epoch"] == 0
        for row in member_results
    )
    checks["checkpoint_optimizer_steps_exact"] = all(row["optimizer_steps_match"] for row in member_results)
    checks["checkpoint_tensors_finite"] = all(
        row["optimizer_moments_finite"] and row["model_tensors_finite"] for row in member_results
    )
    checks["checkpoint_member_seeds_exact_distinct"] = (
        all(int(saved["member_seed"]) == seed for seed, saved in zip((0, 1, 2), saved_checkpoints))
        and len({row["model_tensor_digest"] for row in member_results}) == 3
    )
    checks["protocol_fresh_training_contract_exact"] = (
        cfg["legacy_epochs"] == 30
        and cfg["current_epochs"] == 100
        and protocol["policy"]["fresh_initialization_each_version"] is True
        and protocol["policy"]["early_stopping"] is False
        and all(saved["fresh_initialization"] is True for saved in saved_checkpoints)
    )

    checks["checkpoint_train_only_norm_identical_across_members"] = all(
        all(torch.equal(a, b) for a, b in zip(saved_checkpoints[0][name], saved[name]))
        for saved in saved_checkpoints[1:]
        for name in ("input_norm", "target_norm")
    )
    added_train_loaded = training._load_dataset(
        ROOT, added_rows, "profile_train", protocol["frequencies_ghz"]
    )
    old_checkpoint = torch.load(prior_member0_path, weights_only=False, map_location="cpu")
    incremental_norm_diffs: dict[str, dict[str, float]] = {}
    for name, added_tensor in (("input_norm", added_train_loaded[0]), ("target_norm", added_train_loaded[1])):
        old_mean, old_std = old_checkpoint[name]
        new_mean, new_std = saved_checkpoints[0][name]
        old_variance = torch.where(old_std == 1, torch.zeros_like(old_std), old_std.square())
        added_mean = added_tensor.mean(dim=0)
        added_variance = added_tensor.var(dim=0, unbiased=False)
        old_count = len([row for row in rows[32] if row["split"] == "profile_train"])
        added_count = len(added_train_loaded[2])
        combined_count = old_count + added_count
        combined_mean = (old_mean * old_count + added_mean * added_count) / combined_count
        combined_variance = (
            (old_variance + old_mean.square()) * old_count
            + (added_variance + added_mean.square()) * added_count
        ) / combined_count - combined_mean.square()
        combined_std = combined_variance.clamp_min(0).sqrt()
        combined_std[combined_std < 1e-6] = 1.0
        incremental_norm_diffs[name] = {
            "mean_max_abs_diff": float((combined_mean - new_mean).abs().max().item()),
            "std_max_abs_diff": float((combined_std - new_std).abs().max().item()),
        }
    checks["incremental_train_only_norm_reconstruction_float32_tolerance"] = (
        incremental_norm_diffs["input_norm"]["mean_max_abs_diff"] <= 1e-6
        and incremental_norm_diffs["input_norm"]["std_max_abs_diff"] <= 1e-6
        and incremental_norm_diffs["target_norm"]["mean_max_abs_diff"] <= 2e-6
        and incremental_norm_diffs["target_norm"]["std_max_abs_diff"] <= 1e-6
    )

    hashes_after = {rel(path): sha256(path) for path in bound_paths}
    checks["all_bound_bytes_unchanged_during_review"] = hashes_before == hashes_after
    failures = sorted(name for name, passed in checks.items() if not passed)
    result = {
        "schema_version": 1,
        "kind": "r80_sm_v035_saved_physical_checks_v001",
        "status": "passed" if not failures else "failed",
        "scope": "one bounded completed data-v032 to data-v035/model-v035 physical review; existing v033/v034/v035 increment replays are metadata-bound without repeating raw WM/radiation work; running v036 is excluded",
        "hashes_before": hashes_before,
        "hashes_after": hashes_after,
        "completed_cycle": {
            "cycle_id": cycle["cycle_id"],
            "action_receipt_sha256": sha256(CYCLE),
            "status": cycle["status"],
            "trained_this_cycle": cycle["trained_this_cycle"],
            "latest_data_version": cycle["latest_data_version"],
            "trained_model_summary_sha256": cycle_summary["sha256"],
            "fitted_model_cumulative_valid_unique": receipts[35]["cumulative_valid_unique"],
            "action_cutoff_valid_unique": cycle["valid_unique"],
            "health_recorded_utc": health["recorded_utc"],
            "latest_full_unique": health["latest_full_unique"],
            "latest_full_cutoff_taipei": health["latest_full_cutoff_taipei"],
        },
        "version_growth": {
            "v032_rows": len(rows[32]),
            "v033_rows": len(rows[33]),
            "v034_rows": len(rows[34]),
            "v035_rows": len(rows[35]),
            "versions_advanced": 3,
            "successive_new_rows": [51, 51, 69],
            "cumulative_new_rows": len(delta32_35_ids),
            "cumulative_new_patterns": len(added_patterns),
            "cumulative_new_profile_train": len(added_train),
            "cumulative_new_profile_holdout": len(added_hold),
        },
        "current_cycle_snapshot": {
            "count": len(snapshot_manifest),
            "metadata_hashes": snapshot_hashes,
            "patterns_equal_v034_to_v035_delta": snapshot_patterns == v34_v35_patterns,
            "existing_increment_replay_sha256": sha256(INCREMENT),
            "existing_increment_positive_rows": increment["positive_rows"],
            "existing_increment_best_factory_margin_db": increment["increment_best"]["factory_margin_db"],
            "raw_replayed_by_this_review": False,
        },
        "added_raw_bindings": {
            "source_observation_ids": len(added_source_ids),
            "sample_files": len(added_sample_files),
            "radiation_files": len(added_rad_files),
            "all_names_match_declared_hashes": checks["added_raw_names_match_declared_hashes"],
            "all_files_exist": checks["added_raw_files_exist"],
            "all_342_file_sha256_values_match_manifest": checks["added_raw_file_hashes_exact"],
        },
        "split_findings": {
            "profile_train": len(train_rows),
            "profile_holdout": len(hold_rows),
            "profile_train_aliases": len(train_aliases),
            "profile_holdout_aliases": len(hold_aliases),
            "alias_overlap": sorted(train_aliases & hold_aliases),
            "pattern_overlap_count": len(train_patterns & hold_patterns),
            "legacy_train": usable_legacy_count,
            "legacy_holdout": len(legacy_hold),
            "legacy_train_exclusions_for_current_holdout": len(expected_legacy_exclusions),
        },
        "training_contract": {
            "legacy_epochs": cfg["legacy_epochs"],
            "current_epochs": cfg["current_epochs"],
            "batch_size": cfg["batch_size"],
            "legacy_train_rows": usable_legacy_count,
            "current_train_rows": len(train_rows),
            "expected_optimizer_steps": expected_steps,
            "normalization_source": "saved norms are byte-identical across all three members; incremental reconstruction used the frozen v032 train-only norm plus only 148 newly added train rows",
            "incremental_norm_float32_max_abs_diffs": incremental_norm_diffs,
            "separate_per_epoch_log_present": False,
        },
        "members": member_results,
        "checks": checks,
        "failures": failures,
        "limits": [
            "No model was instantiated and no forward, inference, training, prediction, HFSS, NAS, process, dispatch, worker, queue, marker, source or runtime mutation was run.",
            "The prior v032 48-check audit was not rerun. Its saved receipt/main record and exact baseline checkpoint hash are bound, prior manifest rows are compared semantically, and only the 171 new v032-to-v035 sample/radiation pairs were freshly hashed.",
            "The v033/v034 51-row and v035 69-row raw WM/radiation replays were not repeated. This review binds their immutable actions, snapshot metadata and existing replay receipts; the v035 replay reported zero positive rows and best factory margin -4.656144618988037 dB.",
            "The train-only norms are byte-identical across all three v035 members. The incremental reconstruction from the saved v032 float32 aggregate plus only 148 new train rows is tolerance-based; unchanged raw rows were deliberately not reread.",
            "Fresh initialization is supported by protocol/checkpoint metadata, unique signatures and distinct terminal tensor digests. Initial pre-training tensor bytes are not saved and were not independently replayed.",
            "The 30+100 epoch history is supported by protocol, terminal phase metadata and exact Adam step tensors. No separate per-epoch log exists and no per-epoch history claim is made.",
            "Saved metrics/accuracy were not recomputed because that would require model forward inference. No model-quality, SM-improvement, causal-improvement or best-trigger claim is made.",
            "The descriptive development holdout is not an untouched independent validation set.",
            "The fitted v035 model binds 4,403 unique rows. The completed action reports 4,420 valid unique and the latest full receipt remains 4,363 at 07:44; neither is substituted into the fitted-model binding.",
            "Running v036 was not read, assessed or followed.",
        ],
        "elapsed_seconds": time.time() - started,
    }
    OUT.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"status": result["status"], "failures": failures, "check_count": len(checks), "elapsed_seconds": result["elapsed_seconds"]}, sort_keys=True))


if __name__ == "__main__":
    main()
