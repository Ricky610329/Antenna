Restore these files under tmp/r80_sm_v037_physical_review_20261011_v001 in the original Antenna repository.
Original v001 aggregate audit is FAILED 46/47 and unchanged. Separate exact_norm_v002 replay passes 11/11.
Only local training normalization was replayed; no model forward/training/WM replay/HFSS or live controller change.
Referenced immutable inputs/checkpoints and v035 baseline are hash-bound in receipts but are not included in this evidence ZIP.
