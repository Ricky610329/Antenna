from __future__ import annotations

import hashlib
import json
import sys
import time
from pathlib import Path

import torch


REPO = Path(__file__).resolve().parents[3]
if str(REPO) not in sys.path:
    sys.path.insert(0, str(REPO))

from script import exploration
from script import symmetry_training as training


ROOT = REPO / "tmp" / "r80_factory_20261007" / "training_familydev_v1"
V001 = Path(__file__).resolve().parent.parent
OUT = Path(__file__).with_name("receipt.json")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def rel(path: Path) -> str:
    return str(path.relative_to(REPO)).replace("\\", "/")


def tensor_sha256(tensor: torch.Tensor) -> str:
    value = tensor.detach().cpu().contiguous()
    digest = hashlib.sha256()
    digest.update(str(value.dtype).encode("ascii"))
    digest.update(json.dumps(list(value.shape)).encode("ascii"))
    digest.update(value.numpy().tobytes())
    return digest.hexdigest()


def main() -> None:
    started = time.time()
    protocol_path = ROOT / "protocol.json"
    manifest_path = ROOT / "data" / "data-v037" / "manifest.json"
    receipt_path = ROOT / "data" / "data-v037" / "receipt.json"
    summary_path = ROOT / "models" / "data-v037" / "summary.json"
    member_paths = [ROOT / "models" / "data-v037" / f"member-{seed}.pt" for seed in (0, 1, 2)]
    source_paths = [REPO / "script" / "symmetry_training.py", REPO / "script" / "exploration.py"]
    original_v001_paths = [
        V001 / "review_v037.py",
        V001 / "physical_checks.json",
        V001 / "version_diff.json",
        V001 / "independent_source_review.json",
    ]
    bound_paths = [
        *original_v001_paths,
        manifest_path,
        receipt_path,
        protocol_path,
        summary_path,
        *member_paths,
        *source_paths,
    ]
    hashes_before = {rel(path): sha256(path) for path in bound_paths}

    original = read_json(V001 / "physical_checks.json")
    manifest = read_json(manifest_path)
    receipt = read_json(receipt_path)
    protocol = read_json(protocol_path)
    summary = read_json(summary_path)
    train_rows = [row for row in manifest if row["split"] == "profile_train"]
    train_ids = [row["id"] for row in train_rows]
    sample_paths = [ROOT / row["sample_file"] for row in train_rows]
    rad_paths = [ROOT / row["rad_file"] for row in train_rows]

    checks: dict[str, bool] = {}
    checks["original_v001_failure_preserved_exact"] = (
        original["status"] == "failed"
        and original["failures"] == ["incremental_train_only_norm_reconstruction_float32_tolerance"]
        and len(original["checks"]) == 47
        and sum(bool(value) for value in original["checks"].values()) == 46
        and hashes_before[rel(V001 / "review_v037.py")]
        == "6b6ebae81b9af43900fec24f0452d1e0ac29df586742495a5f674f295e97ea05"
        and hashes_before[rel(V001 / "physical_checks.json")]
        == "06e6ea8e388e087e02bf6956271ab3df7a4c465df97fc72684c5c2d9115b3fb7"
        and hashes_before[rel(V001 / "version_diff.json")]
        == "021d8543695225645ac874bb44289b83694327ad80a09bcc294449c4c25156dd"
        and hashes_before[rel(V001 / "independent_source_review.json")]
        == "22f1efa8662fce69e923dc98f4c3881436a424c29dfed5574b5122f131dce6b0"
    )
    checks["v037_manifest_receipt_summary_binding_exact"] = (
        receipt["data_version"] == summary["data_version"] == 37
        and exploration.content_id(manifest) == receipt["manifest_id"] == summary["manifest_id"]
        and len(manifest) == receipt["cumulative_observations"] == receipt["cumulative_valid_unique"] == 4537
        and summary["binding"]["cumulative_valid_unique"] == 4537
    )
    checks["manifest_ordered_train_ids_exact_before_load"] = (
        len(train_rows) == 3451 and train_ids == summary["profile_train_ids"]
    )
    checks["train_payload_paths_unique_and_present"] = (
        len(set(sample_paths)) == len(set(rad_paths)) == len(train_rows)
        and all(path.is_file() for path in sample_paths)
        and all(path.is_file() for path in rad_paths)
    )

    # This is the single authorized full v037 profile_train load. The production
    # loader hashes each sample/radiation input against the manifest before _target.
    x, y, kept = training._load_dataset(
        ROOT, manifest, "profile_train", protocol["frequencies_ghz"]
    )
    kept_ids = [row["id"] for row in kept]
    checks["production_loader_retained_exact_ordered_train_ids"] = (
        len(kept) == 3451 and kept_ids == train_ids == summary["profile_train_ids"]
    )
    checks["production_loader_train_only_shapes_exact"] = (
        x.shape == (3451, 625)
        and y.shape[0] == 3451
        and all(row["split"] == "profile_train" for row in kept)
    )

    input_norm = exploration._fit_norm(x)
    target_norm = exploration._fit_norm(y)
    computed = {
        "input_mean": input_norm[0],
        "input_std": input_norm[1],
        "target_mean": target_norm[0],
        "target_std": target_norm[1],
    }

    saved_members = [torch.load(path, weights_only=False, map_location="cpu") for path in member_paths]
    saved_by_member = []
    all_equal = True
    max_abs_diffs: dict[str, list[float]] = {name: [] for name in computed}
    for seed, saved in enumerate(saved_members):
        saved_norms = {
            "input_mean": saved["input_norm"][0],
            "input_std": saved["input_norm"][1],
            "target_mean": saved["target_norm"][0],
            "target_std": saved["target_norm"][1],
        }
        comparisons = {}
        for name, value in computed.items():
            expected = saved_norms[name]
            equal = torch.equal(value, expected)
            all_equal = all_equal and equal
            max_diff = float((value - expected).abs().max().item())
            max_abs_diffs[name].append(max_diff)
            comparisons[name] = {
                "byte_exact": equal,
                "computed_sha256": tensor_sha256(value),
                "saved_sha256": tensor_sha256(expected),
                "max_abs_diff": max_diff,
                "dtype": str(value.dtype),
                "shape": list(value.shape),
            }
        saved_by_member.append({"member_seed": seed, "comparisons": comparisons})

    checks["computed_norm_tensors_finite"] = all(torch.isfinite(value).all().item() for value in computed.values())
    checks["saved_norm_tensors_byte_identical_across_members"] = all(
        torch.equal(saved_members[0][norm_name][index], saved[norm_name][index])
        for saved in saved_members[1:]
        for norm_name in ("input_norm", "target_norm")
        for index in (0, 1)
    )
    checks["computed_four_norm_tensors_byte_exact_all_three_members"] = all_equal
    checks["checkpoint_files_match_v037_summary"] = all(
        summary["member_models"][seed]
        == {"member_seed": seed, "file": path.name, "sha256": hashes_before[rel(path)]}
        for seed, path in enumerate(member_paths)
    )

    hashes_after = {rel(path): sha256(path) for path in bound_paths}
    checks["all_bound_v001_inputs_sources_and_checkpoints_unchanged"] = hashes_before == hashes_after
    failures = sorted(name for name, passed in checks.items() if not passed)
    elapsed = time.time() - started
    result = {
        "schema_version": 1,
        "kind": "r80_sm_v037_exact_full_train_norm_replay_v002",
        "status": "passed_exact_full_train_norm_replay" if not failures else "failed_exact_full_train_norm_replay",
        "scope": "one authorized local full profile_train normalization replay for data-v037 solely to resolve the v001 aggregate-reconstruction tolerance failure",
        "helper_sha256": sha256(Path(__file__)),
        "elapsed_seconds": elapsed,
        "rows": {
            "manifest_total": len(manifest),
            "profile_train_loaded_once": len(kept),
            "profile_holdout_raw_loaded": 0,
            "legacy_raw_loaded": 0,
        },
        "payload_read_scope": {
            "sample_files_verified_by_production_loader": len(sample_paths),
            "radiation_files_verified_by_production_loader": len(rad_paths),
            "sample_bytes": sum(path.stat().st_size for path in sample_paths),
            "radiation_bytes": sum(path.stat().st_size for path in rad_paths),
            "total_payload_bytes": sum(path.stat().st_size for path in sample_paths + rad_paths),
            "hash_contract": "production _load_dataset SHA-256 verified every selected sample/radiation file against source_sample_sha256/source_rad_sha256 before tensor construction",
        },
        "computed_norm_sha256": {name: tensor_sha256(value) for name, value in computed.items()},
        "member_comparisons": saved_by_member,
        "max_abs_diffs_across_members": {
            name: max(values) for name, values in max_abs_diffs.items()
        },
        "checks": checks,
        "failures": failures,
        "hashes_before": hashes_before,
        "hashes_after": hashes_after,
        "original_v001_result_retained": {
            "status": original["status"],
            "check_count": len(original["checks"]),
            "passed_check_count": sum(bool(value) for value in original["checks"].values()),
            "failures": original["failures"],
            "aggregate_target_std_max_abs_diff": original["training_contract"]["incremental_norm_float32_max_abs_diffs"]["target_norm"]["std_max_abs_diff"],
            "aggregate_target_std_fixed_limit": 1e-6,
        },
        "limits": [
            "This v002 replay broadens raw reads only to all 3,451 v037 profile_train rows and only for normalization resolution; no holdout or legacy payload was loaded.",
            "The original v001 46/47 failed result, helper and evidence files remain unchanged. Its fixed tolerance was not altered and its checks were not rerun.",
            "No model was constructed and no forward, inference, training, prediction, saved metric, WM/radiation metric replay, HFSS, NAS, process, controller, queue, marker, runtime mutation or v038 read was performed.",
            "Exact equality establishes that the saved v037 norms equal a fresh full profile_train replay under the current reviewed source and local torch environment. It is not an accuracy, performance, model-quality or causal-improvement claim.",
        ],
    }
    OUT.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({
        "status": result["status"],
        "check_count": len(checks),
        "failures": failures,
        "elapsed_seconds": elapsed,
        "profile_train_loaded": len(kept),
    }, sort_keys=True))


if __name__ == "__main__":
    main()
