import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path
here=Path(__file__).resolve().parent
root=here.parents[1]
h=json.loads((root/'tmp/r80_restored_health_20261010_v005/health_restored_20261011_2104.json').read_text(encoding='utf-8-sig'))
settings=json.loads(Path(h['settings']['path']).read_text(encoding='utf-8-sig'))
dataset=Path(settings['dataset_root'])
names=re.findall(r'job (\S+):',h['scoped_status_output'])
assert len(names)==3 and set(names)=={'dedust_r80ka00bff601d27501e','dedust_r80k602e7baa8e550c66','dedust_r80kfb8a72d1023de13e'}
for prior in ('dedust_r80k602e7baa8e550c66', 'dedust_r80kfb8a72d1023de13e', 'dedust_r80c473b6738g01', 'dedust_r80k29f5fb1609aa6d22'):
    if prior not in names: names.append(prior)
rows=[]
for name in names:
    assert name.startswith('dedust_r80') and '/' not in name and '\\' not in name
    markers={}
    for suffix in ('claim','done','fail'):
        path=dataset/'jobs_state'/(name+'.'+suffix)
        item={'exists':path.is_file()}
        if item['exists']:
            raw=path.read_bytes()
            item.update(sha256=hashlib.sha256(raw).hexdigest(),payload=json.loads(raw),
                        modified_utc=datetime.fromtimestamp(path.stat().st_mtime,timezone.utc).isoformat())
        markers[suffix]=item
    path=dataset/name/'results.json'
    raw=path.read_bytes() if path.is_file() else b'{}'
    results=json.loads(raw)
    rows.append(dict(store=name,markers=markers,results_exists=path.is_file(),results_sha256=hashlib.sha256(raw).hexdigest() if path.is_file() else None,
                     results_modified_utc=datetime.fromtimestamp(path.stat().st_mtime,timezone.utc).isoformat() if path.is_file() else None,
                     successful_entries=sum(e.get('status')=='ok' and 'error' not in e for e in results.values()),
                     error_entries=[dict(id=k,entry=v) for k,v in results.items() if 'error' in v]))
record=dict(observed_utc=datetime.now(timezone.utc).isoformat(),read_only=True,stores=rows,
            limits=['Sequential marker/result cutoffs; later progress excluded.',
                    'Claim identity plus recent saved results is not remote worker process verification.',
                    'No raw metric replay or failure recovery assertion.'])
with (here/'active_owner_readback.json').open('x',encoding='utf-8') as f:f.write(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(json.dumps([dict(store=r['store'],owner=r['markers']['claim'].get('payload',{}).get('machine'),
                       fail=r['markers']['fail']['exists'],success=r['successful_entries'],errors=len(r['error_entries'])) for r in rows],ensure_ascii=False))
