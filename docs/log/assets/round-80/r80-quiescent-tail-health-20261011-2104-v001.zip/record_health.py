"""Local evidence-only recorder; never dispatch, train, alter markers, or signal jobs."""
import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from script.symmetry_factory_cycle import _terminal_fail

ROOT=Path(__file__).resolve().parents[2]
def read(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
parser=argparse.ArgumentParser()
parser.add_argument('--stamp',required=True)
parser.add_argument('--previous',required=True)
parser.add_argument('--owners',required=True,type=Path)
parser.add_argument('--next',required=True)
parser.add_argument('--timer',required=True)
parser.add_argument('--increment',type=Path)
args=parser.parse_args()
assert args.stamp.startswith('20261011_') and len(args.stamp)==13
label=args.stamp[-4:-2]+':'+args.stamp[-2:]
hp=ROOT/'tmp/r80_restored_health_20261010_v005'/('health_restored_'+args.stamp+'.json')
h=read(hp)
assert h['process']['pid']==53228 and h['process']['creation_unix_ms']==1791602636766
assert h['process_matches_restoration_receipt'] and h['watcher_inventory_exact'] and h['runtime_file_bindings_verified']==19
previous_path=ROOT/'docs/log/assets'/('r80_health_'+args.previous+'.json')
previous=read(previous_path)
owners=read(args.owners)
lookup={row['store']:row for row in owners['stores']}
active=[row for row in owners['stores'] if row['markers']['claim']['exists'] and not row['markers']['done']['exists'] and not row['markers']['fail']['exists']]
guard_action_path=Path(h['watch_status']['last_receipt'])
assert sha(guard_action_path)==h['watch_status']['last_receipt_sha256']
guard_action=read(guard_action_path)
roster={'140.123.106.216','140.123.106.218','140.123.106.37'}
owners_now=[row['markers']['claim']['payload']['machine'] for row in active]
assert len(set(owners_now))==len(owners_now) and set(owners_now)<=roster
quota_tail_job_counts=dict(previous.get('quota_tail_job_counts',{}))
tail_jobs=guard_action.get('planned_jobs',[])
tail_capacity_bound=bool(tail_jobs) and all(job.get('final_target_tail') is True and 0<job['count']<16 for job in tail_jobs)
if tail_capacity_bound:
    assert guard_action['valid_unique']+guard_action['pending_unique']+sum(job['count'] for job in tail_jobs)==5000
    for job in tail_jobs:
        rows=read(Path(job['staged_input'])/'manifest.json')
        assert len(rows)==job['count']
        quota_tail_job_counts[job['store']]=job['count']
tail_quiescent=False
if not active:
    assert tail_capacity_bound and h['watch_status']['status']=='running_cycle'
    incomplete=[row for row in owners['stores'] if not row['markers']['done']['exists']]
    assert incomplete and all(row['markers']['fail']['exists'] and _terminal_fail(row['markers']['fail']['payload'],tuple(sorted(roster))) for row in incomplete)
    assert all(lookup[job['store']]['markers']['done']['exists'] and lookup[job['store']]['successful_entries']==job['count'] and not lookup[job['store']]['error_entries'] for job in tail_jobs)
    tail_quiescent=True
elif len(active)!=3:
    assert 1<=len(active)<3 and tail_capacity_bound, 'Reduced active count requires an actual capacity-bound final tail'
else:
    assert set(owners_now)==roster
old_lookup={row['store']:row for row in previous['owner_readback']['stores']}
low=lookup['dedust_r80ka00bff601d27501e']
assert low['results_sha256']==old_lookup[low['store']]['results_sha256']
assert low['markers']['fail']['sha256']==old_lookup[low['store']]['markers']['fail']['sha256']
full_path=ROOT/'docs/log/assets/r80_best_status_20261011_0744.json'
full=read(full_path)
dataset=Path(read(Path(h['settings']['path']))['dataset_root'])
recovered=[]
completed=[]
for name,row in lookup.items():
    old=old_lookup.get(name)
    if old and not old['markers']['done']['exists'] and row['markers']['done']['exists']:
        assert row['successful_entries']==quota_tail_job_counts.get(name,16) and not row['error_entries'] and not row['markers']['fail']['exists']
        completed.append(name)
        if old['error_entries']:
            rp=dataset/name/'results.json'
            assert sha(rp)==row['results_sha256']
            results=read(rp)
            for error in old['error_entries']:
                entry=results[error['id']]
                assert entry['status']=='ok' and 'error' not in entry
                assert entry['measurement_id']==full['measurement_id'] and entry['score_spec_id']==full['score_spec_id']
                recovered.append(dict(store=name,id=error['id'],entry=entry,results_sha256=row['results_sha256']))
            assert sha(rp)==row['results_sha256']
ap=Path(h['watch_status']['last_receipt'])
assert sha(ap)==h['watch_status']['last_receipt_sha256']
action=read(ap)
changed=sha(ap)!=previous['latest_action_sha256']
increment=None
if changed and action.get('training_snapshot'):
    assert args.increment is not None
    increment=read(args.increment)
    assert increment['cycle_id']==action['cycle_id'] and increment['completed_cycle_receipt']['sha256']==sha(ap)
    assert increment['raw_rows_replayed']==action['training_snapshot']['count']
    assert increment['reference']['sha256']==sha(full_path)
    assert increment['requires_full_census'] is False, 'Resolve new-best trigger with a full census before recording routine status'
    for name,digest in increment['existing_training_snapshot']['hashes'].items():
        assert sha(Path(increment['existing_training_snapshot']['path'])/name)==digest
else:
    assert args.increment is None, 'Do not repeat or substitute an old raw increment'
physical_path=ROOT/'docs/log/assets/r80_sm_v037_physical_review_20261011.json'
assert read(physical_path)['status']=='passed_saved_model_integrity_with_exact_norm_resolution'
errors=[dict(store=row['store'],error=error) for row in active for error in row['error_entries']]
record=dict(schema_version=1,recorded_utc=datetime.now(timezone.utc).isoformat(),
    status='routine_health_passed_with_saved_progress_and_native_retry_evidence',
    recorder_sha256=sha(Path(__file__)),health=h,health_sha256=sha(hp),
    owner_readback=owners,owner_readback_sha256=sha(args.owners),
    active_owners=owners_now,remote_worker_liveness_not_asserted=True,
    capacity_bound_final_tail=tail_capacity_bound,quota_tail_job_counts=quota_tail_job_counts,
    tail_quiescent_with_running_controller_and_exhausted_rosters=tail_quiescent,
    previous_health=str(previous_path.relative_to(ROOT)),previous_health_sha256=sha(previous_path),
    newly_completed_previous_stores=completed,recovered_sample_metadata=recovered,
    pending_native_sample_retries=errors,old_terminal_low_results_and_fail_hashes_unchanged=True,
    latest_action_sha256=sha(ap),latest_action_summary={key:action[key] for key in
        ['cycle_id','latest_data_version','valid_unique','pending_unique','trained_this_cycle','training_snapshot']},
    latest_completed_action_changed=changed,new_completed_increment=increment,
    new_completed_increment_sha256=sha(args.increment) if increment else None,
    reported_model_version=action['latest_data_version'],reported_model_is_not_new_physical_or_accuracy_audit=True,
    latest_physical_model_version=37,latest_physical_model_fit_unique=4537,
    latest_physical_model_receipt=str(physical_path.relative_to(ROOT)),latest_physical_model_receipt_sha256=sha(physical_path),
    latest_full_receipt=str(full_path.relative_to(ROOT)),latest_full_receipt_sha256=sha(full_path),latest_full_unique=4363,
    latest_full_cutoff_taipei='2026-10-11 07:44',next_routine_taipei='2026-10-11 '+args.next,notify_only_cell_id=args.timer,
    full_census_performed=False,model_load_forward_or_training_performed=False,runtime_queue_or_marker_mutation=False,
    worker_or_controller_restart=False,
    limits=['Sequential health/owner cutoffs; claims and saved results are not remote PID proof.',
            'Recovered samples are success metadata/MID-SID/native done evidence, not repeated raw curve replay.',
            'Current sample errors without done/fail stay in native retry; no terminal or recovery assertion.',
            'Reported model/action counts, physical fit4537 and full4363 have distinct scopes.',
            'Running fragments are excluded from completed-model claims; no accuracy or causal improvement claim.'])
target=ROOT/'docs/log/assets'/('r80_health_'+args.stamp+'.json')
assert not target.exists()
ordered=sorted(active,key=lambda row:row['markers']['claim']['payload']['machine'])
details='；'.join(row['markers']['claim']['payload']['machine'].rsplit('.',1)[1]+' '+row['store'].removeprefix('dedust_r80')+'成功'+str(row['successful_entries']) for row in ordered)
note='**10/11 '+label+'例行健康**：原main身分／唯一inventory／19來源吻合；'+details+'。'
if completed: note+='前次'+str(len(completed))+'批成功done無error/fail，逐批成功数='+','.join(str(lookup[name]['successful_entries']) for name in completed)+'。'
if recovered: note+=str(len(recovered))+'個先前失敗樣本已保存status=ok／MID-SID吻合，僅metadata核對，未重播整批raw。'
if errors: note+='當前'+str(len(errors))+'筆樣本失敗仍無done/fail，留原生補測，不報終態。'
else: note+='當前'+str(len(active))+'個active批次無error。'
if tail_quiescent: note+='當前無active claim，已派尾批完成且未done批次的三機roster全耗盡；main正在running_cycle，正式計數與補額尚待完成。'
elif len(active)<3: note+='已進入容量受限尾批，未認領工作的機器不據此判定停機。'
note+=('新completed ' if changed else 'Completed仍')+action['cycle_id'][:8]+'／v'+str(action['latest_data_version'])+'／'+str(action['valid_unique'])+'；'
if increment:
    note+='只重播新'+str(increment['raw_rows_replayed'])+'本機raw，'+str(increment['positive_rows'])+'正WM、best'+str(increment['increment_best']['factory_margin_db'])+'，未觸發新full。'
else: note+='無新increment重播，running fragments不算新completed model。'
note+='Physicalv037 fit4537／latest full07:44的4363分開，reported model更新不是accuracy或性能提升；舊LOW終態SHA不變。下一例行**'+args.next+'**、notify-only cell'+args.timer+'；無runtime／queue／markers或worker重啟變更。'
board=ROOT/'configs/ONGOING.md'
lines=board.read_text(encoding='utf-8').splitlines(keepends=True)
matches=[i for i,line in enumerate(lines) if line.startswith('- **10/11 ') and '例行健康**' in line]
assert len(matches)==1
lines[matches[0]]='- '+note+' [健康與增量證據](../docs/log/assets/'+target.name+')。\n'
log=ROOT/'docs/log/round-80-symmetry-exploration.md'
parts=log.read_text(encoding='utf-8').split('\n\n',2)
assert parts[1].startswith('最新狀態（2026-10-11 ')
new=('最新狀態（2026-10-11 '+label+'健康；全量仍07:44）：4,363／5,000有效唯一實測（87.26%），尚差637，WM最佳+.0216822624dB仍屬07:44全量切點。'+note+
    ' [本次證據](assets/'+target.name+')／[最新全量](assets/r80_best_status_20261011_0744.json)。資料成長但最佳性能停滯；validated5000即R81備料、R80統計圖表同步。新濾波器不限制對稱。以下切點、PID與timer是歷史，當前以本段及[live板](../../configs/ONGOING.md)為準。')
with target.open('x',encoding='utf-8') as handle:handle.write(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
board.write_text(''.join(lines),encoding='utf-8')
log.write_text(parts[0]+'\n\n'+new+'\n\n歷史開篇（'+label+'取代操作狀態，全量cutoff不變）：'+parts[1]+'\n\n'+parts[2],encoding='utf-8')
print(json.dumps({'record':str(target.relative_to(ROOT)),'sha256':sha(target),'recovered_metadata':len(recovered),'new_raw':increment['raw_rows_replayed'] if increment else 0,'next':args.next},ensure_ascii=False))
