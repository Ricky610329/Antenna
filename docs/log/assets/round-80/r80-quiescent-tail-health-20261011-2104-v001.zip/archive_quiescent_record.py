import hashlib
import json
import zipfile
from pathlib import Path
from script.symmetry_factory_cycle import _terminal_fail

root=Path(__file__).resolve().parents[2]
path=root/'docs/log/assets/r80_health_20261011_2104.json'
record=json.loads(path.read_text(encoding='utf-8'))
partial=next(row for row in record['owner_readback']['stores'] if row['store']=='dedust_r80kfb8a72d1023de13e')
roster=('140.123.106.216','140.123.106.218','140.123.106.37')
assert record['tail_quiescent_with_running_controller_and_exhausted_rosters'] is True
assert _terminal_fail(partial['markers']['fail']['payload'],roster) is True
assert partial['successful_entries']==14 and len(partial['error_entries'])==2
assert all(e['entry']['attempts']==5 for e in partial['error_entries'])
assert partial['markers']['fail']['payload']['worker_continues'] is True
record['newly_exhausted_partial_metadata']={
    'store':partial['store'],'successful_metadata_entries':14,
    'failed_ids':[e['id'] for e in partial['error_entries']],
    'attempts_each':5,'native_terminal_fail':True,'remaining_eligible_workers':[],
    'worker_continues':True,'raw_curve_or_WM_replay_performed':False,
    'limits':'No geometry-cause conclusion, remote PID proof, or current full-census count.'}
files=[root/'tmp/r80_health_recorder_20261011_v004/record_health.py',
       Path(__file__).with_name('prepare_quiescent_recorder.py'),
       Path(__file__).with_name('prepare_terminal_observer.py'),
       Path(__file__).with_name('read_tail_owners.py'),Path(__file__)]
payloads={p.name:p.read_bytes() for p in files}
payloads['README.txt']=('21:04 local evidence formatting only. No runtime/worker/NAS changes.\n'
    'Zero active claims require a live bound controller running_cycle, an immutable capacity-bound short-tail action, '
    'all tail jobs complete with exact expected counts, and all non-done observed stores exhausting the exact native roster.\n'
    'Source references remain repo/tmp paths. Marker metadata is not remote process or raw-curve proof.\n').encode()
manifest={name:{'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()} for name,raw in payloads.items()}
archive=root/'docs/log/assets/round-80/r80-quiescent-tail-health-20261011-2104-v001.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for name,raw in payloads.items():z.writestr(name,raw)
    z.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and all(z.read(name)==raw for name,raw in payloads.items())
record['local_quiescent_recorder_archive']={'path':str(archive.relative_to(root)).replace('\\','/'),
    'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
    'payloads':manifest,'verification':'CRC and exact source bytes passed',
    'scope':'local record formatter, actual saved metadata assertions only'}
path.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
paragraph='**21:04尾批完成、最後partial耗盡**：c473b6738g01的10筆已全數done；kfb8a72d1023de13e由218接手後兩筆仍為COM錯誤、各attempts=5，fail roster現含37／216／218，原生_terminal_fail=true，保留14成功與全部markers，worker_continues=true。保存切點無active claim，main身分與19來源仍吻合且running_cycle；等待原生下一輪正式計數／補額，不把無claim當成已達5000，也不聲稱三台PID皆存活。'
for filename,needle,link in [('configs/ONGOING.md','- **20:34容量尾批與partial**','../docs/log/assets/r80_health_20261011_2104.json'),
                           ('docs/log/round-80-symmetry-exploration.md','**20:34容量尾批與partial**','assets/r80_health_20261011_2104.json')]:
    p=root/filename
    text=p.read_text(encoding='utf-8')
    assert text.count(needle)==1
    insertion=('- ' if filename.startswith('configs/') else '')+paragraph+' [實際metadata與紀錄器]('+link+')。\n\n'
    text=text.replace(needle,insertion+needle,1).replace('19來源吻合；。前次1批成功done','19來源吻合。前次1批成功done')
    p.write_text(text,encoding='utf-8')
print(json.dumps({'archive_bytes':archive.stat().st_size,'record_sha256':hashlib.sha256(path.read_bytes()).hexdigest()},ensure_ascii=False))
