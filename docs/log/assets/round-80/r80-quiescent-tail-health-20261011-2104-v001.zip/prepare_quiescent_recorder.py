"""Preserve prior recorder; admit only the observed exhausted-roster tail phase."""
from pathlib import Path
root=Path(__file__).resolve().parents[2]
text=(root/'tmp/r80_health_recorder_20261011_v003/record_health.py').read_text(encoding='utf-8')
text=text.replace('from pathlib import Path','from pathlib import Path\nfrom script.symmetry_factory_cycle import _terminal_fail',1)
old="""if len(active)!=3:
    assert 1<=len(active)<3 and tail_capacity_bound, 'Reduced active count requires an actual capacity-bound final tail'
else:
    assert set(owners_now)==roster"""
new="""tail_quiescent=False
if not active:
    assert tail_capacity_bound and h['watch_status']['status']=='running_cycle'
    incomplete=[row for row in owners['stores'] if not row['markers']['done']['exists']]
    assert incomplete and all(row['markers']['fail']['exists'] and _terminal_fail(row['markers']['fail']['payload'],tuple(sorted(roster))) for row in incomplete)
    assert all(lookup[job['store']]['markers']['done']['exists'] and lookup[job['store']]['successful_entries']==job['count'] and not lookup[job['store']]['error_entries'] for job in tail_jobs)
    tail_quiescent=True
elif len(active)!=3:
    assert 1<=len(active)<3 and tail_capacity_bound, 'Reduced active count requires an actual capacity-bound final tail'
else:
    assert set(owners_now)==roster"""
assert text.count(old)==1
text=text.replace(old,new,1)
text=text.replace("capacity_bound_final_tail=tail_capacity_bound,quota_tail_job_counts=quota_tail_job_counts,", "capacity_bound_final_tail=tail_capacity_bound,quota_tail_job_counts=quota_tail_job_counts,\n    tail_quiescent_with_running_controller_and_exhausted_rosters=tail_quiescent,",1)
text=text.replace("if len(active)<3: note+='已進入容量受限尾批，未認領工作的機器不據此判定停機。'", "if tail_quiescent: note+='當前無active claim，已派尾批完成且未done批次的三機roster全耗盡；main正在running_cycle，正式計數與補額尚待完成。'\nelif len(active)<3: note+='已進入容量受限尾批，未認領工作的機器不據此判定停機。'",1)
destination=root/'tmp/r80_health_recorder_20261011_v004'
destination.mkdir()
with (destination/'record_health.py').open('x',encoding='utf-8') as handle:handle.write(text)
print(destination/'record_health.py')
