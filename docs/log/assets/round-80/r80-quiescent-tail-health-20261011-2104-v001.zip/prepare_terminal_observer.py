from pathlib import Path
path=Path(__file__).with_name('read_active_owners.py')
text=path.read_text(encoding='utf-8')
old='assert len(names)>=4 and len(set(names))==len(names)'
new="assert len(names)==3 and set(names)=={'dedust_r80ka00bff601d27501e','dedust_r80k602e7baa8e550c66','dedust_r80kfb8a72d1023de13e'}"
assert text.count(old)==1
with path.with_name('read_tail_owners.py').open('x',encoding='utf-8') as handle:
    handle.write(text.replace(old,new,1))
