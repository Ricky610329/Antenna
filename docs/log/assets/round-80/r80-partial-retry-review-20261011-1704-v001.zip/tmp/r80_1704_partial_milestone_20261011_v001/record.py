"""Archive already-completed read-only evidence; never re-run the verifier."""
import hashlib
import json
import zipfile
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
REVIEW = ROOT / 'tmp/r80_1704_partial_review_20261011_v001'
HEALTH = ROOT / 'docs/log/assets/r80_health_20261011_1704.json'
TARGET = ROOT / 'docs/log/assets/r80_partial_retry_review_20261011_1704.json'
ARCHIVE = ROOT / 'docs/log/assets/round-80/r80-partial-retry-review-20261011-1704-v001.zip'

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

receipt_raw = (REVIEW / 'partial_verification.json').read_bytes()
helper_raw = (REVIEW / 'verify_partial.py').read_bytes()
assert sha(receipt_raw) == '89654b8294217a0681f6d4b0209970dbdf5e9125e81106211753ed52f308e54b'
assert sha(helper_raw) == '82e41773bbd46a3e28075616f478d06d0ce7ec28802d2833cd36fbb91a3a16bc'
r = json.loads(receipt_raw)
h = json.loads(HEALTH.read_bytes())
assert r['status'] == 'passed_existing_partial_profile_verifier_nonterminal_exact_roster'
assert len(r['checks']) == 11 and all(r['checks'].values()) and not r['failures']
assert r['saved_health']['sha256'] == h['health_sha256']
assert r['saved_owner_readback']['sha256'] == h['owner_readback_sha256']
assert r['native_partial_verification']['called_once'] is True
assert r['native_partial_verification']['successful'] == 15
assert r['native_partial_verification']['terminal_errors'] == 1
assert r['native_partial_verification']['result']['error_ids'] == ['r80kl03_e19d31436041']
assert r['mutable_before'] == r['mutable_after']
assert r['immutable_hashes_before'] == r['immutable_hashes_after']
assert r['retry_interpretation']['terminal_roster_failure'] is False
assert r['retry_interpretation']['still_eligible_workers_by_rule'] == ['140.123.106.218', '140.123.106.37']
assert r['retry_interpretation']['eligibility_is_actual_takeover'] is False
assert not TARGET.exists() and not ARCHIVE.exists()
payload = {
    'tmp/r80_1704_partial_review_20261011_v001/verify_partial.py': helper_raw,
    'tmp/r80_1704_partial_review_20261011_v001/partial_verification.json': receipt_raw,
    'tmp/r80_1704_partial_milestone_20261011_v001/record.py': Path(__file__).read_bytes(),
    'README.txt': (
        'Restore tmp/ members at their original repository-relative paths.\n'
        'Evidence only: native partial verifier ran once; 15 successes, 1 failed sample.\n'
        'Eligible 218/37 means rule eligibility, not actual takeover.\n'
        'Referenced NAS inputs, curves, models and controller receipts are not included.\n'
        'Do not re-run against a changed live store or modify claims/fail/done.\n'
    ).encode('utf-8'),
}
manifest = {name: {'sha256': sha(raw), 'bytes': len(raw)} for name, raw in payload.items()}
payload['manifest.json'] = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode('utf-8')
with zipfile.ZipFile(ARCHIVE, 'x', zipfile.ZIP_DEFLATED) as z:
    for name, raw in payload.items():
        z.writestr(name, raw)
with zipfile.ZipFile(ARCHIVE) as z:
    assert z.testzip() is None and set(z.namelist()) == set(payload)
    for name, raw in payload.items():
        assert z.read(name) == raw
record = dict(
    schema_version=1,
    status='reviewed_saved_partial_integrity_and_nonterminal_retry_eligibility',
    recorded_utc=datetime.now(timezone.utc).isoformat(),
    health_receipt=str(HEALTH.relative_to(ROOT)).replace('\\', '/'),
    health_receipt_sha256=sha(HEALTH.read_bytes()),
    review_receipt_sha256=sha(receipt_raw),
    partial_review=r,
    conductor_review='Reviewed complete helper, native single-call receipt, exact state/source bindings and all 11 checks; no duplicate verifier or WM replay.',
    archive=dict(path=str(ARCHIVE.relative_to(ROOT)).replace('\\', '/'),
                 sha256=sha(ARCHIVE.read_bytes()), bytes=ARCHIVE.stat().st_size,
                 payload_manifest=manifest, crc_and_exact_member_bytes_verified=True),
    recorder_sha256=sha(Path(__file__).read_bytes()),
    limits=r['limits'],
)
with TARGET.open('x', encoding='utf-8') as f:
    f.write(json.dumps(record, ensure_ascii=False, indent=2) + '\n')
note = ('**17:04新partial核對**：k602e7baa8e550c66在216保留15成功、'
        'r80kl03_e19d31436041三次COM失敗；沿用native partial verifier一次，11/11核對通過，'
        'results／fail／claim及19來源前後不變，done仍不存在。Fail只列216且worker_continues=true；'
        '原生exact roster尚未耗盡，218／37仍可接手，僅資格而非已接手證據。'
        '不移除markers、不重派、不另做WM或HFSS；保留原生跨機處理。')
ongoing = ROOT / 'configs/ONGOING.md'
text = ongoing.read_text(encoding='utf-8')
anchor = next(line for line in text.splitlines() if line.startswith('- **10/11 17:04例行健康**'))
text = text.replace(anchor, anchor + '\n- ' + note + '[核對與版本封存](../docs/log/assets/r80_partial_retry_review_20261011_1704.json)。', 1)
ongoing.write_text(text, encoding='utf-8')
log = ROOT / 'docs/log/round-80-symmetry-exploration.md'
text = log.read_text(encoding='utf-8')
top = text.splitlines()[2]
text = text.replace(top, top + '\n\n' + note + '[實際證據](assets/r80_partial_retry_review_20261011_1704.json)。', 1)
log.write_text(text, encoding='utf-8')
print(json.dumps({'record': str(TARGET.relative_to(ROOT)), 'sha256': sha(TARGET.read_bytes()),
                  'archive_sha256': sha(ARCHIVE.read_bytes()), 'archive_bytes': ARCHIVE.stat().st_size}, ensure_ascii=False))
