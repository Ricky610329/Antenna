from __future__ import annotations

import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path


HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
if str(REPO) not in sys.path:
    sys.path.insert(0, str(REPO))

from script import profiled_batch as pb
from script.symmetry_factory_cycle import _normalize_retry_workers, _terminal_fail


TARGET = "dedust_r80k602e7baa8e550c66"
ERROR_ID = "r80kl03_e19d31436041"
HEALTH = REPO / "tmp" / "r80_restored_health_20261010_v005" / "health_restored_20261011_1704.json"
OWNER = REPO / "tmp" / "r80_1704_health_record_20261011_v001" / "active_owner_readback.json"
COMMIT = (
    REPO
    / "tmp"
    / "r80_factory_20261007"
    / "controller_diverse_sm_v1"
    / "low_backlog"
    / "commit_receipts"
    / "602e7baa8e550c66dd774d506177073e18581b73926c8ba5189eb05c2a6d7a70.json"
)
PAIR_PROOFS = REPO / "tmp" / "r80_best_render_20261010_v030" / "pair_proofs.json"
RESTORATION = REPO / "tmp" / "r80_structured48_controller_transition_20261010_v004" / "restoration_complete.json"
OUT = HERE / "partial_verification.json"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def rel(path: Path) -> str:
    try:
        return str(path.relative_to(REPO)).replace("\\", "/")
    except ValueError:
        return str(path)


def file_binding(path: Path) -> dict:
    try:
        stat = path.stat()
    except FileNotFoundError:
        return {"exists": False}
    return {"exists": True, "sha256": sha256(path), "bytes": stat.st_size}


def marker_binding(path: Path) -> tuple[dict, object | None]:
    binding = file_binding(path)
    if not binding["exists"]:
        return binding, None
    try:
        payload = pb.read_json(path)
    except Exception as exc:  # preserve an invalid/racing marker in the receipt
        binding["valid_json"] = False
        binding["read_error"] = f"{type(exc).__name__}: {exc}"
        return binding, None
    binding["valid_json"] = True
    return binding, payload


def main() -> None:
    health = pb.read_json(HEALTH)
    owner = pb.read_json(OWNER)
    commit = pb.read_json(COMMIT)
    restoration = pb.read_json(RESTORATION)
    proofs = pb.read_json(PAIR_PROOFS)

    # The historical proof supplies only the already-established dataset root.
    # Exact new target input/store names and metadata hashes come from COMMIT.
    old_root_proof = next(
        row for row in proofs if Path(row["store"]).name == "dedust_r80ka00bff601d27501e"
    )
    dataset_root = Path(old_root_proof["store"]).parent
    input_dir = dataset_root / commit["job"]["input"]
    store = dataset_root / commit["job"]["store"]
    state_root = dataset_root / "jobs_state"
    paths = {
        "results": store / "results.json",
        "fail": state_root / f"{TARGET}.fail",
        "claim": state_root / f"{TARGET}.claim",
        "done": state_root / f"{TARGET}.done",
    }
    input_metadata_paths = {
        name: input_dir / name for name in commit["input_metadata_sha256"]
    }
    store_metadata_paths = {
        name: store / name for name in ("manifest.json", "measurement.json", "score_spec.json")
    }

    runtime_paths = {name: REPO / name for name in restoration["runtime_bindings"]}
    immutable_paths = {
        "health": HEALTH,
        "owner": OWNER,
        "commit": COMMIT,
        "pair_proofs": PAIR_PROOFS,
        "restoration": RESTORATION,
        **{f"input/{name}": path for name, path in input_metadata_paths.items()},
        **{f"store/{name}": path for name, path in store_metadata_paths.items()},
        **{f"runtime/{name}": path for name, path in runtime_paths.items()},
    }
    immutable_before = {name: file_binding(path) for name, path in immutable_paths.items()}
    mutable_before = {name: file_binding(path) for name, path in paths.items()}
    fail_before_binding, fail = marker_binding(paths["fail"])
    claim_before_binding, claim = marker_binding(paths["claim"])
    done_before_binding, done = marker_binding(paths["done"])
    mutable_before.update(
        fail=fail_before_binding, claim=claim_before_binding, done=done_before_binding
    )

    cfg = pb.load_profile_config(input_dir / "config.yaml")
    native_result = None
    verifier_error = None
    try:
        native_result = pb.verify_incomplete_hfss_batch(store, cfg)
    except Exception as exc:
        verifier_error = f"{type(exc).__name__}: {exc}"

    results = pb.read_json(paths["results"]) if paths["results"].is_file() else None
    error_entry = results.get(ERROR_ID) if isinstance(results, dict) else None
    owner_target = next(row for row in owner["stores"] if row["store"] == TARGET)
    roster = _normalize_retry_workers(health["watch_status"]["expected_retry_workers"])
    failed_workers = fail.get("machines") if isinstance(fail, dict) else None
    eligible_workers = (
        sorted(set(roster) - set(failed_workers)) if isinstance(failed_workers, list) else []
    )
    terminal = _terminal_fail(fail, roster)

    mutable_after = {name: file_binding(path) for name, path in paths.items()}
    fail_after_binding, fail_after = marker_binding(paths["fail"])
    claim_after_binding, claim_after = marker_binding(paths["claim"])
    done_after_binding, done_after = marker_binding(paths["done"])
    mutable_after.update(
        fail=fail_after_binding, claim=claim_after_binding, done=done_after_binding
    )
    immutable_after = {name: file_binding(path) for name, path in immutable_paths.items()}

    runtime_actual = {
        name: immutable_before[f"runtime/{name}"]["sha256"] for name in runtime_paths
    }
    checks = {
        "new_exact_job_current_commit_binding": (
            commit["status"] == "committed"
            and commit["cohort_id"] == "602e7baa8e550c66dd774d506177073e18581b73926c8ba5189eb05c2a6d7a70"
            and commit["job"]["input"] == f"{TARGET}_input"
            and commit["job"]["store"] == TARGET
            and input_dir.is_dir()
            and store.is_dir()
        ),
        "new_input_metadata_hashes_exact": all(
            immutable_before[f"input/{name}"]["exists"]
            and immutable_before[f"input/{name}"]["sha256"] == expected
            for name, expected in commit["input_metadata_sha256"].items()
        ),
        "saved_health_actual_19_runtime_bindings_exact": (
            health["runtime_file_bindings_verified"] == 19
            and len(restoration["runtime_bindings"]) == 19
            and health["restoration_receipt"]["sha256"] == sha256(RESTORATION)
            and runtime_actual == restoration["runtime_bindings"]
        ),
        "reviewed_partial_sources_exact": (
            runtime_actual["script/profiled_batch.py"]
            == "5e1e99ce79b88624914cc61d57525b4b41cdb2fa4f8bf35a8d376285ced081a3"
            and runtime_actual["script/symmetry_factory_cycle.py"]
            == "3eaea5351b3bc9dddf8fade3f86b5e7927856f68d7094a68d465d1318395a48e"
        ),
        "saved_owner_target_partial_state_exact": (
            owner_target["results_exists"] is True
            and owner_target["results_sha256"] == mutable_before["results"]["sha256"]
            and owner_target["successful_entries"] == 15
            and owner_target["error_entries"]
            == [{"id": ERROR_ID, "entry": error_entry}]
            and owner_target["markers"]["claim"]["sha256"] == claim_before_binding["sha256"]
            and owner_target["markers"]["fail"]["sha256"] == fail_before_binding["sha256"]
            and owner_target["markers"]["done"] == {"exists": False}
        ),
        "native_partial_verifier_15_success_1_error_once": (
            verifier_error is None
            and native_result is not None
            and len(native_result["success_ids"]) == 15
            and native_result["error_ids"] == [ERROR_ID]
        ),
        "exact_failed_entry_attempts_and_kind": (
            isinstance(error_entry, dict)
            and error_entry.get("attempts") == 3
            and error_entry.get("error_kind") == "hfss_simulation"
        ),
        "claim_fail_done_marker_state_exact": (
            claim == {"machine": "140.123.106.216", "at": "2026-10-11 16:03:21"}
            and isinstance(fail, dict)
            and fail.get("machines") == ["140.123.106.216"]
            and fail.get("worker_continues") is True
            and fail.get("failure_kind") == "incomplete_profile_hfss"
            and done is None
            and done_before_binding == {"exists": False}
        ),
        "retry_roster_exact_nonterminal_eligible_only": (
            roster == ("140.123.106.216", "140.123.106.218", "140.123.106.37")
            and terminal is False
            and eligible_workers == ["140.123.106.218", "140.123.106.37"]
        ),
        "results_fail_claim_done_unchanged_during_native_verification": (
            mutable_before == mutable_after
            and fail == fail_after
            and claim == claim_after
            and done == done_after is None
        ),
        "all_immutable_inputs_and_sources_unchanged": immutable_before == immutable_after,
    }
    failures = sorted(name for name, passed in checks.items() if not passed)
    record = {
        "schema_version": 1,
        "kind": "r80_1704_new_partial_failure_review_v001",
        "observed_utc": datetime.now(timezone.utc).isoformat(),
        "status": "passed_existing_partial_profile_verifier_nonterminal_exact_roster" if not failures else "failed_bounded_partial_review",
        "scope": TARGET,
        "exact_job_resolution": {
            "source": "immutable current low-backlog commit receipt; historical pair proof used only for established dataset root",
            "commit_receipt": rel(COMMIT),
            "commit_receipt_sha256": sha256(COMMIT),
            "dataset_root": str(dataset_root),
            "input": str(input_dir),
            "store": str(store),
            "input_metadata_sha256": commit["input_metadata_sha256"],
        },
        "saved_health": {
            "path": rel(HEALTH),
            "sha256": sha256(HEALTH),
            "observed_utc": health["observed_utc"],
            "runtime_file_bindings_verified": health["runtime_file_bindings_verified"],
        },
        "saved_owner_readback": {
            "path": rel(OWNER),
            "sha256": sha256(OWNER),
            "observed_utc": owner["observed_utc"],
            "target": owner_target,
        },
        "native_partial_verification": {
            "called_once": True,
            "result": native_result,
            "error": verifier_error,
            "successful": len(native_result["success_ids"]) if native_result else None,
            "terminal_errors": len(native_result["error_ids"]) if native_result else None,
            "failed_entry": error_entry,
        },
        "retry_interpretation": {
            "expected_retry_workers": list(roster),
            "failed_workers": failed_workers,
            "terminal_roster_failure": terminal,
            "still_eligible_workers_by_rule": eligible_workers,
            "eligibility_is_actual_takeover": False,
            "worker_continues": fail.get("worker_continues") if isinstance(fail, dict) else None,
        },
        "mutable_before": mutable_before,
        "mutable_after": mutable_after,
        "immutable_hashes_before": immutable_before,
        "immutable_hashes_after": immutable_after,
        "runtime_binding_hashes": runtime_actual,
        "checks": checks,
        "failures": failures,
        "helper_sha256": sha256(Path(__file__)),
        "limits": [
            "Only the named new partial store and its exact input, saved 17:04 health/owner evidence, current commit proof and reviewed source bindings were read; no other store or model was reviewed.",
            "The native partial verifier was called once. It replays successful observation profile/file integrity; no separate raw WM arithmetic replay was performed.",
            "Workers 140.123.106.218 and 140.123.106.37 are eligible only under the unchanged roster rule. This is not evidence of an actual claim, takeover, dispatch or remote worker process.",
            "The failed sample remains failed, the done marker remains absent and terminal_roster_failure is false.",
            "No NAS write, marker deletion, job dispatch, process signal, HFSS, training, model review, source edit, queue/runtime mutation, git stage or commit was performed.",
        ],
    }
    with OUT.open("x", encoding="utf-8") as stream:
        stream.write(json.dumps(record, ensure_ascii=False, indent=2, sort_keys=True) + "\n")
    print(json.dumps({
        "status": record["status"],
        "check_count": len(checks),
        "failures": failures,
        "successful": record["native_partial_verification"]["successful"],
        "terminal_errors": record["native_partial_verification"]["terminal_errors"],
        "eligible_by_rule": eligible_workers,
        "terminal": terminal,
    }, ensure_ascii=False, sort_keys=True))


if __name__ == "__main__":
    main()
