Restore tmp/ members at their original repository-relative paths.
Evidence only: native partial verifier ran once; 15 successes, 1 failed sample.
Eligible 218/37 means rule eligibility, not actual takeover.
Referenced NAS inputs, curves, models and controller receipts are not included.
Do not re-run against a changed live store or modify claims/fail/done.
