Local evidence recorder adapter for 2026-10-11 20:34.
No controller/worker/queue/marker changes. Reduced active ownership requires an immutable actual final-tail action, valid+pending+new tail=5000, short final_target_tail jobs and exact local staged manifest row counts.
Current active claims do not prove remote process liveness. Source references remain repo/tmp paths.
