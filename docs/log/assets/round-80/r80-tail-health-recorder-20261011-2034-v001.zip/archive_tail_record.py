"""Archive the local recorder adaptation and annotate saved tail metadata."""
import hashlib
import json
import zipfile
from pathlib import Path
from script.symmetry_factory_cycle import _terminal_fail

root = Path(__file__).resolve().parents[2]
path = root / 'docs/log/assets/r80_health_20261011_2034.json'
record = json.loads(path.read_text(encoding='utf-8'))
partial = next(r for r in record['owner_readback']['stores'] if r['store']=='dedust_r80kfb8a72d1023de13e')
roster = ('140.123.106.216','140.123.106.218','140.123.106.37')
assert _terminal_fail(partial['markers']['fail']['payload'],roster) is False
assert partial['markers']['fail']['payload']['machines']==['140.123.106.37','140.123.106.216']
assert partial['successful_entries']==14 and len(partial['error_entries'])==2
assert partial['markers']['fail']['payload']['worker_continues'] is True
assert not partial['markers']['done']['exists']
record['retryable_partial_metadata'] = {
    'store':partial['store'], 'saved_success_count':14,
    'remaining_eligible_workers':['140.123.106.218'],
    'terminal_by_native_roster_predicate':False,
    'worker_continues':True, 'raw_curves_not_replayed':True,
    'eligibility_is_not_proof_of_takeover_or_remote_liveness':True,
}
paths = [root/'tmp/r80_health_recorder_20261011_v003/record_health.py',
         Path(__file__).with_name('prepare_tail_recorder.py'), Path(__file__)]
payloads = {p.name:p.read_bytes() for p in paths}
payloads['README.txt'] = ('Local evidence recorder adapter for 2026-10-11 20:34.\n'
    'No controller/worker/queue/marker changes. Reduced active ownership requires an immutable actual final-tail action, '
    'valid+pending+new tail=5000, short final_target_tail jobs and exact local staged manifest row counts.\n'
    'Current active claims do not prove remote process liveness. Source references remain repo/tmp paths.\n').encode()
manifest = {name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in payloads.items()}
archive = root/'docs/log/assets/round-80/r80-tail-health-recorder-20261011-2034-v001.zip'
assert not archive.exists()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for name,data in payloads.items(): z.writestr(name,data)
    z.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert all(z.read(name)==data for name,data in payloads.items())
record['local_tail_recorder_archive'] = {'path':str(archive.relative_to(root)).replace('\\','/'),
    'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
    'payloads':manifest,'verification':'CRC and exact source bytes passed',
    'scope':'local evidence formatting only, actual saved metadata assertions; no broad or repeated tests'}
path.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
paragraph = '**20:34容量尾批與partial**：新completed v42確認4965，原pending25＋新guided尾批10恰為5000名額；本次保存時只有218認領尾批且9成功，沒有其他active claim不等同worker停機。僅本機紀錄器改為驗證已綁定尾批容量與實際staged manifest筆數，未改19個live來源。kfb8a72d1023de13e保留14成功、2個COM錯誤，fail roster為37／216、worker_continues=true；原生_terminal_fail=false，218仍可接手，尚無接手或修復證據。'
for filename,needle,link in [('configs/ONGOING.md','- **19:34新partial已耗盡三機**','../docs/log/assets/r80_health_20261011_2034.json'),
                             ('docs/log/round-80-symmetry-exploration.md','**19:34新partial已耗盡三機**','assets/r80_health_20261011_2034.json')]:
    p=root/filename
    text=p.read_text(encoding='utf-8')
    assert text.count(needle)==1
    insertion=('- ' if filename.startswith('configs/') else '')+paragraph+' [metadata與紀錄器版本]('+link+')。\n\n'
    p.write_text(text.replace(needle,insertion+needle,1),encoding='utf-8')
print(json.dumps({'archive':str(archive.relative_to(root)),'bytes':archive.stat().st_size,'record_sha256':hashlib.sha256(path.read_bytes()).hexdigest()},ensure_ascii=False))
