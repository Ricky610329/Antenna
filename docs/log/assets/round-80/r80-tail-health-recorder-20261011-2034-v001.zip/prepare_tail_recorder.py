"""Local recording adapter for the actual bounded 10-row quota tail."""
from pathlib import Path

root = Path(__file__).resolve().parents[2]
source = root / 'tmp/r80_health_recorder_20261011_v002/record_health.py'
text = source.read_text(encoding='utf-8')
old = "assert len(active)==3\nassert {row['markers']['claim']['payload']['machine'] for row in active}=={'140.123.106.216','140.123.106.218','140.123.106.37'}"
new = """guard_action_path=Path(h['watch_status']['last_receipt'])
assert sha(guard_action_path)==h['watch_status']['last_receipt_sha256']
guard_action=read(guard_action_path)
roster={'140.123.106.216','140.123.106.218','140.123.106.37'}
owners_now=[row['markers']['claim']['payload']['machine'] for row in active]
assert len(set(owners_now))==len(owners_now) and set(owners_now)<=roster
quota_tail_job_counts=dict(previous.get('quota_tail_job_counts',{}))
tail_jobs=guard_action.get('planned_jobs',[])
tail_capacity_bound=bool(tail_jobs) and all(job.get('final_target_tail') is True and 0<job['count']<16 for job in tail_jobs)
if tail_capacity_bound:
    assert guard_action['valid_unique']+guard_action['pending_unique']+sum(job['count'] for job in tail_jobs)==5000
    for job in tail_jobs:
        rows=read(Path(job['staged_input'])/'manifest.json')
        assert len(rows)==job['count']
        quota_tail_job_counts[job['store']]=job['count']
if len(active)!=3:
    assert 1<=len(active)<3 and tail_capacity_bound, 'Reduced active count requires an actual capacity-bound final tail'
else:
    assert set(owners_now)==roster"""
assert text.count(old) == 1
text = text.replace(old, new, 1)
text = text.replace("assert row['successful_entries']==16 and not row['error_entries']", "assert row['successful_entries']==quota_tail_job_counts.get(name,16) and not row['error_entries']", 1)
text = text.replace("owner_readback=owners,owner_readback_sha256=sha(args.owners),", "owner_readback=owners,owner_readback_sha256=sha(args.owners),\n    active_owners=owners_now,remote_worker_liveness_not_asserted=True,\n    capacity_bound_final_tail=tail_capacity_bound,quota_tail_job_counts=quota_tail_job_counts,", 1)
text = text.replace("if completed: note+='前次'+str(len(completed))+'批各16成功done無error/fail。'", "if completed: note+='前次'+str(len(completed))+'批成功done無error/fail，逐批成功数='+','.join(str(lookup[name]['successful_entries']) for name in completed)+'。'", 1)
text = text.replace("else: note+='當前三批無error。'", "else: note+='當前'+str(len(active))+'個active批次無error。'\nif len(active)<3: note+='已進入容量受限尾批，未認領工作的機器不據此判定停機。'", 1)
destination = root / 'tmp/r80_health_recorder_20261011_v003'
destination.mkdir()
with (destination/'record_health.py').open('x',encoding='utf-8') as handle:
    handle.write(text)
print(destination/'record_health.py')
